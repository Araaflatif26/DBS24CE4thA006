using System.Text.RegularExpressions;

namespace SchoolManagementSystem.Validators
{
    public static class Validator
    {
        public static bool IsRequired(string? value, string fieldName, out string error)
        {
            error = string.IsNullOrWhiteSpace(value) ? $"{fieldName} is required." : "";
            return string.IsNullOrWhiteSpace(error);
        }

        public static bool IsValidEmail(string? email, out string error)
        {
            error = "";
            if (string.IsNullOrWhiteSpace(email)) { error = "Email is required."; return false; }
            var pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            if (!Regex.IsMatch(email, pattern)) { error = "Invalid email format."; return false; }
            return true;
        }

        public static bool IsValidPhone(string? phone, out string error)
        {
            error = "";
            if (string.IsNullOrWhiteSpace(phone)) { error = "Phone is required."; return false; }
            var pattern = @"^[\d\-\+\(\)\s]{10,15}$";
            if (!Regex.IsMatch(phone, pattern)) { error = "Invalid phone number (10-15 digits)."; return false; }
            return true;
        }

        public static bool IsValidDate(DateTime? date, string fieldName, out string error)
        {
            error = "";
            if (!date.HasValue) { error = $"{fieldName} is required."; return false; }
            if (date.Value > DateTime.Today) { error = $"{fieldName} cannot be in the future."; return false; }
            return true;
        }

        public static bool IsPositiveNumber(decimal value, string fieldName, out string error)
        {
            error = value <= 0 ? $"{fieldName} must be a positive number." : "";
            return string.IsNullOrEmpty(error);
        }

        public static bool IsInRange(int value, int min, int max, string fieldName, out string error)
        {
            error = (value < min || value > max) ? $"{fieldName} must be between {min} and {max}." : "";
            return string.IsNullOrEmpty(error);
        }

        public static bool IsPasswordStrong(string password, out string error)
        {
            error = "";
            if (password.Length < 6) { error = "Password must be at least 6 characters."; return false; }
            return true;
        }

        /// <summary>Validates a Student model and returns all errors</summary>
        public static List<string> ValidateStudent(string firstName, string lastName, string email,
            string phone, DateTime? dob, int classID, int deptID)
        {
            var errors = new List<string>();
            if (!IsRequired(firstName, "First Name", out var e)) errors.Add(e);
            if (!IsRequired(lastName, "Last Name", out e)) errors.Add(e);
            if (!IsValidEmail(email, out e)) errors.Add(e);
            if (!IsValidPhone(phone, out e)) errors.Add(e);
            if (!IsValidDate(dob, "Date of Birth", out e)) errors.Add(e);
            if (classID <= 0) errors.Add("Class must be selected.");
            if (deptID <= 0) errors.Add("Department must be selected.");
            return errors;
        }

        /// <summary>Validates a Teacher model</summary>
        public static List<string> ValidateTeacher(string firstName, string lastName, string email,
            string phone, decimal salary)
        {
            var errors = new List<string>();
            if (!IsRequired(firstName, "First Name", out var e)) errors.Add(e);
            if (!IsRequired(lastName, "Last Name", out e)) errors.Add(e);
            if (!IsValidEmail(email, out e)) errors.Add(e);
            if (!IsValidPhone(phone, out e)) errors.Add(e);
            if (!IsPositiveNumber(salary, "Salary", out e)) errors.Add(e);
            return errors;
        }

        /// <summary>Show validation errors in a message box</summary>
        public static bool ShowErrors(List<string> errors, string title = "Validation Errors")
        {
            if (errors.Count == 0) return true;
            MessageBox.Show(string.Join("\n", errors), title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }
    }
}
