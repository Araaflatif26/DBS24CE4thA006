using SchoolManagementSystem.DAL;

namespace SchoolManagementSystem.Utilities
{
    public enum LogLevel { Info, Warning, Error, Critical }

    public static class Logger
    {
        public static void Log(LogLevel level, string message, string module = "General",
            Exception? ex = null, int? userID = null)
        {
            string stackTrace = ex?.StackTrace ?? "";
            string fullMessage = ex != null ? $"{message} | Exception: {ex.Message}" : message;

            // Log to database
            try
            {
                string query = @"INSERT INTO ErrorLogs (LogLevel, Message, StackTrace, UserID, Module)
                                 VALUES (@level, @msg, @stack, @uid, @module)";
                DatabaseHelper.ExecuteNonQuery(query, new Dictionary<string, object>
                {
                    { "@level", level.ToString() },
                    { "@msg", fullMessage },
                    { "@stack", stackTrace },
                    { "@uid", userID.HasValue ? (object)userID.Value : DBNull.Value },
                    { "@module", module }
                });
            }
            catch { /* Suppress logging errors */ }

            // Also log to file
            try
            {
                string logDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");
                Directory.CreateDirectory(logDir);
                string logFile = Path.Combine(logDir, $"log_{DateTime.Today:yyyyMMdd}.txt");
                string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{level}] [{module}] {fullMessage}";
                if (!string.IsNullOrEmpty(stackTrace))
                    logEntry += $"\n  StackTrace: {stackTrace}";
                File.AppendAllText(logFile, logEntry + Environment.NewLine);
            }
            catch { /* Suppress file logging errors */ }
        }

        public static void LogInfo(string message, string module = "General") =>
            Log(LogLevel.Info, message, module);

        public static void LogWarning(string message, string module = "General") =>
            Log(LogLevel.Warning, message, module);

        public static void LogError(string message, string module = "General", Exception? ex = null) =>
            Log(LogLevel.Error, message, module, ex);

        public static void LogCritical(string message, string module = "General", Exception? ex = null) =>
            Log(LogLevel.Critical, message, module, ex);
    }
}
