using SchoolManagementSystem.Forms;
using SchoolManagementSystem.Utilities;

namespace SchoolManagementSystem
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Global exception handler
            Application.ThreadException += (sender, e) =>
            {
                Logger.LogCritical($"Unhandled UI exception: {e.Exception.Message}", "Application", e.Exception);
                MessageBox.Show($"An unexpected error occurred:\n{e.Exception.Message}\n\nThe error has been logged.",
                    "Unexpected Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };

            AppDomain.CurrentDomain.UnhandledException += (sender, e) =>
            {
                var ex = e.ExceptionObject as Exception;
                Logger.LogCritical($"Unhandled domain exception: {ex?.Message}", "Application", ex);
            };

            Logger.LogInfo("Application started.", "Application");
            Application.Run(new LoginForm());
        }
    }
}
