using MySql.Data.MySqlClient;
using System.Configuration;

namespace SchoolManagementSystem.DAL
{
    public static class DatabaseHelper
    {
        private static readonly string ConnectionString =
            "Server=localhost;Database=SchoolManagementDB;Uid=root;Pwd=Araaf@1234;";

        public static MySqlConnection GetConnection()
        {
            var conn = new MySqlConnection(ConnectionString);
            conn.Open();
            return conn;
        }

        public static void ExecuteNonQuery(string query, Dictionary<string, object>? parameters = null)
        {
            using var conn = GetConnection();
            using var cmd = new MySqlCommand(query, conn);
            if (parameters != null)
                foreach (var p in parameters)
                    cmd.Parameters.AddWithValue(p.Key, p.Value);
            cmd.ExecuteNonQuery();
        }

        public static MySqlDataReader ExecuteReader(string query, MySqlConnection conn,
            Dictionary<string, object>? parameters = null)
        {
            var cmd = new MySqlCommand(query, conn);
            if (parameters != null)
                foreach (var p in parameters)
                    cmd.Parameters.AddWithValue(p.Key, p.Value);
            return cmd.ExecuteReader();
        }

        public static object? ExecuteScalar(string query, Dictionary<string, object>? parameters = null)
        {
            using var conn = GetConnection();
            using var cmd = new MySqlCommand(query, conn);
            if (parameters != null)
                foreach (var p in parameters)
                    cmd.Parameters.AddWithValue(p.Key, p.Value);
            return cmd.ExecuteScalar();
        }

        public static System.Data.DataTable ExecuteDataTable(string query,
            Dictionary<string, object>? parameters = null)
        {
            using var conn = GetConnection();
            using var cmd = new MySqlCommand(query, conn);
            if (parameters != null)
                foreach (var p in parameters)
                    cmd.Parameters.AddWithValue(p.Key, p.Value);
            using var adapter = new MySqlDataAdapter(cmd);
            var dt = new System.Data.DataTable();
            adapter.Fill(dt);
            return dt;
        }

        public static System.Data.DataTable ExecuteStoredProcedure(string procName,
            Dictionary<string, object>? parameters = null)
        {
            using var conn = GetConnection();
            using var cmd = new MySqlCommand(procName, conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            if (parameters != null)
                foreach (var p in parameters)
                    cmd.Parameters.AddWithValue(p.Key, p.Value);
            using var adapter = new MySqlDataAdapter(cmd);
            var dt = new System.Data.DataTable();
            adapter.Fill(dt);
            return dt;
        }
    }
}
