using SchoolManagementSystem.Models;
using SchoolManagementSystem.Utilities;
using System.Data;

namespace SchoolManagementSystem.DAL
{
    public class StudentDAL
    {
        public List<Student> GetAllStudents(bool activeOnly = true)
        {
            var list = new List<Student>();
            try
            {
                string query = activeOnly
                    ? "SELECT * FROM vw_StudentDetails WHERE IsActive = 1 ORDER BY FirstName"
                    : "SELECT * FROM vw_StudentDetails ORDER BY FirstName";
                var dt = DatabaseHelper.ExecuteDataTable(query);
                foreach (DataRow row in dt.Rows)
                    list.Add(MapStudent(row));
            }
            catch (Exception ex) { Logger.LogError("GetAllStudents failed", "StudentDAL", ex); }
            return list;
        }

        public Student? GetStudentByID(int studentID)
        {
            try
            {
                var dt = DatabaseHelper.ExecuteDataTable(
                    "SELECT * FROM vw_StudentDetails WHERE StudentID = @id",
                    new Dictionary<string, object> { { "@id", studentID } });
                return dt.Rows.Count > 0 ? MapStudent(dt.Rows[0]) : null;
            }
            catch (Exception ex) { Logger.LogError($"GetStudentByID({studentID}) failed", "StudentDAL", ex); return null; }
        }

        public bool AddStudent(Student s, out string message)
        {
            message = "";
            try
            {
                string query = @"INSERT INTO Students 
                    (FirstName, LastName, DateOfBirth, Gender, Email, Phone, Address,
                     EnrollmentDate, ClassID, DepartmentID, GuardianName, GuardianPhone)
                    VALUES (@fn, @ln, @dob, @gender, @email, @phone, @addr,
                            @enroll, @class, @dept, @gname, @gphone)";
                DatabaseHelper.ExecuteNonQuery(query, new Dictionary<string, object>
                {
                    {"@fn", s.FirstName}, {"@ln", s.LastName}, {"@dob", s.DateOfBirth},
                    {"@gender", s.Gender}, {"@email", s.Email}, {"@phone", s.Phone},
                    {"@addr", s.Address}, {"@enroll", s.EnrollmentDate},
                    {"@class", s.ClassID}, {"@dept", s.DepartmentID},
                    {"@gname", s.GuardianName}, {"@gphone", s.GuardianPhone}
                });
                Logger.LogInfo($"Student {s.FullName} added.", "StudentDAL");
                return true;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                Logger.LogError("AddStudent failed", "StudentDAL", ex);
                return false;
            }
        }

        public bool UpdateStudent(Student s, out string message)
        {
            message = "";
            try
            {
                string query = @"UPDATE Students SET
                    FirstName=@fn, LastName=@ln, DateOfBirth=@dob, Gender=@gender,
                    Email=@email, Phone=@phone, Address=@addr, ClassID=@class,
                    DepartmentID=@dept, GuardianName=@gname, GuardianPhone=@gphone
                    WHERE StudentID=@id";
                DatabaseHelper.ExecuteNonQuery(query, new Dictionary<string, object>
                {
                    {"@fn", s.FirstName}, {"@ln", s.LastName}, {"@dob", s.DateOfBirth},
                    {"@gender", s.Gender}, {"@email", s.Email}, {"@phone", s.Phone},
                    {"@addr", s.Address}, {"@class", s.ClassID}, {"@dept", s.DepartmentID},
                    {"@gname", s.GuardianName}, {"@gphone", s.GuardianPhone}, {"@id", s.StudentID}
                });
                Logger.LogInfo($"Student ID {s.StudentID} updated.", "StudentDAL");
                return true;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                Logger.LogError("UpdateStudent failed", "StudentDAL", ex);
                return false;
            }
        }

        public bool DeactivateStudent(int studentID, out string message)
        {
            message = "";
            try
            {
                DatabaseHelper.ExecuteNonQuery(
                    "UPDATE Students SET IsActive = 0 WHERE StudentID = @id",
                    new Dictionary<string, object> { { "@id", studentID } });
                return true;
            }
            catch (Exception ex) { message = ex.Message; Logger.LogError("DeactivateStudent failed", "StudentDAL", ex); return false; }
        }

        public DataTable SearchStudents(string keyword)
        {
            string query = @"SELECT StudentID, FullName, Email, Phone, ClassName, DepartmentName
                             FROM vw_StudentDetails
                             WHERE (FirstName LIKE @kw OR LastName LIKE @kw OR Email LIKE @kw)
                             AND IsActive = 1";
            return DatabaseHelper.ExecuteDataTable(query,
                new Dictionary<string, object> { { "@kw", $"%{keyword}%" } });
        }

        public DataTable GetStudentsByClass(int classID)
        {
            return DatabaseHelper.ExecuteDataTable(
                "SELECT * FROM vw_StudentDetails WHERE ClassID = @cid AND IsActive = 1",
                new Dictionary<string, object> { { "@cid", classID } });
        }

        private Student MapStudent(DataRow row) => new Student
        {
            StudentID = Convert.ToInt32(row["StudentID"]),
            FirstName = row["FirstName"].ToString()!,
            LastName = row["LastName"].ToString()!,
            DateOfBirth = Convert.ToDateTime(row["DateOfBirth"]),
            Gender = row["Gender"].ToString()!,
            Email = row["Email"]?.ToString() ?? "",
            Phone = row["Phone"]?.ToString() ?? "",
            ClassID = row["ClassID"] == DBNull.Value ? 0 : Convert.ToInt32(row["ClassID"]),
            ClassName = row["ClassName"]?.ToString() ?? "",
            DepartmentID = row["DepartmentID"] == DBNull.Value ? 0 : Convert.ToInt32(row["DepartmentID"]),
            DepartmentName = row["DepartmentName"]?.ToString() ?? "",
            GuardianName = row["GuardianName"]?.ToString() ?? "",
            GuardianPhone = row["GuardianPhone"]?.ToString() ?? "",
            IsActive = Convert.ToBoolean(row["IsActive"])
        };
    }
}
