using iTextSharp.text;
using iTextSharp.text.pdf;
using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Utilities;
using System.Data;
using PdfFont = iTextSharp.text.Font;

namespace SchoolManagementSystem.Reports
{
    public static class PdfReportGenerator
    {
        private static readonly BaseColor HeaderColor = new BaseColor(0, 102, 204);
        private static readonly BaseColor AltRowColor = new BaseColor(235, 245, 255);
        private static readonly PdfFont TitleFont = new PdfFont(PdfFont.FontFamily.HELVETICA, 16, PdfFont.BOLD, BaseColor.WHITE);
        private static readonly PdfFont HeaderFont = new PdfFont(PdfFont.FontFamily.HELVETICA, 10, PdfFont.BOLD, BaseColor.WHITE);
        private static readonly PdfFont NormalFont = new PdfFont(PdfFont.FontFamily.HELVETICA, 9, PdfFont.NORMAL, BaseColor.BLACK);
        private static readonly PdfFont BoldFont = new PdfFont(PdfFont.FontFamily.HELVETICA, 9, PdfFont.BOLD, BaseColor.BLACK);
        private static readonly PdfFont SmallFont = new PdfFont(PdfFont.FontFamily.HELVETICA, 8, PdfFont.NORMAL, BaseColor.DARK_GRAY);

        // ── Report 1: All Students List ──────────────────────────────────────
        public static string GenerateStudentListReport(int? classID = null)
        {
            string query = classID.HasValue
                ? $"SELECT FullName, Gender, ClassName, DepartmentName, Email, Phone, EnrollmentDate FROM vw_StudentDetails WHERE IsActive=1 AND ClassID={classID} ORDER BY FullName"
                : "SELECT FullName, Gender, ClassName, DepartmentName, Email, Phone, EnrollmentDate FROM vw_StudentDetails WHERE IsActive=1 ORDER BY ClassName, FullName";
            var dt = DatabaseHelper.ExecuteDataTable(query);
            return GenerateTableReport("Student List Report", dt, new[] { "Full Name", "Gender", "Class", "Department", "Email", "Phone", "Enrolled" });
        }

        // ── Report 2: Student Attendance Report ─────────────────────────────
        public static string GenerateAttendanceReport(int classID, int subjectID, DateTime from, DateTime to)
        {
            var dt = DatabaseHelper.ExecuteStoredProcedure("sp_GetClassAttendanceReport", new Dictionary<string, object>
            {
                {"@p_ClassID", classID}, {"@p_SubjectID", subjectID},
                {"@p_StartDate", from}, {"@p_EndDate", to}
            });
            string title = $"Attendance Report ({from:dd/MM/yyyy} - {to:dd/MM/yyyy})";
            return GenerateTableReport(title, dt, new[] { "Student ID", "Student Name", "Total", "Present", "Absent", "Late", "Attendance %" });
        }

        // ── Report 3: Exam Results Report ───────────────────────────────────
        public static string GenerateExamResultsReport(int examID)
        {
            var dt = DatabaseHelper.ExecuteDataTable(@"SELECT StudentName, SubjectName, ExamType, TotalMarks, ObtainedMarks, Percentage, Grade, PassFail
                FROM vw_ExamResultsSummary WHERE ExamID=@id ORDER BY StudentName",
                new Dictionary<string, object> { { "@id", examID } });
            return GenerateTableReport("Exam Results Report", dt, new[] { "Student", "Subject", "Type", "Total", "Obtained", "%", "Grade", "Result" });
        }

        // ── Report 4: Student Report Card ───────────────────────────────────
        public static string GenerateReportCard(int studentID, string academicYear)
        {
            string path = GetOutputPath("ReportCard");
            try
            {
                var studentInfo = DatabaseHelper.ExecuteDataTable("SELECT * FROM vw_StudentDetails WHERE StudentID=@id",
                    new Dictionary<string, object> { { "@id", studentID } });
                var results = DatabaseHelper.ExecuteStoredProcedure("sp_GetStudentReportCard",
                    new Dictionary<string, object> { { "@p_StudentID", studentID }, { "@p_AcademicYear", academicYear } });

                using var doc = new Document(PageSize.A4, 50, 50, 60, 60);
                using var writer = PdfWriter.GetInstance(doc, new FileStream(path, FileMode.Create));
                doc.Open();

                AddHeader(doc, "Student Report Card", $"Academic Year: {academicYear}");

                if (studentInfo.Rows.Count > 0)
                {
                    var r = studentInfo.Rows[0];
                    var infoTable = new PdfPTable(4) { WidthPercentage = 100 };
                    infoTable.SetWidths(new float[] { 25, 25, 25, 25 });
                    AddInfoCell(infoTable, "Student Name:", r["FullName"].ToString()!);
                    AddInfoCell(infoTable, "Class:", r["ClassName"].ToString()!);
                    AddInfoCell(infoTable, "Department:", r["DepartmentName"].ToString()!);
                    AddInfoCell(infoTable, "Roll No:", studentID.ToString());
                    doc.Add(infoTable);
                    doc.Add(new Paragraph(" "));
                }

                var table = new PdfPTable(7) { WidthPercentage = 100 };
                table.SetWidths(new float[] { 30, 15, 12, 12, 12, 10, 9 });
                AddTableHeader(table, new[] { "Subject", "Exam Type", "Total Marks", "Obtained", "Percentage", "Grade", "Status" });

                decimal totalPct = 0; int count = 0;
                foreach (DataRow row in results.Rows)
                {
                    bool isPass = row["Status"].ToString() == "Pass";
                    var rowColor = isPass ? BaseColor.WHITE : new BaseColor(255, 230, 230);
                    AddTableRow(table, new[] { row["SubjectName"], row["ExamType"], row["TotalMarks"], row["ObtainedMarks"], row["Percentage"]+" %", row["Grade"], row["Status"] }, rowColor);
                    if (decimal.TryParse(row["Percentage"].ToString(), out decimal p)) { totalPct += p; count++; }
                }

                if (count > 0)
                {
                    decimal avg = totalPct / count;
                    var summaryRow = table.DefaultCell;
                    AddTableRow(table, new[] { "OVERALL AVERAGE", "", "", "", $"{avg:F1} %", GetGrade(avg), avg >= 50 ? "PASS" : "FAIL" }, new BaseColor(200, 230, 255));
                }

                doc.Add(table);
                doc.Add(new Paragraph(" "));
                AddFooter(doc);
                doc.Close();
                Logger.LogInfo($"Report card generated for StudentID {studentID}", "Reports");
                return path;
            }
            catch (Exception ex) { Logger.LogError("GenerateReportCard failed", "Reports", ex); throw; }
        }

        // ── Report 5: Fee Collection Report ────────────────────────────────
        public static string GenerateFeeCollectionReport(string month, int year)
        {
            var dt = DatabaseHelper.ExecuteDataTable(@"SELECT CONCAT(s.FirstName,' ',s.LastName) AS Student, c.ClassName, fs.FeeType,
                fp.AmountPaid, fp.PaymentDate, fp.PaymentMethod, fp.ReceiptNumber, fp.Status
                FROM FeePayments fp JOIN Students s ON fp.StudentID=s.StudentID
                JOIN FeeStructure fs ON fp.FeeStructureID=fs.FeeStructureID
                JOIN Classes c ON s.ClassID=c.ClassID
                WHERE fp.Month=@m AND fp.Year=@y ORDER BY fp.PaymentDate",
                new Dictionary<string, object> { { "@m", month }, { "@y", year } });
            return GenerateTableReport($"Fee Collection Report - {month} {year}", dt,
                new[] { "Student", "Class", "Fee Type", "Amount", "Date", "Method", "Receipt", "Status" });
        }

        // ── Report 6: Teacher List Report ───────────────────────────────────
        public static string GenerateTeacherListReport()
        {
            var dt = DatabaseHelper.ExecuteDataTable("SELECT FullName, Email, Phone, Qualification, JoiningDate, DepartmentName, Salary FROM vw_TeacherDetails WHERE IsActive=1 ORDER BY DepartmentName, FullName");
            return GenerateTableReport("Teacher List Report", dt, new[] { "Name", "Email", "Phone", "Qualification", "Joined", "Department", "Salary" });
        }

        // ── Report 7: Class-wise Student Count ──────────────────────────────
        public static string GenerateClassWiseStudentReport()
        {
            var dt = DatabaseHelper.ExecuteDataTable(@"SELECT c.ClassName, c.Section, d.DepartmentName,
                COUNT(s.StudentID) AS TotalStudents, c.Capacity,
                (c.Capacity - COUNT(s.StudentID)) AS AvailableSeats
                FROM Classes c LEFT JOIN Students s ON c.ClassID=s.ClassID AND s.IsActive=1
                LEFT JOIN Departments d ON c.DepartmentID=d.DepartmentID
                WHERE c.IsActive=1 GROUP BY c.ClassID ORDER BY c.ClassName");
            return GenerateTableReport("Class-wise Student Count Report", dt,
                new[] { "Class", "Section", "Department", "Total Students", "Capacity", "Available Seats" });
        }

        // ── Report 8: Fee Defaulters Report ────────────────────────────────
        public static string GenerateFeeDefaultersReport(string academicYear)
        {
            var dt = DatabaseHelper.ExecuteDataTable(@"SELECT StudentName, ClassName, FeeType, TotalFee, PaidAmount, BalanceAmount
                FROM vw_FeeStatus WHERE BalanceAmount > 0 ORDER BY BalanceAmount DESC");
            return GenerateTableReport("Fee Defaulters Report", dt,
                new[] { "Student", "Class", "Fee Type", "Total Fee", "Paid", "Balance" });
        }

        // ── Report 9: Subject-wise Results Summary ──────────────────────────
        public static string GenerateSubjectResultsSummary(int classID, string academicYear)
        {
            var dt = DatabaseHelper.ExecuteDataTable(@"SELECT sub.SubjectName, e.ExamType,
                COUNT(er.ResultID) AS TotalStudents,
                ROUND(AVG(er.ObtainedMarks*100/e.TotalMarks),2) AS AvgPercentage,
                SUM(CASE WHEN er.ObtainedMarks>=e.PassingMarks THEN 1 ELSE 0 END) AS Passed,
                SUM(CASE WHEN er.ObtainedMarks<e.PassingMarks THEN 1 ELSE 0 END) AS Failed
                FROM ExamResults er JOIN Exams e ON er.ExamID=e.ExamID
                JOIN Subjects sub ON e.SubjectID=sub.SubjectID
                JOIN Classes c ON e.ClassID=c.ClassID
                WHERE e.ClassID=@cid AND c.AcademicYear=@yr
                GROUP BY sub.SubjectID, e.ExamType ORDER BY sub.SubjectName",
                new Dictionary<string, object> { { "@cid", classID }, { "@yr", academicYear } });
            return GenerateTableReport("Subject-wise Results Summary", dt,
                new[] { "Subject", "Exam Type", "Total Students", "Avg %", "Passed", "Failed" });
        }

        // ── Report 10: Daily Attendance Summary ─────────────────────────────
        public static string GenerateDailyAttendanceSummary(DateTime date)
        {
            var dt = DatabaseHelper.ExecuteDataTable(@"SELECT c.ClassName, sub.SubjectName,
                COUNT(a.AttendanceID) AS Total,
                SUM(CASE WHEN a.Status='Present' THEN 1 ELSE 0 END) AS Present,
                SUM(CASE WHEN a.Status='Absent' THEN 1 ELSE 0 END) AS Absent,
                ROUND(SUM(CASE WHEN a.Status='Present' THEN 1 ELSE 0 END)*100.0/COUNT(a.AttendanceID),1) AS AttendancePct
                FROM Attendance a JOIN Students s ON a.StudentID=s.StudentID
                JOIN Classes c ON s.ClassID=c.ClassID
                JOIN Subjects sub ON a.SubjectID=sub.SubjectID
                WHERE DATE(a.AttendanceDate)=@date GROUP BY c.ClassID, sub.SubjectID",
                new Dictionary<string, object> { { "@date", date.Date } });
            return GenerateTableReport($"Daily Attendance Summary - {date:dd/MM/yyyy}", dt,
                new[] { "Class", "Subject", "Total", "Present", "Absent", "Attendance %" });
        }

        // ── Report 11: Timetable Report ─────────────────────────────────────
        public static string GenerateTimetableReport(int classID)
        {
            var dt = DatabaseHelper.ExecuteDataTable("SELECT DayOfWeek, StartTime, EndTime, SubjectName, TeacherName, RoomNumber FROM vw_ClassTimetable WHERE ClassName=(SELECT ClassName FROM Classes WHERE ClassID=@cid) ORDER BY DayOfWeek, StartTime",
                new Dictionary<string, object> { { "@cid", classID } });
            return GenerateTableReport("Class Timetable Report", dt,
                new[] { "Day", "Start", "End", "Subject", "Teacher", "Room" });
        }

        // ────────────────────────────────────────────────────────────────────
        // Helpers
        // ────────────────────────────────────────────────────────────────────

        private static string GenerateTableReport(string title, DataTable dt, string[] headers)
        {
            string path = GetOutputPath(title.Replace(" ", "_").Replace("/", "-"));
            try
            {
                using var doc = new Document(PageSize.A4.Rotate(), 30, 30, 50, 50);
                using var writer = PdfWriter.GetInstance(doc, new FileStream(path, FileMode.Create));
                doc.Open();
                AddHeader(doc, title, $"Generated: {DateTime.Now:dd/MM/yyyy HH:mm}");

                var table = new PdfPTable(headers.Length) { WidthPercentage = 100 };
                AddTableHeader(table, headers);

                int rowNum = 0;
                foreach (DataRow row in dt.Rows)
                {
                    var color = rowNum % 2 == 0 ? BaseColor.WHITE : AltRowColor;
                    AddTableRow(table, row.ItemArray, color);
                    rowNum++;
                }

                // Summary row
                var summaryPara = new Paragraph($"Total Records: {dt.Rows.Count}", BoldFont) { SpacingBefore = 5 };
                doc.Add(table);
                doc.Add(summaryPara);
                AddFooter(doc);
                doc.Close();
                Logger.LogInfo($"Report generated: {title}", "Reports");
                return path;
            }
            catch (Exception ex) { Logger.LogError($"GenerateTableReport failed: {title}", "Reports", ex); throw; }
        }

        private static void AddHeader(Document doc, string title, string subtitle)
        {
            var headerTable = new PdfPTable(1) { WidthPercentage = 100 };
            var titleCell = new PdfPCell(new Phrase(title, TitleFont))
            {
                BackgroundColor = HeaderColor, HorizontalAlignment = Element.ALIGN_CENTER,
                Padding = 12, Border = iTextSharp.text.Rectangle.NO_BORDER
            };
            headerTable.AddCell(titleCell);

            var subtitleCell = new PdfPCell(new Phrase($"School Management System  |  {subtitle}", SmallFont))
            {
                BackgroundColor = new BaseColor(0, 80, 160), HorizontalAlignment = Element.ALIGN_CENTER,
                Padding = 5, Border = iTextSharp.text.Rectangle.NO_BORDER
            };
            var subFont = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 8, iTextSharp.text.Font.NORMAL, BaseColor.WHITE);
            subtitleCell.Phrase = new Phrase($"School Management System  |  {subtitle}", subFont);
            headerTable.AddCell(subtitleCell);

            doc.Add(headerTable);
            doc.Add(new Paragraph(" "));
        }

        private static void AddTableHeader(PdfPTable table, string[] headers)
        {
            foreach (var h in headers)
            {
                var cell = new PdfPCell(new Phrase(h, HeaderFont))
                {
                    BackgroundColor = HeaderColor, HorizontalAlignment = Element.ALIGN_CENTER,
                    Padding = 6, Border = iTextSharp.text.Rectangle.BOX, BorderColor = BaseColor.WHITE
                };
                table.AddCell(cell);
            }
        }

        private static void AddTableRow(PdfPTable table, object?[] values, BaseColor bgColor)
        {
            foreach (var v in values)
            {
                var cell = new PdfPCell(new Phrase(v?.ToString() ?? "", NormalFont))
                {
                    BackgroundColor = bgColor, Padding = 5,
                    Border = iTextSharp.text.Rectangle.BOX, BorderColor = new BaseColor(200, 200, 200)
                };
                table.AddCell(cell);
            }
        }

        private static void AddInfoCell(PdfPTable table, string label, string value)
        {
            table.AddCell(new PdfPCell(new Phrase(label, BoldFont)) { Border = iTextSharp.text.Rectangle.NO_BORDER, Padding = 4 });
            table.AddCell(new PdfPCell(new Phrase(value, NormalFont)) { Border = iTextSharp.text.Rectangle.NO_BORDER, Padding = 4 });
        }

        private static void AddFooter(Document doc)
        {
            doc.Add(new Paragraph(" "));
            var line = new iTextSharp.text.pdf.draw.LineSeparator(0.5f, 100f, HeaderColor, Element.ALIGN_CENTER, -2);
            doc.Add(new Chunk(line));
            var footer = new Paragraph($"© {DateTime.Now.Year} School Management System | University of Engineering and Technology, Lahore | Page generated on {DateTime.Now:dd/MM/yyyy HH:mm:ss}", SmallFont)
            { Alignment = Element.ALIGN_CENTER, SpacingBefore = 4 };
            doc.Add(footer);
        }

        private static string GetOutputPath(string name)
        {
            string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "SMS_Reports");
            Directory.CreateDirectory(dir);
            return Path.Combine(dir, $"{name}_{DateTime.Now:yyyyMMdd_HHmmss}.pdf");
        }

        private static string GetGrade(decimal pct) => pct switch
        {
            >= 90 => "A+", >= 80 => "A", >= 70 => "B", >= 60 => "C", >= 50 => "D", _ => "F"
        };
    }
}
