namespace SchoolManagementSystem.Models
{
    // Domain Class 1
    public class Student
    {
        public int StudentID { get; set; }
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
        public string FullName => $"{FirstName} {LastName}";
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; } = "";
        public string Email { get; set; } = "";
        public string Phone { get; set; } = "";
        public string Address { get; set; } = "";
        public DateTime EnrollmentDate { get; set; }
        public int ClassID { get; set; }
        public string ClassName { get; set; } = "";
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; } = "";
        public string GuardianName { get; set; } = "";
        public string GuardianPhone { get; set; } = "";
        public bool IsActive { get; set; } = true;
    }

    // Domain Class 2
    public class Teacher
    {
        public int TeacherID { get; set; }
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
        public string FullName => $"{FirstName} {LastName}";
        public string Email { get; set; } = "";
        public string Phone { get; set; } = "";
        public string Qualification { get; set; } = "";
        public DateTime JoiningDate { get; set; }
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; } = "";
        public decimal Salary { get; set; }
        public bool IsActive { get; set; } = true;
    }

    // Domain Class 3
    public class Department
    {
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; } = "";
        public string DepartmentCode { get; set; } = "";
        public string HeadOfDepartment { get; set; } = "";
        public int EstablishedYear { get; set; }
        public bool IsActive { get; set; } = true;
    }

    // Domain Class 4
    public class Subject
    {
        public int SubjectID { get; set; }
        public string SubjectName { get; set; } = "";
        public string SubjectCode { get; set; } = "";
        public int CreditHours { get; set; }
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; } = "";
        public bool IsElective { get; set; }
        public bool IsActive { get; set; } = true;
    }

    // Domain Class 5
    public class ClassModel
    {
        public int ClassID { get; set; }
        public string ClassName { get; set; } = "";
        public string ClassCode { get; set; } = "";
        public string Section { get; set; } = "";
        public int DepartmentID { get; set; }
        public int ClassTeacherID { get; set; }
        public string RoomNumber { get; set; } = "";
        public int Capacity { get; set; }
        public string AcademicYear { get; set; } = "";
        public bool IsActive { get; set; } = true;
    }

    // Domain Class 6
    public class Attendance
    {
        public int AttendanceID { get; set; }
        public int StudentID { get; set; }
        public string StudentName { get; set; } = "";
        public int SubjectID { get; set; }
        public DateTime AttendanceDate { get; set; }
        public string Status { get; set; } = "Present";
        public string Remarks { get; set; } = "";
        public int MarkedByTeacherID { get; set; }
    }

    // Domain Class 7
    public class Exam
    {
        public int ExamID { get; set; }
        public string ExamName { get; set; } = "";
        public string ExamType { get; set; } = "";
        public int SubjectID { get; set; }
        public string SubjectName { get; set; } = "";
        public int ClassID { get; set; }
        public string ClassName { get; set; } = "";
        public DateTime ExamDate { get; set; }
        public int TotalMarks { get; set; }
        public int PassingMarks { get; set; }
        public int Duration { get; set; }
        public bool IsActive { get; set; } = true;
    }

    // Domain Class 8
    public class ExamResult
    {
        public int ResultID { get; set; }
        public int ExamID { get; set; }
        public string ExamName { get; set; } = "";
        public int StudentID { get; set; }
        public string StudentName { get; set; } = "";
        public decimal ObtainedMarks { get; set; }
        public string Grade { get; set; } = "";
        public string Remarks { get; set; } = "";
        public double Percentage => ExamTotalMarks > 0 ? (double)ObtainedMarks * 100 / ExamTotalMarks : 0;
        public int ExamTotalMarks { get; set; }
    }

    // Domain Class 9
    public class FeePayment
    {
        public int PaymentID { get; set; }
        public int StudentID { get; set; }
        public string StudentName { get; set; } = "";
        public int FeeStructureID { get; set; }
        public string FeeType { get; set; } = "";
        public decimal AmountPaid { get; set; }
        public DateTime PaymentDate { get; set; }
        public string PaymentMethod { get; set; } = "";
        public string ReceiptNumber { get; set; } = "";
        public string Month { get; set; } = "";
        public int Year { get; set; }
        public string Status { get; set; } = "";
    }

    // Domain Class 10
    public class Timetable
    {
        public int TimetableID { get; set; }
        public int ClassID { get; set; }
        public string ClassName { get; set; } = "";
        public int SubjectID { get; set; }
        public string SubjectName { get; set; } = "";
        public int TeacherID { get; set; }
        public string TeacherName { get; set; } = "";
        public string DayOfWeek { get; set; } = "";
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public string RoomNumber { get; set; } = "";
        public string AcademicYear { get; set; } = "";
    }

    // Software Class 1: Session/Auth
    public class UserSession
    {
        public static int UserID { get; set; }
        public static string Username { get; set; } = "";
        public static string Role { get; set; } = "";
        public static bool IsLoggedIn { get; set; }
        public static int? TeacherID { get; set; }
        public static int? StudentID { get; set; }

        public static void Clear()
        {
            UserID = 0; Username = ""; Role = "";
            IsLoggedIn = false; TeacherID = null; StudentID = null;
        }
    }

    // Software Class 2: Report Parameters
    public class ReportParameters
    {
        public string ReportType { get; set; } = "";
        public int? ClassID { get; set; }
        public int? SubjectID { get; set; }
        public int? StudentID { get; set; }
        public int? TeacherID { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string AcademicYear { get; set; } = "";
        public string Month { get; set; } = "";
        public int? Year { get; set; }
    }

    // Software Class 3: Announcement
    public class Announcement
    {
        public int AnnouncementID { get; set; }
        public string Title { get; set; } = "";
        public string Content { get; set; } = "";
        public string TargetAudience { get; set; } = "";
        public DateTime PublishDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public bool IsActive { get; set; } = true;
    }

    // Software Class 4: Leave Request
    public class LeaveRequest
    {
        public int LeaveID { get; set; }
        public string ApplicantType { get; set; } = "";
        public int ApplicantID { get; set; }
        public string LeaveType { get; set; } = "";
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Reason { get; set; } = "";
        public string Status { get; set; } = "Pending";
    }

    // Software Class 5: Dashboard Stats
    public class DashboardStats
    {
        public int TotalStudents { get; set; }
        public int TotalTeachers { get; set; }
        public int TotalClasses { get; set; }
        public int TotalSubjects { get; set; }
        public int PendingLeaves { get; set; }
        public decimal TotalFeeCollected { get; set; }
        public double AverageAttendance { get; set; }
    }
}
