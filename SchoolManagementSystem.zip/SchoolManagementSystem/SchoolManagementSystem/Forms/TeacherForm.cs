using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Models;
using SchoolManagementSystem.Utilities;
using SchoolManagementSystem.Validators;

namespace SchoolManagementSystem.Forms
{
    public class TeacherForm : Form
    {
        private DataGridView dgvTeachers;
        private TextBox txtFirstName, txtLastName, txtEmail, txtPhone, txtQualification, txtSalary;
        private DateTimePicker dtpJoining, dtpDOB;
        private RadioButton rdoMale, rdoFemale;
        private ComboBox cmbDepartment;
        private Button btnSave, btnUpdate, btnDelete, btnClear;
        private Panel pnlForm, pnlList;
        private Label lblTitle;

        public TeacherForm()
        {
            InitializeComponent();
            LoadTeachers();
            LoadDepartments();
        }

        private void InitializeComponent()
        {
            this.Text = "Teacher Management";
            this.Size = new Size(1100, 680);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            var menu = new MenuStrip();
            var fileMenu = new ToolStripMenuItem("File");
            fileMenu.DropDownItems.Add("New Teacher", null, (s, e) => ClearForm());
            fileMenu.DropDownItems.Add("Close", null, (s, e) => this.Close());
            menu.Items.Add(fileMenu);
            this.Controls.Add(menu);

            // List Panel
            pnlList = new Panel { Location = new Point(0, 30), Size = new Size(450, 620), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };

            var lblList = new Label { Text = "Teachers", Font = new Font("Segoe UI", 12, FontStyle.Bold), Location = new Point(10, 10), AutoSize = true, ForeColor = Color.FromArgb(0, 102, 204) };

            dgvTeachers = new DataGridView
            {
                Location = new Point(10, 40),
                Size = new Size(425, 560),
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AllowUserToAddRows = false,
                BackgroundColor = Color.White,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            dgvTeachers.SelectionChanged += DgvTeachers_SelectionChanged;

            pnlList.Controls.AddRange(new Control[] { lblList, dgvTeachers });

            // Form Panel
            pnlForm = new Panel { Location = new Point(460, 30), Size = new Size(620, 620), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };

            lblTitle = new Label { Text = "Teacher Details", Font = new Font("Segoe UI", 12, FontStyle.Bold), Location = new Point(10, 10), AutoSize = true, ForeColor = Color.FromArgb(0, 102, 204) };

            int lx = 20, rx = 320, ty = 45;
            AddLabel(pnlForm, "First Name: *", lx, ty);
            txtFirstName = AddTextBox(pnlForm, lx, ty + 22, 270);

            AddLabel(pnlForm, "Last Name: *", rx, ty);
            txtLastName = AddTextBox(pnlForm, rx, ty + 22, 270);

            AddLabel(pnlForm, "Date of Birth:", lx, ty + 70);
            dtpDOB = new DateTimePicker { Location = new Point(lx, ty + 92), Width = 270, Format = DateTimePickerFormat.Short };
            pnlForm.Controls.Add(dtpDOB);

            AddLabel(pnlForm, "Gender:", rx, ty + 70);
            rdoMale = new RadioButton { Text = "Male", Location = new Point(rx, ty + 95), Checked = true, AutoSize = true };
            rdoFemale = new RadioButton { Text = "Female", Location = new Point(rx + 70, ty + 95), AutoSize = true };
            pnlForm.Controls.AddRange(new Control[] { rdoMale, rdoFemale });

            AddLabel(pnlForm, "Email: *", lx, ty + 140);
            txtEmail = AddTextBox(pnlForm, lx, ty + 162, 270);

            AddLabel(pnlForm, "Phone: *", rx, ty + 140);
            txtPhone = AddTextBox(pnlForm, rx, ty + 162, 270);

            AddLabel(pnlForm, "Qualification:", lx, ty + 210);
            txtQualification = AddTextBox(pnlForm, lx, ty + 232, 270);

            AddLabel(pnlForm, "Joining Date:", rx, ty + 210);
            dtpJoining = new DateTimePicker { Location = new Point(rx, ty + 232), Width = 270, Format = DateTimePickerFormat.Short };
            pnlForm.Controls.Add(dtpJoining);

            AddLabel(pnlForm, "Department:", lx, ty + 280);
            cmbDepartment = new ComboBox { Location = new Point(lx, ty + 302), Width = 270, DropDownStyle = ComboBoxStyle.DropDownList };
            pnlForm.Controls.Add(cmbDepartment);

            AddLabel(pnlForm, "Salary (PKR): *", rx, ty + 280);
            txtSalary = AddTextBox(pnlForm, rx, ty + 302, 270);

            // Buttons
            btnSave = CreateButton("💾 Save", Color.FromArgb(0, 153, 76), new Point(lx, ty + 370));
            btnSave.Click += BtnSave_Click;

            btnUpdate = CreateButton("✏️ Update", Color.FromArgb(0, 102, 204), new Point(lx + 130, ty + 370));
            btnUpdate.Click += BtnUpdate_Click;
            btnUpdate.Enabled = false;

            btnDelete = CreateButton("🗑 Deactivate", Color.Red, new Point(lx + 260, ty + 370));
            btnDelete.Click += BtnDelete_Click;
            btnDelete.Enabled = false;

            btnClear = CreateButton("✕ Clear", Color.Gray, new Point(lx + 390, ty + 370));
            btnClear.Click += (s, e) => ClearForm();

            pnlForm.Controls.AddRange(new Control[] { lblTitle, btnSave, btnUpdate, btnDelete, btnClear });
            this.Controls.AddRange(new Control[] { pnlList, pnlForm });
        }

        private Label AddLabel(Panel p, string text, int x, int y)
        {
            var lbl = new Label { Text = text, Location = new Point(x, y), AutoSize = true };
            p.Controls.Add(lbl);
            return lbl;
        }

        private TextBox AddTextBox(Panel p, int x, int y, int w)
        {
            var txt = new TextBox { Location = new Point(x, y), Width = w };
            p.Controls.Add(txt);
            return txt;
        }

        private Button CreateButton(string text, Color color, Point location) => new Button
        {
            Text = text,
            Location = location,
            Width = 120,
            Height = 36,
            BackColor = color,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        };

        private void LoadTeachers()
        {
            try
            {
                var dt = DatabaseHelper.ExecuteDataTable("SELECT TeacherID, FullName, Email, DepartmentName, Salary FROM vw_TeacherDetails WHERE IsActive=1");
                dgvTeachers.DataSource = dt;
            }
            catch (Exception ex) { Logger.LogError("LoadTeachers failed", "TeacherForm", ex); }
        }

        private void LoadDepartments()
        {
            try
            {
                var depts = DatabaseHelper.ExecuteDataTable("SELECT DepartmentID, DepartmentName FROM Departments WHERE IsActive=1");
                cmbDepartment.DataSource = depts;
                cmbDepartment.DisplayMember = "DepartmentName";
                cmbDepartment.ValueMember = "DepartmentID";
            }
            catch (Exception ex) { Logger.LogError("LoadDepartments failed", "TeacherForm", ex); }
        }

        private void DgvTeachers_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgvTeachers.SelectedRows.Count == 0) return;
            int id = Convert.ToInt32(dgvTeachers.SelectedRows[0].Cells["TeacherID"].Value);
            try
            {
                var dt = DatabaseHelper.ExecuteDataTable(
                    "SELECT * FROM Teachers WHERE TeacherID = @id",
                    new Dictionary<string, object> { { "@id", id } });
                if (dt.Rows.Count == 0) return;
                var row = dt.Rows[0];
                _editingID = id;
                txtFirstName.Text = row["FirstName"].ToString();
                txtLastName.Text = row["LastName"].ToString();
                txtEmail.Text = row["Email"].ToString();
                txtPhone.Text = row["Phone"]?.ToString() ?? "";
                txtQualification.Text = row["Qualification"]?.ToString() ?? "";
                txtSalary.Text = row["Salary"]?.ToString() ?? "";
                if (row["DateOfBirth"] != DBNull.Value) dtpDOB.Value = Convert.ToDateTime(row["DateOfBirth"]);
                dtpJoining.Value = Convert.ToDateTime(row["JoiningDate"]);
                try { cmbDepartment.SelectedValue = Convert.ToInt32(row["DepartmentID"]); } catch { }
                string gender = row["Gender"]?.ToString() ?? "Male";
                rdoMale.Checked = gender == "Male"; rdoFemale.Checked = gender == "Female";
                btnSave.Enabled = false; btnUpdate.Enabled = true; btnDelete.Enabled = true;
            }
            catch (Exception ex) { Logger.LogError("Load teacher for edit failed", "TeacherForm", ex); }
        }

        private int _editingID = -1;

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (!decimal.TryParse(txtSalary.Text, out decimal salary)) { MessageBox.Show("Invalid salary."); return; }
            var errors = Validator.ValidateTeacher(txtFirstName.Text, txtLastName.Text, txtEmail.Text, txtPhone.Text, salary);
            if (!Validator.ShowErrors(errors)) return;
            try
            {
                string query = @"INSERT INTO Teachers (FirstName, LastName, DateOfBirth, Gender, Email, Phone,
                    Qualification, JoiningDate, DepartmentID, Salary)
                    VALUES (@fn, @ln, @dob, @gender, @email, @phone, @qual, @join, @dept, @sal)";
                DatabaseHelper.ExecuteNonQuery(query, new Dictionary<string, object>
                {
                    {"@fn", txtFirstName.Text.Trim()}, {"@ln", txtLastName.Text.Trim()},
                    {"@dob", dtpDOB.Value}, {"@gender", rdoMale.Checked ? "Male" : "Female"},
                    {"@email", txtEmail.Text.Trim()}, {"@phone", txtPhone.Text.Trim()},
                    {"@qual", txtQualification.Text.Trim()}, {"@join", dtpJoining.Value},
                    {"@dept", cmbDepartment.SelectedValue!}, {"@sal", salary}
                });
                MessageBox.Show("Teacher added!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadTeachers(); ClearForm();
            }
            catch (Exception ex) { Logger.LogError("BtnSave_Click Teacher failed", "TeacherForm", ex); MessageBox.Show($"Error: {ex.Message}"); }
        }

        private void BtnUpdate_Click(object? sender, EventArgs e)
        {
            if (_editingID < 0 || !decimal.TryParse(txtSalary.Text, out decimal salary)) return;
            try
            {
                string query = @"UPDATE Teachers SET FirstName=@fn, LastName=@ln, Email=@email,
                    Phone=@phone, Qualification=@qual, JoiningDate=@join, DepartmentID=@dept, Salary=@sal
                    WHERE TeacherID=@id";
                DatabaseHelper.ExecuteNonQuery(query, new Dictionary<string, object>
                {
                    {"@fn", txtFirstName.Text.Trim()}, {"@ln", txtLastName.Text.Trim()},
                    {"@email", txtEmail.Text.Trim()}, {"@phone", txtPhone.Text.Trim()},
                    {"@qual", txtQualification.Text.Trim()}, {"@join", dtpJoining.Value},
                    {"@dept", cmbDepartment.SelectedValue!}, {"@sal", salary}, {"@id", _editingID}
                });
                MessageBox.Show("Teacher updated!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadTeachers(); ClearForm();
            }
            catch (Exception ex) { Logger.LogError("Update teacher failed", "TeacherForm", ex); MessageBox.Show($"Error: {ex.Message}"); }
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (_editingID < 0) return;
            if (MessageBox.Show("Deactivate this teacher?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DatabaseHelper.ExecuteNonQuery("UPDATE Teachers SET IsActive=0 WHERE TeacherID=@id",
                    new Dictionary<string, object> { { "@id", _editingID } });
                LoadTeachers(); ClearForm();
            }
        }

        private void ClearForm()
        {
            _editingID = -1;
            txtFirstName.Clear(); txtLastName.Clear(); txtEmail.Clear();
            txtPhone.Clear(); txtQualification.Clear(); txtSalary.Clear();
            rdoMale.Checked = true;
            dtpDOB.Value = DateTime.Today.AddYears(-30);
            dtpJoining.Value = DateTime.Today;
            if (cmbDepartment.Items.Count > 0) cmbDepartment.SelectedIndex = 0;
            btnSave.Enabled = true; btnUpdate.Enabled = false; btnDelete.Enabled = false;
        }
    }
}
