using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Utilities;

namespace SchoolManagementSystem.Forms
{
    public class TimetableForm : Form
    {
        private DataGridView dgv;
        private ComboBox cmbClass, cmbSubject, cmbTeacher, cmbDay, cmbAcYear;
        private DateTimePicker dtpStart, dtpEnd;
        private TextBox txtRoom;
        private Button btnSave, btnDelete, btnClear, btnFilter;
        private int _editID = -1;

        public TimetableForm()
        {
            InitializeComponent();
            LoadDropdowns();
            LoadTimetable();
        }

        private void InitializeComponent()
        {
            this.Text = "Timetable Management";
            this.Size = new Size(1050, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            var menu = new MenuStrip();
            var fm = new ToolStripMenuItem("File");
            fm.DropDownItems.Add("Close",null,(s,e)=>this.Close());
            menu.Items.Add(fm); this.Controls.Add(menu);

            var lblTitle = new Label { Text="Timetable Management", Font=new Font("Segoe UI",14,FontStyle.Bold), Location=new Point(10,38), AutoSize=true, ForeColor=Color.FromArgb(0,102,204) };

            // Filter bar
            var pnlFilter = new Panel { Location=new Point(10,70), Size=new Size(1020,45), BackColor=Color.FromArgb(235,245,255) };
            var lblFilter = new Label { Text="Filter by Class:", Location=new Point(10,13), AutoSize=true };
            var cmbFilterClass = new ComboBox { Location=new Point(110,10), Width=200, DropDownStyle=ComboBoxStyle.DropDownList };
            btnFilter = new Button { Text="Filter", Location=new Point(320,8), Width=80, BackColor=Color.FromArgb(0,102,204), ForeColor=Color.White, FlatStyle=FlatStyle.Flat };

            pnlFilter.Controls.AddRange(new Control[]{lblFilter, cmbFilterClass, btnFilter});

            // Form panel
            var pnlForm = new Panel { Location=new Point(10,125), Size=new Size(1020,110), BackColor=Color.FromArgb(248,249,250), BorderStyle=BorderStyle.FixedSingle };

            void AddField(string lbl, Control ctrl, int x)
            {
                pnlForm.Controls.Add(new Label { Text=lbl, Location=new Point(x,8), AutoSize=true });
                ctrl.Location=new Point(x,28); ctrl.Width=140; pnlForm.Controls.Add(ctrl);
            }

            cmbClass=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList}; AddField("Class:",cmbClass,10);
            cmbSubject=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList}; AddField("Subject:",cmbSubject,165);
            cmbTeacher=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList}; AddField("Teacher:",cmbTeacher,320);
            cmbDay=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList}; cmbDay.Items.AddRange(new string[]{"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"}); cmbDay.SelectedIndex=0; AddField("Day:",cmbDay,475);
            dtpStart=new DateTimePicker{Format=DateTimePickerFormat.Time,ShowUpDown=true}; AddField("Start Time:",dtpStart,620);
            dtpEnd=new DateTimePicker{Format=DateTimePickerFormat.Time,ShowUpDown=true}; AddField("End Time:",dtpEnd,775);
            txtRoom=new TextBox(); AddField("Room:",txtRoom,920);

            cmbAcYear=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList,Location=new Point(10,65),Width=140}; cmbAcYear.Items.AddRange(new string[]{"2023-24","2024-25","2025-26"}); cmbAcYear.SelectedIndex=1;
            pnlForm.Controls.Add(new Label{Text="Academic Year:",Location=new Point(10,50),AutoSize=true});
            pnlForm.Controls.Add(cmbAcYear);

            btnSave=Btn("💾 Add",Color.FromArgb(0,153,76),new Point(170,55)); btnSave.Click+=BtnSave_Click;
            btnDelete=Btn("🗑 Delete",Color.Red,new Point(290,55)); btnDelete.Click+=BtnDelete_Click; btnDelete.Enabled=false;
            btnClear=Btn("✕ Clear",Color.Gray,new Point(410,55)); btnClear.Click+=(s,e)=>ClearForm();
            pnlForm.Controls.AddRange(new Control[]{btnSave,btnDelete,btnClear});

            // Grid
            dgv=new DataGridView{Location=new Point(10,245),Size=new Size(1020,360),ReadOnly=true,SelectionMode=DataGridViewSelectionMode.FullRowSelect,AllowUserToAddRows=false,BackgroundColor=Color.White,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill};
            dgv.SelectionChanged+=Dgv_SelectionChanged;

            btnFilter.Click+=(s,e)=>{
                if(cmbFilterClass.SelectedValue==null){LoadTimetable();return;}
                var dt=DatabaseHelper.ExecuteDataTable("SELECT * FROM vw_ClassTimetable WHERE ClassName=(SELECT ClassName FROM Classes WHERE ClassID=@cid)",new Dictionary<string,object>{{"@cid",cmbFilterClass.SelectedValue}});
                dgv.DataSource=dt;
            };

            this.Controls.AddRange(new Control[]{menu,lblTitle,pnlFilter,pnlForm,dgv});

            // Load filter class dropdown
            try
            {
                var classes=DatabaseHelper.ExecuteDataTable("SELECT ClassID, ClassName FROM Classes WHERE IsActive=1");
                cmbFilterClass.DataSource=classes; cmbFilterClass.DisplayMember="ClassName"; cmbFilterClass.ValueMember="ClassID";
            }
            catch { }
        }

        private Button Btn(string t,Color c,Point loc)=>new Button{Text=t,Location=loc,Width=110,Height=32,BackColor=c,ForeColor=Color.White,FlatStyle=FlatStyle.Flat,Font=new Font("Segoe UI",9,FontStyle.Bold)};

        private void LoadDropdowns()
        {
            try
            {
                var classes=DatabaseHelper.ExecuteDataTable("SELECT ClassID,ClassName FROM Classes WHERE IsActive=1");
                cmbClass.DataSource=classes; cmbClass.DisplayMember="ClassName"; cmbClass.ValueMember="ClassID";

                var subs=DatabaseHelper.ExecuteDataTable("SELECT SubjectID,SubjectName FROM Subjects WHERE IsActive=1");
                cmbSubject.DataSource=subs; cmbSubject.DisplayMember="SubjectName"; cmbSubject.ValueMember="SubjectID";

                var teachers=DatabaseHelper.ExecuteDataTable("SELECT TeacherID,CONCAT(FirstName,' ',LastName) AS Name FROM Teachers WHERE IsActive=1");
                cmbTeacher.DataSource=teachers; cmbTeacher.DisplayMember="Name"; cmbTeacher.ValueMember="TeacherID";
            }
            catch (Exception ex){Logger.LogError("LoadDropdowns TimetableForm failed","TimetableForm",ex);}
        }

        private void LoadTimetable()
        {
            try { dgv.DataSource=DatabaseHelper.ExecuteDataTable("SELECT * FROM vw_ClassTimetable"); }
            catch (Exception ex){Logger.LogError("LoadTimetable failed","TimetableForm",ex);}
        }

        private void Dgv_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count==0) return;
            _editID=Convert.ToInt32(dgv.SelectedRows[0].Cells["TimetableID"].Value);
            btnDelete.Enabled=true;
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (cmbClass.SelectedValue==null||cmbSubject.SelectedValue==null||cmbTeacher.SelectedValue==null){MessageBox.Show("Fill all required fields.");return;}
            try
            {
                DatabaseHelper.ExecuteNonQuery(@"INSERT INTO Timetable (ClassID,SubjectID,TeacherID,DayOfWeek,StartTime,EndTime,RoomNumber,AcademicYear)
                    VALUES (@cls,@sub,@tea,@day,@start,@end,@room,@yr)",
                    new Dictionary<string,object>{{"@cls",cmbClass.SelectedValue!},{"@sub",cmbSubject.SelectedValue!},{"@tea",cmbTeacher.SelectedValue!},
                    {"@day",cmbDay.SelectedItem!},{"@start",dtpStart.Value.TimeOfDay},{"@end",dtpEnd.Value.TimeOfDay},
                    {"@room",txtRoom.Text.Trim()},{"@yr",cmbAcYear.SelectedItem!}});
                MessageBox.Show("Timetable entry added!","Success",MessageBoxButtons.OK,MessageBoxIcon.Information);
                LoadTimetable(); ClearForm();
            }
            catch (Exception ex){MessageBox.Show($"Error: {ex.Message}");}
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (_editID<0) return;
            if (MessageBox.Show("Delete this entry?","Confirm",MessageBoxButtons.YesNo)==DialogResult.Yes)
            {
                DatabaseHelper.ExecuteNonQuery("UPDATE Timetable SET IsActive=0 WHERE TimetableID=@id",new Dictionary<string,object>{{"@id",_editID}});
                LoadTimetable(); ClearForm();
            }
        }

        private void ClearForm()
        {
            _editID=-1; txtRoom.Clear(); cmbDay.SelectedIndex=0; btnDelete.Enabled=false;
        }
    }
}
