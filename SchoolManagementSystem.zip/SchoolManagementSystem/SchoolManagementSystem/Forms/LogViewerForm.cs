using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Utilities;

namespace SchoolManagementSystem.Forms
{
    public class LogViewerForm : Form
    {
        private DataGridView dgv;
        private ComboBox cmbLevel;
        private DateTimePicker dtpFrom, dtpTo;
        private Button btnFilter, btnClearLogs;
        private Label lblCount;

        public LogViewerForm()
        {
            InitializeComponent();
            LoadLogs();
        }

        private void InitializeComponent()
        {
            this.Text = "System Error Logs";
            this.Size = new Size(1000, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            var menu = new MenuStrip();
            var fm = new ToolStripMenuItem("File");
            fm.DropDownItems.Add("Export Logs",null,BtnExport_Click);
            fm.DropDownItems.Add("Close",null,(s,e)=>this.Close());
            menu.Items.Add(fm); this.Controls.Add(menu);

            var pnlTop = new Panel { Location=new Point(0,28), Size=new Size(990,50), BackColor=Color.FromArgb(235,245,255) };

            pnlTop.Controls.Add(new Label{Text="Level:",Location=new Point(10,15),AutoSize=true});
            cmbLevel=new ComboBox{Location=new Point(55,12),Width=120,DropDownStyle=ComboBoxStyle.DropDownList};
            cmbLevel.Items.AddRange(new string[]{"All","Info","Warning","Error","Critical"}); cmbLevel.SelectedIndex=0;
            pnlTop.Controls.Add(cmbLevel);

            pnlTop.Controls.Add(new Label{Text="From:",Location=new Point(190,15),AutoSize=true});
            dtpFrom=new DateTimePicker{Location=new Point(225,12),Width=140,Format=DateTimePickerFormat.Short,Value=DateTime.Today.AddDays(-7)};
            pnlTop.Controls.Add(dtpFrom);

            pnlTop.Controls.Add(new Label{Text="To:",Location=new Point(375,15),AutoSize=true});
            dtpTo=new DateTimePicker{Location=new Point(400,12),Width=140,Format=DateTimePickerFormat.Short,Value=DateTime.Today};
            pnlTop.Controls.Add(dtpTo);

            btnFilter=new Button{Text="🔍 Filter",Location=new Point(550,10),Width=100,BackColor=Color.FromArgb(0,102,204),ForeColor=Color.White,FlatStyle=FlatStyle.Flat};
            btnFilter.Click+=BtnFilter_Click;
            pnlTop.Controls.Add(btnFilter);

            btnClearLogs=new Button{Text="🗑 Clear Old",Location=new Point(660,10),Width=120,BackColor=Color.Red,ForeColor=Color.White,FlatStyle=FlatStyle.Flat};
            btnClearLogs.Click+=BtnClearLogs_Click;
            pnlTop.Controls.Add(btnClearLogs);

            lblCount=new Label{Text="",Location=new Point(800,15),AutoSize=true,ForeColor=Color.DarkBlue,Font=new Font("Segoe UI",9,FontStyle.Bold)};
            pnlTop.Controls.Add(lblCount);

            dgv=new DataGridView{Location=new Point(0,78),Size=new Size(990,480),ReadOnly=true,AllowUserToAddRows=false,BackgroundColor=Color.White,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill};
            dgv.RowPrePaint+=Dgv_RowPrePaint;

            this.Controls.AddRange(new Control[]{menu,pnlTop,dgv});
        }

        private void LoadLogs(string level="All", DateTime? from=null, DateTime? to=null)
        {
            try
            {
                string where = "WHERE 1=1";
                var p=new Dictionary<string,object>();
                if (level!="All"){where+=" AND LogLevel=@level"; p["@level"]=level;}
                if (from.HasValue){where+=" AND LoggedAt>=@from"; p["@from"]=from.Value;}
                if (to.HasValue){where+=" AND LoggedAt<=@to"; p["@to"]=to.Value.AddDays(1);}
                var dt=DatabaseHelper.ExecuteDataTable($"SELECT LogID, LogLevel, Module, Message, LoggedAt FROM ErrorLogs {where} ORDER BY LoggedAt DESC LIMIT 500", p);
                dgv.DataSource=dt;
                lblCount.Text=$"Showing {dt.Rows.Count} records";
            }
            catch (Exception ex){MessageBox.Show($"Error loading logs: {ex.Message}");}
        }

        private void BtnFilter_Click(object? sender, EventArgs e)
        {
            LoadLogs(cmbLevel.SelectedItem?.ToString()??"All", dtpFrom.Value.Date, dtpTo.Value.Date);
        }

        private void BtnClearLogs_Click(object? sender, EventArgs e)
        {
            if (MessageBox.Show("Delete all logs older than 30 days?","Confirm",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.Yes)
            {
                DatabaseHelper.ExecuteNonQuery("DELETE FROM ErrorLogs WHERE LoggedAt < DATE_SUB(NOW(), INTERVAL 30 DAY)");
                MessageBox.Show("Old logs cleared."); LoadLogs();
            }
        }

        private void BtnExport_Click(object? sender, EventArgs e)
        {
            try
            {
                var dt=DatabaseHelper.ExecuteDataTable("SELECT * FROM ErrorLogs ORDER BY LoggedAt DESC");
                string path=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop),"ErrorLogs.csv");
                var sb=new System.Text.StringBuilder();
                sb.AppendLine("LogID,LogLevel,Module,Message,LoggedAt");
                foreach (System.Data.DataRow r in dt.Rows)
                    sb.AppendLine($"{r["LogID"]},{r["LogLevel"]},{r["Module"]},\"{r["Message"]}\",{r["LoggedAt"]}");
                File.WriteAllText(path,sb.ToString());
                MessageBox.Show($"Exported to: {path}");
            }
            catch (Exception ex){MessageBox.Show($"Export error: {ex.Message}");}
        }

        private void Dgv_RowPrePaint(object? sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (e.RowIndex<0||dgv.Rows[e.RowIndex].Cells["LogLevel"].Value==null) return;
            string level=dgv.Rows[e.RowIndex].Cells["LogLevel"].Value.ToString()!;
            dgv.Rows[e.RowIndex].DefaultCellStyle.BackColor = level switch
            {
                "Error" => Color.FromArgb(255,230,230),
                "Critical" => Color.FromArgb(255,200,200),
                "Warning" => Color.FromArgb(255,255,204),
                _ => Color.White
            };
        }
    }
}
