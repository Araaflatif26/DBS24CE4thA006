using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Utilities;

namespace SchoolManagementSystem.Forms
{
    public class SubjectForm : Form
    {
        private DataGridView dgvSubjects;
        private TextBox txtName, txtCode;
        private NumericUpDown nudCredits;
        private ComboBox cmbDepartment;
        private CheckBox chkElective;
        private Button btnSave, btnUpdate, btnDelete, btnClear;
        private int _editID = -1;

        public SubjectForm()
        {
            InitializeComponent();
            LoadSubjects();
            LoadDepartments();
        }

        private void InitializeComponent()
        {
            this.Text = "Subject Management";
            this.Size = new Size(900, 560);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            var menu = new MenuStrip();
            var fm = new ToolStripMenuItem("File");
            fm.DropDownItems.Add("Close", null, (s,e)=>this.Close());
            menu.Items.Add(fm); this.Controls.Add(menu);

            var pnlList = new Panel { Location=new Point(0,28), Size=new Size(430,510), BorderStyle=BorderStyle.FixedSingle };
            var lbl = new Label { Text="Subjects", Font=new Font("Segoe UI",12,FontStyle.Bold), Location=new Point(10,8), AutoSize=true, ForeColor=Color.FromArgb(0,102,204) };
            dgvSubjects = new DataGridView { Location=new Point(10,38), Size=new Size(408,460), ReadOnly=true, SelectionMode=DataGridViewSelectionMode.FullRowSelect, AllowUserToAddRows=false, BackgroundColor=Color.White, AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill };
            dgvSubjects.SelectionChanged += Dgv_SelectionChanged;
            pnlList.Controls.AddRange(new Control[]{ lbl, dgvSubjects });

            var pnlForm = new Panel { Location=new Point(440,28), Size=new Size(450,510), BorderStyle=BorderStyle.FixedSingle };
            var lblT = new Label { Text="Subject Details", Font=new Font("Segoe UI",12,FontStyle.Bold), Location=new Point(10,8), AutoSize=true, ForeColor=Color.FromArgb(0,102,204) };

            int y=45;
            void Add(string label, Control ctrl, int width=400)
            {
                pnlForm.Controls.Add(new Label { Text=label, Location=new Point(10,y), AutoSize=true });
                ctrl.Location=new Point(10,y+20); ctrl.Width=width; pnlForm.Controls.Add(ctrl); y+=62;
            }

            txtName = new TextBox(); Add("Subject Name: *", txtName);
            txtCode = new TextBox(); Add("Subject Code: *", txtCode);
            nudCredits = new NumericUpDown { Minimum=1, Maximum=6, Value=3 }; Add("Credit Hours:", nudCredits, 100);
            cmbDepartment = new ComboBox { DropDownStyle=ComboBoxStyle.DropDownList }; Add("Department:", cmbDepartment);
            chkElective = new CheckBox { Text="Is Elective Subject", Location=new Point(10,y), AutoSize=true }; pnlForm.Controls.Add(chkElective); y+=40;

            btnSave = Btn("💾 Save", Color.FromArgb(0,153,76), new Point(10,y+10)); btnSave.Click += BtnSave_Click;
            btnUpdate = Btn("✏️ Update", Color.FromArgb(0,102,204), new Point(130,y+10)); btnUpdate.Click += BtnUpdate_Click; btnUpdate.Enabled=false;
            btnDelete = Btn("🗑 Delete", Color.Red, new Point(250,y+10)); btnDelete.Click += BtnDelete_Click; btnDelete.Enabled=false;
            btnClear = Btn("✕ Clear", Color.Gray, new Point(370,y+10)); btnClear.Click += (s,e)=>ClearForm();

            pnlForm.Controls.AddRange(new Control[]{ lblT, btnSave, btnUpdate, btnDelete, btnClear });
            this.Controls.AddRange(new Control[]{ menu, pnlList, pnlForm });
        }

        private Button Btn(string t, Color c, Point loc) => new Button { Text=t, Location=loc, Width=110, Height=34, BackColor=c, ForeColor=Color.White, FlatStyle=FlatStyle.Flat, Font=new Font("Segoe UI",9,FontStyle.Bold) };

        private void LoadSubjects()
        {
            try
            {
                
                // Simple approach:
                var dt2 = DatabaseHelper.ExecuteDataTable(@"SELECT s.SubjectID, s.SubjectName, s.SubjectCode, s.CreditHours, d.DepartmentName, IF(s.IsElective,'Yes','No') AS Elective FROM Subjects s JOIN Departments d ON s.DepartmentID=d.DepartmentID WHERE s.IsActive=1 ORDER BY s.SubjectName");
                dgvSubjects.DataSource = dt2;
            }
            catch (Exception ex) { Logger.LogError("LoadSubjects failed","SubjectForm",ex); }
        }

        private void LoadDepartments()
        {
            try
            {
                var d = DatabaseHelper.ExecuteDataTable("SELECT DepartmentID, DepartmentName FROM Departments WHERE IsActive=1");
                cmbDepartment.DataSource=d; cmbDepartment.DisplayMember="DepartmentName"; cmbDepartment.ValueMember="DepartmentID";
            }
            catch (Exception ex) { Logger.LogError("LoadDepartments SubjectForm failed","SubjectForm",ex); }
        }

        private void Dgv_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgvSubjects.SelectedRows.Count==0) return;
            _editID = Convert.ToInt32(dgvSubjects.SelectedRows[0].Cells["SubjectID"].Value);
            try
            {
                var dt = DatabaseHelper.ExecuteDataTable("SELECT * FROM Subjects WHERE SubjectID=@id", new Dictionary<string,object>{{"@id",_editID}});
                if (dt.Rows.Count==0) return;
                var r=dt.Rows[0];
                txtName.Text=r["SubjectName"].ToString();
                txtCode.Text=r["SubjectCode"].ToString();
                nudCredits.Value=Convert.ToDecimal(r["CreditHours"]);
                chkElective.Checked=Convert.ToBoolean(r["IsElective"]);
                try { cmbDepartment.SelectedValue=Convert.ToInt32(r["DepartmentID"]); } catch { }
                btnSave.Enabled=false; btnUpdate.Enabled=true; btnDelete.Enabled=true;
            }
            catch (Exception ex) { Logger.LogError("Dgv SubjectForm",ex.Message); }
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text)) { MessageBox.Show("Name required."); return; }
            try
            {
                DatabaseHelper.ExecuteNonQuery("INSERT INTO Subjects (SubjectName,SubjectCode,CreditHours,DepartmentID,IsElective) VALUES (@n,@c,@cr,@d,@e)",
                    new Dictionary<string,object>{{"@n",txtName.Text.Trim()},{"@c",txtCode.Text.Trim()},{"@cr",(int)nudCredits.Value},{"@d",cmbDepartment.SelectedValue!},{"@e",chkElective.Checked}});
                MessageBox.Show("Subject saved!","Success",MessageBoxButtons.OK,MessageBoxIcon.Information);
                LoadSubjects(); ClearForm();
            }
            catch (Exception ex) { MessageBox.Show($"Error: {ex.Message}"); }
        }

        private void BtnUpdate_Click(object? sender, EventArgs e)
        {
            if (_editID<0) return;
            try
            {
                DatabaseHelper.ExecuteNonQuery("UPDATE Subjects SET SubjectName=@n,SubjectCode=@c,CreditHours=@cr,DepartmentID=@d,IsElective=@e WHERE SubjectID=@id",
                    new Dictionary<string,object>{{"@n",txtName.Text.Trim()},{"@c",txtCode.Text.Trim()},{"@cr",(int)nudCredits.Value},{"@d",cmbDepartment.SelectedValue!},{"@e",chkElective.Checked},{"@id",_editID}});
                MessageBox.Show("Updated!","Success",MessageBoxButtons.OK,MessageBoxIcon.Information);
                LoadSubjects(); ClearForm();
            }
            catch (Exception ex) { MessageBox.Show($"Error: {ex.Message}"); }
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (_editID<0) return;
            if (MessageBox.Show("Delete subject?","Confirm",MessageBoxButtons.YesNo)==DialogResult.Yes)
            {
                DatabaseHelper.ExecuteNonQuery("UPDATE Subjects SET IsActive=0 WHERE SubjectID=@id", new Dictionary<string,object>{{"@id",_editID}});
                LoadSubjects(); ClearForm();
            }
        }

        private void ClearForm()
        {
            _editID=-1; txtName.Clear(); txtCode.Clear(); nudCredits.Value=3; chkElective.Checked=false;
            if (cmbDepartment.Items.Count>0) cmbDepartment.SelectedIndex=0;
            btnSave.Enabled=true; btnUpdate.Enabled=false; btnDelete.Enabled=false;
        }
    }
}
