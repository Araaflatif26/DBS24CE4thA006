using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Models;
using SchoolManagementSystem.Utilities;

namespace SchoolManagementSystem.Forms
{
    public class DashboardForm : Form
    {
        private MenuStrip menuStrip;
        private StatusStrip statusStrip;
        private ToolStripStatusLabel lblStatus, lblUser, lblTime;
        private Panel pnlDashboard;
        private System.Windows.Forms.Timer tmrClock;

        public DashboardForm()
        {
            InitializeComponent();
            LoadDashboardStats();
        }

        private void InitializeComponent()
        {
            this.Text = $"School Management System - {UserSession.Role} Dashboard";
            this.Size = new Size(1100, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 242, 245);

            // ---- Menu Strip ----
            menuStrip = new MenuStrip { BackColor = Color.FromArgb(0, 102, 204), ForeColor = Color.White };

            var studentMenu = new ToolStripMenuItem("👨‍🎓 Students") { ForeColor = Color.White };
            studentMenu.DropDownItems.Add("Manage Students", null, (s, e) => OpenForm(new StudentForm()));
            studentMenu.DropDownItems.Add("Attendance", null, (s, e) => OpenForm(new AttendanceForm()));
            studentMenu.DropDownItems.Add("Fee Management", null, (s, e) => OpenForm(new FeeManagementForm()));

            var teacherMenu = new ToolStripMenuItem("👨‍🏫 Teachers") { ForeColor = Color.White };
            teacherMenu.DropDownItems.Add("Manage Teachers", null, (s, e) => OpenForm(new TeacherForm()));
            teacherMenu.DropDownItems.Add("Timetable", null, (s, e) => OpenForm(new TimetableForm()));

            var academicMenu = new ToolStripMenuItem("📚 Academics") { ForeColor = Color.White };
            academicMenu.DropDownItems.Add("Classes", null, (s, e) => OpenForm(new ClassForm()));
            academicMenu.DropDownItems.Add("Subjects", null, (s, e) => OpenForm(new SubjectForm()));
            academicMenu.DropDownItems.Add("Exams & Results", null, (s, e) => OpenForm(new ExamForm()));

            var reportMenu = new ToolStripMenuItem("📊 Reports") { ForeColor = Color.White };
            reportMenu.DropDownItems.Add("Student Report", null, (s, e) => OpenForm(new ReportForm("Student")));
            reportMenu.DropDownItems.Add("Attendance Report", null, (s, e) => OpenForm(new ReportForm("Attendance")));
            reportMenu.DropDownItems.Add("Fee Report", null, (s, e) => OpenForm(new ReportForm("Fee")));
            reportMenu.DropDownItems.Add("Exam Results Report", null, (s, e) => OpenForm(new ReportForm("Exam")));

            var adminMenu = new ToolStripMenuItem("⚙️ Admin") { ForeColor = Color.White };
            adminMenu.DropDownItems.Add("Departments", null, (s, e) => OpenForm(new DepartmentForm()));
            adminMenu.DropDownItems.Add("Announcements", null, (s, e) => OpenForm(new AnnouncementForm()));
            adminMenu.DropDownItems.Add("Error Logs", null, (s, e) => OpenForm(new LogViewerForm()));

            var logoutMenu = new ToolStripMenuItem("🚪 Logout") { ForeColor = Color.White };
            logoutMenu.Click += (s, e) => {
                Logger.LogInfo($"User {UserSession.Username} logged out.", "Auth");
                UserSession.Clear();
                new LoginForm().Show();
                this.Close();
            };

            menuStrip.Items.AddRange(new ToolStripItem[] {
                studentMenu, teacherMenu, academicMenu, reportMenu, adminMenu, logoutMenu
            });

            // ---- Status Strip ----
            statusStrip = new StatusStrip { BackColor = Color.FromArgb(0, 102, 204) };
            lblUser = new ToolStripStatusLabel($"Logged in as: {UserSession.Username} ({UserSession.Role})")
            { ForeColor = Color.White };
            lblStatus = new ToolStripStatusLabel("Ready") { Spring = true, ForeColor = Color.LightGreen };
            lblTime = new ToolStripStatusLabel(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")) { ForeColor = Color.White };
            statusStrip.Items.AddRange(new ToolStripItem[] { lblUser, lblStatus, lblTime });

            // Clock
            tmrClock = new System.Windows.Forms.Timer { Interval = 1000 };
            tmrClock.Tick += (s, e) => lblTime.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            tmrClock.Start();

            // ---- Dashboard Panel ----
            pnlDashboard = new Panel { Dock = DockStyle.Fill, Padding = new Padding(20) };

            var lblWelcome = new Label
            {
                Text = $"Welcome, {UserSession.Username}!",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 102, 204),
                Location = new Point(20, 30),
                AutoSize = true
            };

            pnlDashboard.Controls.Add(lblWelcome);

            // Stats cards will be added in LoadDashboardStats
            this.Controls.AddRange(new Control[] { menuStrip, pnlDashboard, statusStrip });
            this.MainMenuStrip = menuStrip;
        }

        private void LoadDashboardStats()
        {
            try
            {
                int[] y = { 90, 150, 210, 270, 330 };
                string[] queries = {
                    "SELECT COUNT(*) FROM Students WHERE IsActive=1",
                    "SELECT COUNT(*) FROM Teachers WHERE IsActive=1",
                    "SELECT COUNT(*) FROM Classes WHERE IsActive=1",
                    "SELECT COUNT(*) FROM Subjects WHERE IsActive=1",
                    "SELECT COALESCE(SUM(AmountPaid),0) FROM FeePayments WHERE YEAR(PaymentDate)=YEAR(NOW())"
                };
                string[] labels = { "Total Students", "Total Teachers", "Total Classes", "Total Subjects", "Fee Collected (This Year)" };
                Color[] colors = {
                    Color.FromArgb(0, 153, 76),
                    Color.FromArgb(0, 102, 204),
                    Color.FromArgb(153, 51, 255),
                    Color.FromArgb(204, 102, 0),
                    Color.FromArgb(0, 153, 153)
                };

                for (int i = 0; i < queries.Length; i++)
                {
                    var val = DatabaseHelper.ExecuteScalar(queries[i])?.ToString() ?? "0";
                    CreateStatCard(labels[i], val, colors[i], new Point(20 + (i % 3) * 230, 80 + (i / 3) * 130));
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Dashboard stats load failed", "Dashboard", ex);
            }
        }

        private void CreateStatCard(string title, string value, Color color, Point location)
        {
            var card = new Panel
            {
                Location = location,
                Size = new Size(210, 110),
                BackColor = color,
                BorderStyle = BorderStyle.None
            };

            var lblVal = new Label
            {
                Text = value,
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(10, 10),
                AutoSize = true
            };

            var lblTitle = new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.White,
                Location = new Point(10, 65),
                AutoSize = true
            };

            card.Controls.AddRange(new Control[] { lblVal, lblTitle });
            pnlDashboard.Controls.Add(card);
        }

        private void OpenForm(Form form)
        {
            form.MdiParent = null;
            form.StartPosition = FormStartPosition.CenterParent;
            form.ShowDialog();
        }
    }
}
