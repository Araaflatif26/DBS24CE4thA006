using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Utilities;

namespace SchoolManagementSystem.Forms
{
    public class AnnouncementForm : Form
    {
        private DataGridView dgv;
        private TextBox txtTitle;
        private RichTextBox rtbContent;
        private ComboBox cmbAudience;
        private DateTimePicker dtpExpiry;
        private CheckBox chkHasExpiry;
        private Button btnSave, btnDelete, btnClear;
        private int _editID = -1;

        public AnnouncementForm()
        {
            InitializeComponent();
            LoadAnnouncements();
        }

        private void InitializeComponent()
        {
            this.Text = "Announcements";
            this.Size = new Size(950, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            var menu = new MenuStrip();
            var fm = new ToolStripMenuItem("File");
            fm.DropDownItems.Add("Close",null,(s,e)=>this.Close());
            menu.Items.Add(fm); this.Controls.Add(menu);

            var pnlL = new Panel { Location=new Point(0,28), Size=new Size(450,550), BorderStyle=BorderStyle.FixedSingle };
            var lbl = new Label { Text="Announcements", Font=new Font("Segoe UI",12,FontStyle.Bold), Location=new Point(10,8), AutoSize=true, ForeColor=Color.FromArgb(0,102,204) };
            dgv = new DataGridView { Location=new Point(10,38), Size=new Size(428,500), ReadOnly=true, SelectionMode=DataGridViewSelectionMode.FullRowSelect, AllowUserToAddRows=false, BackgroundColor=Color.White, AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill };
            dgv.SelectionChanged += Dgv_SelectionChanged;
            pnlL.Controls.AddRange(new Control[]{lbl,dgv});

            var pnlR = new Panel { Location=new Point(460,28), Size=new Size(480,550), BorderStyle=BorderStyle.FixedSingle };
            var lblT = new Label { Text="New Announcement", Font=new Font("Segoe UI",12,FontStyle.Bold), Location=new Point(10,8), AutoSize=true, ForeColor=Color.FromArgb(0,102,204) };

            pnlR.Controls.Add(new Label{Text="Title: *",Location=new Point(10,40),AutoSize=true});
            txtTitle=new TextBox{Location=new Point(10,60),Width=450}; pnlR.Controls.Add(txtTitle);

            pnlR.Controls.Add(new Label{Text="Content: *",Location=new Point(10,95),AutoSize=true});
            rtbContent=new RichTextBox{Location=new Point(10,115),Width=450,Height=200,ScrollBars=RichTextBoxScrollBars.Vertical}; pnlR.Controls.Add(rtbContent);

            pnlR.Controls.Add(new Label{Text="Target Audience:",Location=new Point(10,330),AutoSize=true});
            cmbAudience=new ComboBox{Location=new Point(10,350),Width=220,DropDownStyle=ComboBoxStyle.DropDownList};
            cmbAudience.Items.AddRange(new string[]{"All","Students","Teachers","Parents"}); cmbAudience.SelectedIndex=0;
            pnlR.Controls.Add(cmbAudience);

            chkHasExpiry=new CheckBox{Text="Set Expiry Date",Location=new Point(10,395),AutoSize=true}; pnlR.Controls.Add(chkHasExpiry);
            dtpExpiry=new DateTimePicker{Location=new Point(10,418),Width=220,Format=DateTimePickerFormat.Short,Enabled=false}; pnlR.Controls.Add(dtpExpiry);
            chkHasExpiry.CheckedChanged+=(s,e)=>dtpExpiry.Enabled=chkHasExpiry.Checked;

            btnSave=Btn("📢 Post",Color.FromArgb(0,102,204),new Point(10,460)); btnSave.Click+=BtnSave_Click;
            btnDelete=Btn("🗑 Delete",Color.Red,new Point(130,460)); btnDelete.Click+=BtnDelete_Click; btnDelete.Enabled=false;
            btnClear=Btn("✕ Clear",Color.Gray,new Point(250,460)); btnClear.Click+=(s,e)=>ClearForm();

            pnlR.Controls.AddRange(new Control[]{lblT,btnSave,btnDelete,btnClear});
            this.Controls.AddRange(new Control[]{menu,pnlL,pnlR});
        }

        private Button Btn(string t,Color c,Point loc)=>new Button{Text=t,Location=loc,Width=110,Height=34,BackColor=c,ForeColor=Color.White,FlatStyle=FlatStyle.Flat,Font=new Font("Segoe UI",9,FontStyle.Bold)};

        private void LoadAnnouncements()
        {
            try { dgv.DataSource=DatabaseHelper.ExecuteDataTable("SELECT AnnouncementID, Title, TargetAudience, PublishDate FROM Announcements WHERE IsActive=1 ORDER BY PublishDate DESC"); }
            catch (Exception ex){Logger.LogError("LoadAnnouncements failed","AnnouncementForm",ex);}
        }

        private void Dgv_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count==0) return;
            _editID=Convert.ToInt32(dgv.SelectedRows[0].Cells["AnnouncementID"].Value);
            try
            {
                var dt=DatabaseHelper.ExecuteDataTable("SELECT * FROM Announcements WHERE AnnouncementID=@id",new Dictionary<string,object>{{"@id",_editID}});
                if (dt.Rows.Count==0) return;
                var r=dt.Rows[0];
                txtTitle.Text=r["Title"].ToString();
                rtbContent.Text=r["Content"].ToString();
                cmbAudience.SelectedItem=r["TargetAudience"].ToString();
                btnDelete.Enabled=true;
            }
            catch { }
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text)||string.IsNullOrWhiteSpace(rtbContent.Text)){MessageBox.Show("Title and content required.");return;}
            try
            {
                object expiry = chkHasExpiry.Checked ? (object)dtpExpiry.Value.Date : DBNull.Value;
                DatabaseHelper.ExecuteNonQuery(@"INSERT INTO Announcements (Title,Content,TargetAudience,PublishedByUserID,ExpiryDate)
                    VALUES (@t,@c,@aud,@uid,@exp)",
                    new Dictionary<string,object>{{"@t",txtTitle.Text.Trim()},{"@c",rtbContent.Text.Trim()},
                    {"@aud",cmbAudience.SelectedItem!},{"@uid",Models.UserSession.UserID},{"@exp",expiry}});
                MessageBox.Show("Announcement posted!","Success",MessageBoxButtons.OK,MessageBoxIcon.Information);
                LoadAnnouncements(); ClearForm();
            }
            catch (Exception ex){MessageBox.Show($"Error: {ex.Message}");}
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (_editID<0) return;
            if (MessageBox.Show("Delete announcement?","Confirm",MessageBoxButtons.YesNo)==DialogResult.Yes)
            {
                DatabaseHelper.ExecuteNonQuery("UPDATE Announcements SET IsActive=0 WHERE AnnouncementID=@id",new Dictionary<string,object>{{"@id",_editID}});
                LoadAnnouncements(); ClearForm();
            }
        }

        private void ClearForm()
        {
            _editID=-1; txtTitle.Clear(); rtbContent.Clear(); cmbAudience.SelectedIndex=0; chkHasExpiry.Checked=false;
            btnDelete.Enabled=false;
        }
    }
}
