using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Models;
using SchoolManagementSystem.Utilities;
using SchoolManagementSystem.Validators;

namespace SchoolManagementSystem.Forms
{
    public class StudentForm : Form
    {
        // Left panel - list/search
        private Panel pnlList, pnlDetail;
        private DataGridView dgvStudents;
        private TextBox txtSearch;
        private Button btnSearch, btnNew, btnRefresh;
        private ComboBox cmbFilterClass;
        private Label lblFilter;

        // Detail form (same form for add/edit)
        private TabControl tabControl;
        private TabPage tabPersonal, tabAcademic, tabGuardian;

        // Personal Info
        private TextBox txtFirstName, txtLastName, txtEmail, txtPhone, txtAddress;
        private DateTimePicker dtpDOB, dtpEnrollment;
        private RadioButton rdoMale, rdoFemale, rdoOther;
        private Label lblFN, lblLN, lblDOB, lblGender, lblEmail, lblPhone, lblAddress, lblEnroll;

        // Academic
        private ComboBox cmbClass, cmbDepartment;
        private Label lblClass, lblDept;

        // Guardian
        private TextBox txtGuardianName, txtGuardianPhone;
        private Label lblGName, lblGPhone;

        // Buttons
        private Button btnSave, btnUpdate, btnDelete, btnCancel;
        private Panel pnlButtons;

        private StudentDAL _dal = new StudentDAL();
        private int _editingStudentID = -1;

        public StudentForm()
        {
            InitializeComponent();
            LoadStudents();
            LoadDropdowns();
        }

        private void InitializeComponent()
        {
            this.Text = "Student Management";
            this.Size = new Size(1200, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(245, 245, 245);

            // ---- File Menu ----
            var menu = new MenuStrip();
            var fileMenu = new ToolStripMenuItem("File");
            fileMenu.DropDownItems.Add("New Student", null, (s, e) => ClearForm());
            fileMenu.DropDownItems.Add("Export to CSV", null, BtnExport_Click);
            fileMenu.DropDownItems.Add(new ToolStripSeparator());
            fileMenu.DropDownItems.Add("Close", null, (s, e) => this.Close());
            menu.Items.Add(fileMenu);
            this.Controls.Add(menu);

            // ---- Left Panel (List) ----
            pnlList = new Panel
            {
                Location = new Point(0, 30),
                Size = new Size(480, 640),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            var lblListTitle = new Label
            {
                Text = "Student List",
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                Location = new Point(10, 10),
                AutoSize = true,
                ForeColor = Color.FromArgb(0, 102, 204)
            };

            txtSearch = new TextBox { Location = new Point(10, 45), Width = 280, Height = 28, Font = new Font("Segoe UI", 10) };
            txtSearch.PlaceholderText = "Search by name or email...";

            btnSearch = new Button
            {
                Text = "Search",
                Location = new Point(295, 43),
                Width = 80,
                BackColor = Color.FromArgb(0, 102, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnSearch.Click += (s, e) => SearchStudents();

            lblFilter = new Label { Text = "Filter by Class:", Location = new Point(10, 82), AutoSize = true };
            cmbFilterClass = new ComboBox
            {
                Location = new Point(110, 79),
                Width = 200,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbFilterClass.SelectedIndexChanged += (s, e) => FilterByClass();

            btnRefresh = new Button
            {
                Text = "↺",
                Location = new Point(320, 79),
                Width = 40,
                BackColor = Color.LightGray,
                FlatStyle = FlatStyle.Flat
            };
            btnRefresh.Click += (s, e) => LoadStudents();

            btnNew = new Button
            {
                Text = "+ New Student",
                Location = new Point(10, 540),
                Width = 150,
                Height = 35,
                BackColor = Color.FromArgb(0, 153, 76),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat
            };
            btnNew.Click += (s, e) => ClearForm();

            dgvStudents = new DataGridView
            {
                Location = new Point(10, 115),
                Size = new Size(455, 415),
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AllowUserToAddRows = false,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            dgvStudents.SelectionChanged += DgvStudents_SelectionChanged;

            pnlList.Controls.AddRange(new Control[] {
                lblListTitle, txtSearch, btnSearch, lblFilter, cmbFilterClass,
                btnRefresh, dgvStudents, btnNew
            });

            // ---- Right Panel (Detail) ----
            pnlDetail = new Panel
            {
                Location = new Point(490, 30),
                Size = new Size(680, 640),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            var lblDetailTitle = new Label
            {
                Text = "Student Details",
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                Location = new Point(10, 10),
                AutoSize = true,
                ForeColor = Color.FromArgb(0, 102, 204)
            };

            tabControl = new TabControl
            {
                Location = new Point(10, 40),
                Size = new Size(655, 500)
            };

            // Personal Tab
            tabPersonal = new TabPage("Personal Information");
            int lx = 20, rx = 340, ty = 20;

            lblFN = new Label { Text = "First Name: *", Location = new Point(lx, ty), AutoSize = true };
            txtFirstName = new TextBox { Location = new Point(lx, ty + 22), Width = 280 };

            lblLN = new Label { Text = "Last Name: *", Location = new Point(rx, ty), AutoSize = true };
            txtLastName = new TextBox { Location = new Point(rx, ty + 22), Width = 280 };

            lblDOB = new Label { Text = "Date of Birth: *", Location = new Point(lx, ty + 65), AutoSize = true };
            dtpDOB = new DateTimePicker { Location = new Point(lx, ty + 87), Width = 280, Format = DateTimePickerFormat.Short };

            lblGender = new Label { Text = "Gender: *", Location = new Point(rx, ty + 65), AutoSize = true };
            rdoMale = new RadioButton { Text = "Male", Location = new Point(rx, ty + 87), Checked = true, AutoSize = true };
            rdoFemale = new RadioButton { Text = "Female", Location = new Point(rx + 70, ty + 87), AutoSize = true };
            rdoOther = new RadioButton { Text = "Other", Location = new Point(rx + 145, ty + 87), AutoSize = true };

            lblEmail = new Label { Text = "Email: *", Location = new Point(lx, ty + 130), AutoSize = true };
            txtEmail = new TextBox { Location = new Point(lx, ty + 152), Width = 280 };

            lblPhone = new Label { Text = "Phone: *", Location = new Point(rx, ty + 130), AutoSize = true };
            txtPhone = new TextBox { Location = new Point(rx, ty + 152), Width = 280 };

            lblEnroll = new Label { Text = "Enrollment Date:", Location = new Point(lx, ty + 195), AutoSize = true };
            dtpEnrollment = new DateTimePicker { Location = new Point(lx, ty + 217), Width = 280, Format = DateTimePickerFormat.Short };

            lblAddress = new Label { Text = "Address:", Location = new Point(lx, ty + 260), AutoSize = true };
            txtAddress = new TextBox { Location = new Point(lx, ty + 282), Width = 600, Height = 60, Multiline = true, ScrollBars = ScrollBars.Vertical };

            tabPersonal.Controls.AddRange(new Control[] {
                lblFN, txtFirstName, lblLN, txtLastName,
                lblDOB, dtpDOB, lblGender, rdoMale, rdoFemale, rdoOther,
                lblEmail, txtEmail, lblPhone, txtPhone,
                lblEnroll, dtpEnrollment, lblAddress, txtAddress
            });

            // Academic Tab
            tabAcademic = new TabPage("Academic Information");
            lblClass = new Label { Text = "Class: *", Location = new Point(20, 30), AutoSize = true };
            cmbClass = new ComboBox { Location = new Point(20, 52), Width = 280, DropDownStyle = ComboBoxStyle.DropDownList };

            lblDept = new Label { Text = "Department: *", Location = new Point(340, 30), AutoSize = true };
            cmbDepartment = new ComboBox { Location = new Point(340, 52), Width = 280, DropDownStyle = ComboBoxStyle.DropDownList };

            tabAcademic.Controls.AddRange(new Control[] { lblClass, cmbClass, lblDept, cmbDepartment });

            // Guardian Tab
            tabGuardian = new TabPage("Guardian Information");
            lblGName = new Label { Text = "Guardian Name:", Location = new Point(20, 30), AutoSize = true };
            txtGuardianName = new TextBox { Location = new Point(20, 52), Width = 280 };

            lblGPhone = new Label { Text = "Guardian Phone:", Location = new Point(340, 30), AutoSize = true };
            txtGuardianPhone = new TextBox { Location = new Point(340, 52), Width = 280 };

            tabGuardian.Controls.AddRange(new Control[] { lblGName, txtGuardianName, lblGPhone, txtGuardianPhone });

            tabControl.TabPages.AddRange(new TabPage[] { tabPersonal, tabAcademic, tabGuardian });

            // Buttons Panel
            pnlButtons = new Panel { Location = new Point(10, 555), Size = new Size(655, 60) };

            btnSave = new Button { Text = "💾 Save", Location = new Point(0, 10), Width = 120, Height = 38, BackColor = Color.FromArgb(0, 153, 76), ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold), FlatStyle = FlatStyle.Flat };
            btnSave.Click += BtnSave_Click;

            btnUpdate = new Button { Text = "✏️ Update", Location = new Point(130, 10), Width = 120, Height = 38, BackColor = Color.FromArgb(0, 102, 204), ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold), FlatStyle = FlatStyle.Flat, Enabled = false };
            btnUpdate.Click += BtnUpdate_Click;

            btnDelete = new Button { Text = "🗑 Deactivate", Location = new Point(260, 10), Width = 130, Height = 38, BackColor = Color.FromArgb(204, 0, 0), ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold), FlatStyle = FlatStyle.Flat, Enabled = false };
            btnDelete.Click += BtnDelete_Click;

            btnCancel = new Button { Text = "✕ Cancel", Location = new Point(400, 10), Width = 100, Height = 38, BackColor = Color.Gray, ForeColor = Color.White, Font = new Font("Segoe UI", 10), FlatStyle = FlatStyle.Flat };
            btnCancel.Click += (s, e) => ClearForm();

            pnlButtons.Controls.AddRange(new Control[] { btnSave, btnUpdate, btnDelete, btnCancel });

            pnlDetail.Controls.AddRange(new Control[] { lblDetailTitle, tabControl, pnlButtons });
            this.Controls.AddRange(new Control[] { pnlList, pnlDetail });
        }

        private void LoadStudents()
        {
            try
            {
                var dt = DatabaseHelper.ExecuteDataTable(
                    "SELECT StudentID, FullName, Gender, ClassName, DepartmentName, Email FROM vw_StudentDetails WHERE IsActive=1");
                dgvStudents.DataSource = dt;
                Logger.LogInfo("Student list loaded.", "StudentForm");
            }
            catch (Exception ex) { Logger.LogError("LoadStudents failed", "StudentForm", ex); }
        }

        private void LoadDropdowns()
        {
            try
            {
                var classes = DatabaseHelper.ExecuteDataTable("SELECT ClassID, ClassName FROM Classes WHERE IsActive=1");
                cmbClass.DataSource = classes;
                cmbClass.DisplayMember = "ClassName";
                cmbClass.ValueMember = "ClassID";

                cmbFilterClass.DataSource = DatabaseHelper.ExecuteDataTable("SELECT ClassID, ClassName FROM Classes WHERE IsActive=1");
                cmbFilterClass.DisplayMember = "ClassName";
                cmbFilterClass.ValueMember = "ClassID";

                var depts = DatabaseHelper.ExecuteDataTable("SELECT DepartmentID, DepartmentName FROM Departments WHERE IsActive=1");
                cmbDepartment.DataSource = depts;
                cmbDepartment.DisplayMember = "DepartmentName";
                cmbDepartment.ValueMember = "DepartmentID";
            }
            catch (Exception ex) { Logger.LogError("LoadDropdowns failed", "StudentForm", ex); }
        }

        private void DgvStudents_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgvStudents.SelectedRows.Count == 0) return;
            var row = dgvStudents.SelectedRows[0];
            int studentID = Convert.ToInt32(row.Cells["StudentID"].Value);
            LoadStudentForEdit(studentID);
        }

        private void LoadStudentForEdit(int studentID)
        {
            try
            {
                var s = _dal.GetStudentByID(studentID);
                if (s == null) return;
                _editingStudentID = studentID;

                txtFirstName.Text = s.FirstName;
                txtLastName.Text = s.LastName;
                dtpDOB.Value = s.DateOfBirth;
                txtEmail.Text = s.Email;
                txtPhone.Text = s.Phone;
                txtAddress.Text = s.Address;
                dtpEnrollment.Value = s.EnrollmentDate;
                txtGuardianName.Text = s.GuardianName;
                txtGuardianPhone.Text = s.GuardianPhone;

                if (s.Gender == "Male") rdoMale.Checked = true;
                else if (s.Gender == "Female") rdoFemale.Checked = true;
                else rdoOther.Checked = true;

                try { cmbClass.SelectedValue = s.ClassID; } catch { }
                try { cmbDepartment.SelectedValue = s.DepartmentID; } catch { }

                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }
            catch (Exception ex) { Logger.LogError("LoadStudentForEdit failed", "StudentForm", ex); }
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            try
            {
                var errors = Validator.ValidateStudent(
                    txtFirstName.Text, txtLastName.Text, txtEmail.Text, txtPhone.Text,
                    dtpDOB.Value, cmbClass.SelectedIndex >= 0 ? (int)cmbClass.SelectedValue! : 0,
                    cmbDepartment.SelectedIndex >= 0 ? (int)cmbDepartment.SelectedValue! : 0);

                if (!Validator.ShowErrors(errors)) return;

                var s = BuildStudentFromForm();
                if (_dal.AddStudent(s, out string msg))
                {
                    MessageBox.Show("Student added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadStudents();
                    ClearForm();
                }
                else
                    MessageBox.Show($"Failed to add student: {msg}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex) { Logger.LogError("BtnSave_Click failed", "StudentForm", ex); }
        }

        private void BtnUpdate_Click(object? sender, EventArgs e)
        {
            try
            {
                if (_editingStudentID < 0) return;
                var errors = Validator.ValidateStudent(
                    txtFirstName.Text, txtLastName.Text, txtEmail.Text, txtPhone.Text,
                    dtpDOB.Value, (int)cmbClass.SelectedValue!, (int)cmbDepartment.SelectedValue!);

                if (!Validator.ShowErrors(errors)) return;

                var s = BuildStudentFromForm();
                s.StudentID = _editingStudentID;

                if (_dal.UpdateStudent(s, out string msg))
                {
                    MessageBox.Show("Student updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadStudents();
                    ClearForm();
                }
                else
                    MessageBox.Show($"Failed to update: {msg}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex) { Logger.LogError("BtnUpdate_Click failed", "StudentForm", ex); }
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (_editingStudentID < 0) return;
            var result = MessageBox.Show("Are you sure you want to deactivate this student?",
                "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result != DialogResult.Yes) return;

            if (_dal.DeactivateStudent(_editingStudentID, out string msg))
            {
                MessageBox.Show("Student deactivated.", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadStudents();
                ClearForm();
            }
            else
                MessageBox.Show($"Error: {msg}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void BtnExport_Click(object? sender, EventArgs e)
        {
            try
            {
                var dt = DatabaseHelper.ExecuteDataTable("SELECT * FROM vw_StudentDetails WHERE IsActive=1");
                string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Students.csv");
                var sb = new System.Text.StringBuilder();
                sb.AppendLine(string.Join(",", dt.Columns.Cast<System.Data.DataColumn>().Select(c => c.ColumnName)));
                foreach (System.Data.DataRow row in dt.Rows)
                    sb.AppendLine(string.Join(",", row.ItemArray.Select(v => $"\"{v}\"")));
                File.WriteAllText(path, sb.ToString());
                MessageBox.Show($"Exported to: {path}", "Exported", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { Logger.LogError("Export failed", "StudentForm", ex); }
        }

        private void SearchStudents()
        {
            if (string.IsNullOrWhiteSpace(txtSearch.Text)) { LoadStudents(); return; }
            var dt = _dal.SearchStudents(txtSearch.Text);
            dgvStudents.DataSource = dt;
        }

        private void FilterByClass()
        {
            if (cmbFilterClass.SelectedValue == null) return;
            var dt = _dal.GetStudentsByClass((int)cmbFilterClass.SelectedValue);
            dgvStudents.DataSource = dt;
        }

        private Student BuildStudentFromForm() => new Student
        {
            FirstName = txtFirstName.Text.Trim(),
            LastName = txtLastName.Text.Trim(),
            DateOfBirth = dtpDOB.Value,
            Gender = rdoMale.Checked ? "Male" : rdoFemale.Checked ? "Female" : "Other",
            Email = txtEmail.Text.Trim(),
            Phone = txtPhone.Text.Trim(),
            Address = txtAddress.Text.Trim(),
            EnrollmentDate = dtpEnrollment.Value,
            ClassID = cmbClass.SelectedValue != null ? (int)cmbClass.SelectedValue : 0,
            DepartmentID = cmbDepartment.SelectedValue != null ? (int)cmbDepartment.SelectedValue : 0,
            GuardianName = txtGuardianName.Text.Trim(),
            GuardianPhone = txtGuardianPhone.Text.Trim()
        };

        private void ClearForm()
        {
            _editingStudentID = -1;
            txtFirstName.Clear(); txtLastName.Clear(); txtEmail.Clear();
            txtPhone.Clear(); txtAddress.Clear(); txtGuardianName.Clear(); txtGuardianPhone.Clear();
            dtpDOB.Value = DateTime.Today.AddYears(-14);
            dtpEnrollment.Value = DateTime.Today;
            rdoMale.Checked = true;
            if (cmbClass.Items.Count > 0) cmbClass.SelectedIndex = 0;
            if (cmbDepartment.Items.Count > 0) cmbDepartment.SelectedIndex = 0;
            btnSave.Enabled = true;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
        }
    }
}
