using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Utilities;

namespace SchoolManagementSystem.Forms
{
    public class ExamForm : Form
    {
        private TabControl tabControl;
        private TabPage tabExams, tabResults;

        // Exams Tab
        private DataGridView dgvExams;
        private TextBox txtExamName, txtTotalMarks, txtPassingMarks, txtDuration;
        private ComboBox cmbExamType, cmbSubject, cmbClass;
        private DateTimePicker dtpExamDate;
        private Button btnSaveExam, btnUpdateExam, btnDeleteExam, btnClearExam;

        // Results Tab
        private DataGridView dgvResults;
        private ComboBox cmbExam;
        private Button btnLoadStudents, btnSaveResults;

        private int _editExamID = -1;

        public ExamForm()
        {
            InitializeComponent();
            LoadDropdowns();
            LoadExams();
        }

        private void InitializeComponent()
        {
            this.Text = "Exam & Results Management";
            this.Size = new Size(1000, 680);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            var menu = new MenuStrip();
            var fileMenu = new ToolStripMenuItem("File");
            fileMenu.DropDownItems.Add("Close", null, (s, e) => this.Close());
            menu.Items.Add(fileMenu);
            this.Controls.Add(menu);

            tabControl = new TabControl { Location = new Point(5, 30), Size = new Size(985, 630) };
            tabExams = new TabPage("📝 Exams");
            tabResults = new TabPage("📊 Enter Results");

            BuildExamsTab();
            BuildResultsTab();

            tabControl.TabPages.AddRange(new TabPage[] { tabExams, tabResults });
            this.Controls.Add(tabControl);
        }

        private void BuildExamsTab()
        {
            // Left: list
            var dgvPanel = new Panel { Location = new Point(0, 0), Size = new Size(450, 590), BorderStyle = BorderStyle.FixedSingle };
            dgvExams = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AllowUserToAddRows = false,
                BackgroundColor = Color.White,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            dgvExams.SelectionChanged += DgvExams_SelectionChanged;
            dgvPanel.Controls.Add(dgvExams);

            // Right: form
            var formPanel = new Panel { Location = new Point(460, 0), Size = new Size(510, 590) };
            int y = 10;

            void AddRow(string label1, Control ctrl1, string label2, Control ctrl2)
            {
                formPanel.Controls.Add(new Label { Text = label1, Location = new Point(10, y), AutoSize = true });
                ctrl1.Location = new Point(10, y + 22); ctrl1.Width = 220;
                formPanel.Controls.Add(ctrl1);
                formPanel.Controls.Add(new Label { Text = label2, Location = new Point(260, y), AutoSize = true });
                ctrl2.Location = new Point(260, y + 22); ctrl2.Width = 220;
                formPanel.Controls.Add(ctrl2);
                y += 65;
            }

            txtExamName = new TextBox();
            cmbExamType = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbExamType.Items.AddRange(new string[] { "Midterm", "Final", "Quiz", "Assignment", "Practical" });
            cmbExamType.SelectedIndex = 0;
            AddRow("Exam Name: *", txtExamName, "Exam Type:", cmbExamType);

            cmbSubject = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbClass = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            AddRow("Subject:", cmbSubject, "Class:", cmbClass);

            dtpExamDate = new DateTimePicker { Format = DateTimePickerFormat.Short };
            txtDuration = new TextBox();
            AddRow("Exam Date:", dtpExamDate, "Duration (mins):", txtDuration);

            txtTotalMarks = new TextBox();
            txtPassingMarks = new TextBox();
            AddRow("Total Marks: *", txtTotalMarks, "Passing Marks: *", txtPassingMarks);

            btnSaveExam = MakeBtn("💾 Save", Color.FromArgb(0, 153, 76), new Point(10, y + 10));
            btnSaveExam.Click += BtnSaveExam_Click;
            btnUpdateExam = MakeBtn("✏️ Update", Color.FromArgb(0, 102, 204), new Point(130, y + 10));
            btnUpdateExam.Click += BtnUpdateExam_Click;
            btnUpdateExam.Enabled = false;
            btnDeleteExam = MakeBtn("🗑 Delete", Color.Red, new Point(250, y + 10));
            btnDeleteExam.Click += BtnDeleteExam_Click;
            btnDeleteExam.Enabled = false;
            btnClearExam = MakeBtn("✕ Clear", Color.Gray, new Point(370, y + 10));
            btnClearExam.Click += (s, e) => ClearExamForm();

            formPanel.Controls.AddRange(new Control[] { btnSaveExam, btnUpdateExam, btnDeleteExam, btnClearExam });

            tabExams.Controls.AddRange(new Control[] { dgvPanel, formPanel });
        }

        private void BuildResultsTab()
        {
            var lblExam = new Label { Text = "Select Exam:", Location = new Point(10, 15), AutoSize = true };
            cmbExam = new ComboBox { Location = new Point(100, 12), Width = 300, DropDownStyle = ComboBoxStyle.DropDownList };

            btnLoadStudents = new Button
            {
                Text = "Load Students",
                Location = new Point(415, 10),
                Width = 130,
                BackColor = Color.FromArgb(0, 102, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnLoadStudents.Click += BtnLoadStudentsResults_Click;

            dgvResults = new DataGridView
            {
                Location = new Point(10, 50),
                Size = new Size(960, 470),
                BackgroundColor = Color.White,
                AllowUserToAddRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            dgvResults.Columns.Add("StudentID", "Student ID");
            dgvResults.Columns["StudentID"].Visible = false;
            dgvResults.Columns.Add("StudentName", "Student Name");
            dgvResults.Columns.Add("ObtainedMarks", "Obtained Marks");
            dgvResults.Columns.Add("Remarks", "Remarks");

            btnSaveResults = new Button
            {
                Text = "💾 Save Results",
                Location = new Point(10, 535),
                Width = 160,
                Height = 38,
                BackColor = Color.FromArgb(0, 153, 76),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat
            };
            btnSaveResults.Click += BtnSaveResults_Click;

            tabResults.Controls.AddRange(new Control[] { lblExam, cmbExam, btnLoadStudents, dgvResults, btnSaveResults });
        }

        private Button MakeBtn(string text, Color color, Point loc) => new Button
        {
            Text = text, Location = loc, Width = 110, Height = 34,
            BackColor = color, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        };

        private void LoadDropdowns()
        {
            try
            {
                var subjects = DatabaseHelper.ExecuteDataTable("SELECT SubjectID, SubjectName FROM Subjects WHERE IsActive=1");
                cmbSubject.DataSource = subjects;
                cmbSubject.DisplayMember = "SubjectName";
                cmbSubject.ValueMember = "SubjectID";

                var classes = DatabaseHelper.ExecuteDataTable("SELECT ClassID, ClassName FROM Classes WHERE IsActive=1");
                cmbClass.DataSource = classes;
                cmbClass.DisplayMember = "ClassName";
                cmbClass.ValueMember = "ClassID";

                var exams = DatabaseHelper.ExecuteDataTable("SELECT ExamID, ExamName FROM Exams WHERE IsActive=1");
                cmbExam.DataSource = exams;
                cmbExam.DisplayMember = "ExamName";
                cmbExam.ValueMember = "ExamID";
            }
            catch (Exception ex) { Logger.LogError("LoadDropdowns ExamForm failed", "ExamForm", ex); }
        }

        private void LoadExams()
        {
            try
            {
                var dt = DatabaseHelper.ExecuteDataTable(@"
                    SELECT e.ExamID, e.ExamName, e.ExamType, sub.SubjectName, c.ClassName, e.ExamDate, e.TotalMarks
                    FROM Exams e
                    JOIN Subjects sub ON e.SubjectID=sub.SubjectID
                    JOIN Classes c ON e.ClassID=c.ClassID
                    WHERE e.IsActive=1 ORDER BY e.ExamDate DESC");
                dgvExams.DataSource = dt;
            }
            catch (Exception ex) { Logger.LogError("LoadExams failed", "ExamForm", ex); }
        }

        private void DgvExams_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgvExams.SelectedRows.Count == 0) return;
            _editExamID = Convert.ToInt32(dgvExams.SelectedRows[0].Cells["ExamID"].Value);
            try
            {
                var dt = DatabaseHelper.ExecuteDataTable("SELECT * FROM Exams WHERE ExamID=@id",
                    new Dictionary<string, object> { { "@id", _editExamID } });
                if (dt.Rows.Count == 0) return;
                var row = dt.Rows[0];
                txtExamName.Text = row["ExamName"].ToString();
                cmbExamType.SelectedItem = row["ExamType"].ToString();
                dtpExamDate.Value = Convert.ToDateTime(row["ExamDate"]);
                txtTotalMarks.Text = row["TotalMarks"].ToString();
                txtPassingMarks.Text = row["PassingMarks"].ToString();
                txtDuration.Text = row["Duration"]?.ToString() ?? "";
                try { cmbSubject.SelectedValue = Convert.ToInt32(row["SubjectID"]); } catch { }
                try { cmbClass.SelectedValue = Convert.ToInt32(row["ClassID"]); } catch { }
                btnSaveExam.Enabled = false; btnUpdateExam.Enabled = true; btnDeleteExam.Enabled = true;
            }
            catch (Exception ex) { Logger.LogError("DgvExams_SelectionChanged failed", "ExamForm", ex); }
        }

        private void BtnSaveExam_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtExamName.Text)) { MessageBox.Show("Exam name is required."); return; }
            if (!int.TryParse(txtTotalMarks.Text, out int total) || !int.TryParse(txtPassingMarks.Text, out int pass)) { MessageBox.Show("Invalid marks."); return; }
            if (pass > total) { MessageBox.Show("Passing marks cannot exceed total marks."); return; }
            try
            {
                string q = @"INSERT INTO Exams (ExamName, ExamType, SubjectID, ClassID, ExamDate, TotalMarks, PassingMarks, Duration)
                             VALUES (@name, @type, @sub, @cls, @date, @total, @pass, @dur)";
                DatabaseHelper.ExecuteNonQuery(q, new Dictionary<string, object>
                {
                    {"@name", txtExamName.Text.Trim()}, {"@type", cmbExamType.SelectedItem!},
                    {"@sub", cmbSubject.SelectedValue!}, {"@cls", cmbClass.SelectedValue!},
                    {"@date", dtpExamDate.Value}, {"@total", total}, {"@pass", pass},
                    {"@dur", string.IsNullOrEmpty(txtDuration.Text) ? (object)DBNull.Value : int.Parse(txtDuration.Text)}
                });
                MessageBox.Show("Exam saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadExams(); LoadDropdowns(); ClearExamForm();
            }
            catch (Exception ex) { Logger.LogError("BtnSaveExam failed", "ExamForm", ex); MessageBox.Show($"Error: {ex.Message}"); }
        }

        private void BtnUpdateExam_Click(object? sender, EventArgs e)
        {
            if (_editExamID < 0) return;
            if (!int.TryParse(txtTotalMarks.Text, out int total) || !int.TryParse(txtPassingMarks.Text, out int pass)) return;
            try
            {
                DatabaseHelper.ExecuteNonQuery(@"UPDATE Exams SET ExamName=@name, ExamType=@type, ExamDate=@date,
                    TotalMarks=@total, PassingMarks=@pass WHERE ExamID=@id",
                    new Dictionary<string, object> {
                        {"@name", txtExamName.Text.Trim()}, {"@type", cmbExamType.SelectedItem!},
                        {"@date", dtpExamDate.Value}, {"@total", total}, {"@pass", pass}, {"@id", _editExamID}
                    });
                MessageBox.Show("Exam updated!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadExams(); ClearExamForm();
            }
            catch (Exception ex) { Logger.LogError("BtnUpdateExam failed", "ExamForm", ex); }
        }

        private void BtnDeleteExam_Click(object? sender, EventArgs e)
        {
            if (_editExamID < 0) return;
            if (MessageBox.Show("Delete this exam?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DatabaseHelper.ExecuteNonQuery("UPDATE Exams SET IsActive=0 WHERE ExamID=@id",
                    new Dictionary<string, object> { { "@id", _editExamID } });
                LoadExams(); ClearExamForm();
            }
        }

        private void BtnLoadStudentsResults_Click(object? sender, EventArgs e)
        {
            if (cmbExam.SelectedValue == null) return;
            try
            {
                int examID = (int)cmbExam.SelectedValue;
                var exam = DatabaseHelper.ExecuteDataTable("SELECT * FROM Exams WHERE ExamID=@id",
                    new Dictionary<string, object> { { "@id", examID } });
                if (exam.Rows.Count == 0) return;
                int classID = Convert.ToInt32(exam.Rows[0]["ClassID"]);

                var dt = DatabaseHelper.ExecuteDataTable(@"
                    SELECT s.StudentID, CONCAT(s.FirstName,' ',s.LastName) AS StudentName,
                    COALESCE(er.ObtainedMarks,'') AS ObtainedMarks, COALESCE(er.Remarks,'') AS Remarks
                    FROM Students s
                    LEFT JOIN ExamResults er ON s.StudentID=er.StudentID AND er.ExamID=@eid
                    WHERE s.ClassID=@cid AND s.IsActive=1",
                    new Dictionary<string, object> { { "@eid", examID }, { "@cid", classID } });

                dgvResults.Rows.Clear();
                foreach (System.Data.DataRow row in dt.Rows)
                    dgvResults.Rows.Add(row["StudentID"], row["StudentName"], row["ObtainedMarks"], row["Remarks"]);
            }
            catch (Exception ex) { Logger.LogError("BtnLoadStudentsResults_Click failed", "ExamForm", ex); }
        }

        private void BtnSaveResults_Click(object? sender, EventArgs e)
        {
            if (dgvResults.Rows.Count == 0 || cmbExam.SelectedValue == null) return;
            try
            {
                int examID = (int)cmbExam.SelectedValue;
                foreach (DataGridViewRow row in dgvResults.Rows)
                {
                    if (row.Cells["ObtainedMarks"].Value == null || string.IsNullOrEmpty(row.Cells["ObtainedMarks"].Value.ToString())) continue;
                    int studentID = Convert.ToInt32(row.Cells["StudentID"].Value);
                    decimal marks = Convert.ToDecimal(row.Cells["ObtainedMarks"].Value);
                    string remarks = row.Cells["Remarks"].Value?.ToString() ?? "";

                    string q = @"INSERT INTO ExamResults (ExamID, StudentID, ObtainedMarks, Remarks)
                        VALUES (@eid, @sid, @marks, @rem)
                        ON DUPLICATE KEY UPDATE ObtainedMarks=@marks, Remarks=@rem";
                    DatabaseHelper.ExecuteNonQuery(q, new Dictionary<string, object>
                    {
                        {"@eid", examID}, {"@sid", studentID}, {"@marks", marks}, {"@rem", remarks}
                    });
                }
                MessageBox.Show("Results saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { Logger.LogError("BtnSaveResults_Click failed", "ExamForm", ex); MessageBox.Show($"Error: {ex.Message}"); }
        }

        private void ClearExamForm()
        {
            _editExamID = -1;
            txtExamName.Clear(); txtTotalMarks.Clear(); txtPassingMarks.Clear(); txtDuration.Clear();
            cmbExamType.SelectedIndex = 0; dtpExamDate.Value = DateTime.Today;
            btnSaveExam.Enabled = true; btnUpdateExam.Enabled = false; btnDeleteExam.Enabled = false;
        }
    }
}
