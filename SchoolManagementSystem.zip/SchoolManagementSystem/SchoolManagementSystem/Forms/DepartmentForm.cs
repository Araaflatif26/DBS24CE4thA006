using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Utilities;

namespace SchoolManagementSystem.Forms
{
    public class DepartmentForm : Form
    {
        private DataGridView dgv;
        private TextBox txtName, txtCode, txtHead;
        private NumericUpDown nudYear;
        private Button btnSave, btnUpdate, btnDelete, btnClear;
        private int _editID = -1;

        public DepartmentForm()
        {
            InitializeComponent();
            LoadDepartments();
        }

        private void InitializeComponent()
        {
            this.Text = "Department Management";
            this.Size = new Size(860, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            var menu = new MenuStrip();
            var fm = new ToolStripMenuItem("File");
            fm.DropDownItems.Add("Close", null, (s,e)=>this.Close());
            menu.Items.Add(fm); this.Controls.Add(menu);

            var pnlL = new Panel { Location=new Point(0,28), Size=new Size(420,450), BorderStyle=BorderStyle.FixedSingle };
            var lbl = new Label { Text="Departments", Font=new Font("Segoe UI",12,FontStyle.Bold), Location=new Point(10,8), AutoSize=true, ForeColor=Color.FromArgb(0,102,204) };
            dgv = new DataGridView { Location=new Point(10,38), Size=new Size(398,400), ReadOnly=true, SelectionMode=DataGridViewSelectionMode.FullRowSelect, AllowUserToAddRows=false, BackgroundColor=Color.White, AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill };
            dgv.SelectionChanged += Dgv_SelectionChanged;
            pnlL.Controls.AddRange(new Control[]{lbl, dgv});

            var pnlR = new Panel { Location=new Point(430,28), Size=new Size(420,450), BorderStyle=BorderStyle.FixedSingle };
            var lblT = new Label { Text="Department Details", Font=new Font("Segoe UI",12,FontStyle.Bold), Location=new Point(10,8), AutoSize=true, ForeColor=Color.FromArgb(0,102,204) };

            int y=45;
            void Add(string label, Control ctrl)
            {
                pnlR.Controls.Add(new Label { Text=label, Location=new Point(10,y), AutoSize=true });
                ctrl.Location=new Point(10,y+20); ctrl.Width=390; pnlR.Controls.Add(ctrl); y+=62;
            }

            txtName = new TextBox(); Add("Department Name: *", txtName);
            txtCode = new TextBox(); Add("Department Code: *", txtCode);
            txtHead = new TextBox(); Add("Head of Department:", txtHead);
            nudYear = new NumericUpDown { Minimum=1950, Maximum=2030, Value=2020 }; Add("Established Year:", nudYear);

            btnSave = Btn("💾 Save",Color.FromArgb(0,153,76),new Point(10,y+10)); btnSave.Click+=BtnSave_Click;
            btnUpdate = Btn("✏️ Update",Color.FromArgb(0,102,204),new Point(130,y+10)); btnUpdate.Click+=BtnUpdate_Click; btnUpdate.Enabled=false;
            btnDelete = Btn("🗑 Delete",Color.Red,new Point(250,y+10)); btnDelete.Click+=BtnDelete_Click; btnDelete.Enabled=false;
            btnClear = Btn("✕ Clear",Color.Gray,new Point(370,y+10)); btnClear.Click+=(s,e)=>ClearForm();

            pnlR.Controls.AddRange(new Control[]{lblT, btnSave, btnUpdate, btnDelete, btnClear});
            this.Controls.AddRange(new Control[]{menu, pnlL, pnlR});
        }

        private Button Btn(string t, Color c, Point loc) => new Button { Text=t, Location=loc, Width=110, Height=34, BackColor=c, ForeColor=Color.White, FlatStyle=FlatStyle.Flat, Font=new Font("Segoe UI",9,FontStyle.Bold) };

        private void LoadDepartments()
        {
            try
            {
                dgv.DataSource = DatabaseHelper.ExecuteDataTable("SELECT DepartmentID, DepartmentName, DepartmentCode, HeadOfDepartment, EstablishedYear FROM Departments WHERE IsActive=1 ORDER BY DepartmentName");
            }
            catch (Exception ex) { Logger.LogError("LoadDepartments failed","DeptForm",ex); }
        }

        private void Dgv_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count==0) return;
            _editID=Convert.ToInt32(dgv.SelectedRows[0].Cells["DepartmentID"].Value);
            try
            {
                var dt=DatabaseHelper.ExecuteDataTable("SELECT * FROM Departments WHERE DepartmentID=@id",new Dictionary<string,object>{{"@id",_editID}});
                if (dt.Rows.Count==0) return;
                var r=dt.Rows[0];
                txtName.Text=r["DepartmentName"].ToString();
                txtCode.Text=r["DepartmentCode"].ToString();
                txtHead.Text=r["HeadOfDepartment"]?.ToString()??"";
                nudYear.Value=r["EstablishedYear"]==DBNull.Value?2000:Convert.ToDecimal(r["EstablishedYear"]);
                btnSave.Enabled=false; btnUpdate.Enabled=true; btnDelete.Enabled=true;
            }
            catch { }
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text)){MessageBox.Show("Name required.");return;}
            try
            {
                DatabaseHelper.ExecuteNonQuery("INSERT INTO Departments (DepartmentName,DepartmentCode,HeadOfDepartment,EstablishedYear) VALUES (@n,@c,@h,@y)",
                    new Dictionary<string,object>{{"@n",txtName.Text.Trim()},{"@c",txtCode.Text.Trim()},{"@h",txtHead.Text.Trim()},{"@y",(int)nudYear.Value}});
                MessageBox.Show("Saved!","Success",MessageBoxButtons.OK,MessageBoxIcon.Information);
                LoadDepartments(); ClearForm();
            }
            catch (Exception ex) { MessageBox.Show($"Error: {ex.Message}"); }
        }

        private void BtnUpdate_Click(object? sender, EventArgs e)
        {
            if (_editID<0) return;
            try
            {
                DatabaseHelper.ExecuteNonQuery("UPDATE Departments SET DepartmentName=@n,DepartmentCode=@c,HeadOfDepartment=@h,EstablishedYear=@y WHERE DepartmentID=@id",
                    new Dictionary<string,object>{{"@n",txtName.Text.Trim()},{"@c",txtCode.Text.Trim()},{"@h",txtHead.Text.Trim()},{"@y",(int)nudYear.Value},{"@id",_editID}});
                MessageBox.Show("Updated!","Success",MessageBoxButtons.OK,MessageBoxIcon.Information);
                LoadDepartments(); ClearForm();
            }
            catch (Exception ex) { MessageBox.Show($"Error: {ex.Message}"); }
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (_editID<0) return;
            if (MessageBox.Show("Delete?","Confirm",MessageBoxButtons.YesNo)==DialogResult.Yes)
            {
                DatabaseHelper.ExecuteNonQuery("UPDATE Departments SET IsActive=0 WHERE DepartmentID=@id",new Dictionary<string,object>{{"@id",_editID}});
                LoadDepartments(); ClearForm();
            }
        }

        private void ClearForm()
        {
            _editID=-1; txtName.Clear(); txtCode.Clear(); txtHead.Clear(); nudYear.Value=2020;
            btnSave.Enabled=true; btnUpdate.Enabled=false; btnDelete.Enabled=false;
        }
    }
}
