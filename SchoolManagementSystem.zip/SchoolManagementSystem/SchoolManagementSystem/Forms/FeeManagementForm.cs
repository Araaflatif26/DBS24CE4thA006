using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Utilities;

namespace SchoolManagementSystem.Forms
{
    public class FeeManagementForm : Form
    {
        private ComboBox cmbStudent, cmbFeeType, cmbPaymentMethod, cmbMonth;
        private TextBox txtAmount, txtReceiptNo;
        private NumericUpDown nudYear;
        private DateTimePicker dtpPaymentDate;
        private DataGridView dgvPayments;
        private Button btnSavePayment, btnSearchStudent;
        private Label lblBalance;

        public FeeManagementForm()
        {
            InitializeComponent();
            LoadDropdowns();
            LoadRecentPayments();
        }

        private void InitializeComponent()
        {
            this.Text = "Fee Management";
            this.Size = new Size(1000, 680);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            var menu = new MenuStrip();
            var fileMenu = new ToolStripMenuItem("File");
            fileMenu.DropDownItems.Add("Close", null, (s, e) => this.Close());
            menu.Items.Add(fileMenu);
            this.Controls.Add(menu);

            var lblTitle = new Label { Text = "Fee Payment Entry", Font = new Font("Segoe UI", 14, FontStyle.Bold), Location = new Point(10, 38), AutoSize = true, ForeColor = Color.FromArgb(0, 102, 204) };

            // Form Panel
            var pnlForm = new Panel { Location = new Point(10, 70), Size = new Size(470, 500), BackColor = Color.FromArgb(248, 249, 250), BorderStyle = BorderStyle.FixedSingle, Padding = new Padding(10) };

            int y = 15, lx = 15, rw = 420;

            void AddField(string label, Control ctrl)
            {
                pnlForm.Controls.Add(new Label { Text = label, Location = new Point(lx, y), AutoSize = true });
                ctrl.Location = new Point(lx, y + 22);
                ctrl.Width = rw;
                pnlForm.Controls.Add(ctrl);
                y += 60;
            }

            cmbStudent = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbStudent.SelectedIndexChanged += CmbStudent_SelectedIndexChanged;
            AddField("Student: *", cmbStudent);

            lblBalance = new Label { Text = "Balance: N/A", Location = new Point(lx, y), ForeColor = Color.Red, Font = new Font("Segoe UI", 9, FontStyle.Bold), AutoSize = true };
            pnlForm.Controls.Add(lblBalance);
            y += 25;

            cmbFeeType = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            AddField("Fee Type: *", cmbFeeType);

            cmbMonth = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbMonth.Items.AddRange(new string[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" });
            cmbMonth.SelectedIndex = DateTime.Now.Month - 1;
            AddField("Month:", cmbMonth);

            nudYear = new NumericUpDown { Minimum = 2020, Maximum = 2030, Value = DateTime.Now.Year };
            AddField("Year:", nudYear);

            txtAmount = new TextBox();
            AddField("Amount (PKR): *", txtAmount);

            cmbPaymentMethod = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbPaymentMethod.Items.AddRange(new string[] { "Cash", "Bank", "Online", "Cheque" });
            cmbPaymentMethod.SelectedIndex = 0;
            AddField("Payment Method: *", cmbPaymentMethod);

            dtpPaymentDate = new DateTimePicker { Format = DateTimePickerFormat.Short, Value = DateTime.Today };
            AddField("Payment Date:", dtpPaymentDate);

            btnSavePayment = new Button
            {
                Text = "💰 Record Payment",
                Location = new Point(lx, y + 5),
                Width = 200,
                Height = 40,
                BackColor = Color.FromArgb(0, 153, 76),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat
            };
            btnSavePayment.Click += BtnSavePayment_Click;
            pnlForm.Controls.Add(btnSavePayment);

            // Payments Grid
            var pnlGrid = new Panel { Location = new Point(495, 70), Size = new Size(490, 560), BorderStyle = BorderStyle.FixedSingle };
            var lblGridTitle = new Label { Text = "Recent Payments", Font = new Font("Segoe UI", 11, FontStyle.Bold), Location = new Point(10, 10), AutoSize = true };
            dgvPayments = new DataGridView
            {
                Location = new Point(10, 40),
                Size = new Size(465, 510),
                ReadOnly = true,
                AllowUserToAddRows = false,
                BackgroundColor = Color.White,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            pnlGrid.Controls.AddRange(new Control[] { lblGridTitle, dgvPayments });

            this.Controls.AddRange(new Control[] { menu, lblTitle, pnlForm, pnlGrid });
        }

        private void LoadDropdowns()
        {
            try
            {
                var students = DatabaseHelper.ExecuteDataTable("SELECT StudentID, CONCAT(FirstName,' ',LastName) AS Name FROM Students WHERE IsActive=1 ORDER BY FirstName");
                cmbStudent.DataSource = students;
                cmbStudent.DisplayMember = "Name";
                cmbStudent.ValueMember = "StudentID";

                var feeTypes = DatabaseHelper.ExecuteDataTable("SELECT DISTINCT FeeType FROM FeeStructure WHERE IsActive=1");
                cmbFeeType.DataSource = feeTypes;
                cmbFeeType.DisplayMember = "FeeType";
            }
            catch (Exception ex) { Logger.LogError("LoadDropdowns Fee failed", "FeeForm", ex); }
        }

        private void CmbStudent_SelectedIndexChanged(object? sender, EventArgs e)
        {
            if (cmbStudent.SelectedValue == null) return;
            try
            {
                int studentID = (int)cmbStudent.SelectedValue;
                var dt = DatabaseHelper.ExecuteDataTable(@"
                    SELECT COALESCE(SUM(fs.Amount),0) - COALESCE(SUM(fp.AmountPaid),0) AS Balance
                    FROM Students s
                    JOIN Classes c ON s.ClassID=c.ClassID
                    JOIN FeeStructure fs ON c.ClassName=fs.ClassName
                    LEFT JOIN FeePayments fp ON s.StudentID=fp.StudentID AND fs.FeeStructureID=fp.FeeStructureID
                    WHERE s.StudentID=@sid",
                    new Dictionary<string, object> { { "@sid", studentID } });
                if (dt.Rows.Count > 0)
                {
                    decimal balance = dt.Rows[0]["Balance"] == DBNull.Value ? 0 : Convert.ToDecimal(dt.Rows[0]["Balance"]);
                    lblBalance.Text = $"Pending Balance: PKR {balance:N2}";
                    lblBalance.ForeColor = balance > 0 ? Color.Red : Color.Green;
                }
                LoadStudentPayments(studentID);
            }
            catch (Exception ex) { Logger.LogError("CmbStudent changed failed", "FeeForm", ex); }
        }

        private void LoadStudentPayments(int studentID)
        {
            try
            {
                var dt = DatabaseHelper.ExecuteDataTable(@"
                    SELECT fp.ReceiptNumber, fs.FeeType, fp.AmountPaid, fp.PaymentDate,
                           fp.PaymentMethod, fp.Month, fp.Year, fp.Status
                    FROM FeePayments fp
                    JOIN FeeStructure fs ON fp.FeeStructureID=fs.FeeStructureID
                    WHERE fp.StudentID=@sid ORDER BY fp.PaymentDate DESC LIMIT 20",
                    new Dictionary<string, object> { { "@sid", studentID } });
                dgvPayments.DataSource = dt;
            }
            catch (Exception ex) { Logger.LogError("LoadStudentPayments failed", "FeeForm", ex); }
        }

        private void LoadRecentPayments()
        {
            try
            {
                var dt = DatabaseHelper.ExecuteDataTable(@"
                    SELECT fp.ReceiptNumber, CONCAT(s.FirstName,' ',s.LastName) AS Student,
                           fs.FeeType, fp.AmountPaid, fp.PaymentDate, fp.Status
                    FROM FeePayments fp
                    JOIN Students s ON fp.StudentID=s.StudentID
                    JOIN FeeStructure fs ON fp.FeeStructureID=fs.FeeStructureID
                    ORDER BY fp.CreatedAt DESC LIMIT 30");
                dgvPayments.DataSource = dt;
            }
            catch (Exception ex) { Logger.LogError("LoadRecentPayments failed", "FeeForm", ex); }
        }

        private void BtnSavePayment_Click(object? sender, EventArgs e)
        {
            if (cmbStudent.SelectedValue == null) { MessageBox.Show("Select a student."); return; }
            if (!decimal.TryParse(txtAmount.Text, out decimal amount) || amount <= 0) { MessageBox.Show("Enter valid amount."); return; }

            try
            {
                int studentID = (int)cmbStudent.SelectedValue;
                string feeType = cmbFeeType.SelectedItem?.ToString() ?? "";

                // Get fee structure ID
                var feeStructure = DatabaseHelper.ExecuteDataTable(@"
                    SELECT fs.FeeStructureID FROM FeeStructure fs
                    JOIN Students s ON s.ClassID = (SELECT ClassID FROM Classes c WHERE c.ClassName = fs.ClassName LIMIT 1)
                    WHERE s.StudentID=@sid AND fs.FeeType=@type AND fs.IsActive=1 LIMIT 1",
                    new Dictionary<string, object> { { "@sid", studentID }, { "@type", feeType } });

                if (feeStructure.Rows.Count == 0) { MessageBox.Show("Fee structure not found for this student/type."); return; }

                int feeStructureID = Convert.ToInt32(feeStructure.Rows[0]["FeeStructureID"]);
                string receiptNo = $"RCP{DateTime.Now:yyyyMMddHHmmss}{studentID}";

                string query = @"INSERT INTO FeePayments (StudentID, FeeStructureID, AmountPaid, PaymentDate,
                    PaymentMethod, ReceiptNumber, Month, Year, Status, ReceivedByUserID)
                    VALUES (@sid, @fsid, @amt, @date, @method, @rec, @month, @year, 'Paid', @uid)";

                DatabaseHelper.ExecuteNonQuery(query, new Dictionary<string, object>
                {
                    {"@sid", studentID}, {"@fsid", feeStructureID}, {"@amt", amount},
                    {"@date", dtpPaymentDate.Value}, {"@method", cmbPaymentMethod.SelectedItem!},
                    {"@rec", receiptNo}, {"@month", cmbMonth.SelectedItem!}, {"@year", (int)nudYear.Value},
                    {"@uid", Models.UserSession.UserID}
                });

                Logger.LogInfo($"Fee payment recorded. Receipt: {receiptNo}", "FeeForm");
                MessageBox.Show($"Payment recorded!\nReceipt No: {receiptNo}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadStudentPayments(studentID);
                CmbStudent_SelectedIndexChanged(null, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                Logger.LogError("BtnSavePayment_Click failed", "FeeForm", ex);
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
    }
}
