using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Models;
using SchoolManagementSystem.Utilities;
using System.Security.Cryptography;
using System.Text;

namespace SchoolManagementSystem.Forms
{
    public class LoginForm : Form
    {
        private Label lblTitle, lblUsername, lblPassword, lblRole;
        private TextBox txtUsername, txtPassword;
        private ComboBox cmbRole;
        private Button btnLogin, btnExit;
        private Panel pnlHeader, pnlForm;
        private CheckBox chkShowPassword;
        private PictureBox picLogo;
        private Label lblSubtitle;

        public LoginForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "School Management System - Login";
            this.Size = new Size(480, 520);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.White;

            // Header Panel
            pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 120,
                BackColor = Color.FromArgb(0, 102, 204)
            };

            lblTitle = new Label
            {
                Text = "School Management System",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = false,
                Width = 460,
                Height = 40,
                Location = new Point(10, 30),
                TextAlign = ContentAlignment.MiddleCenter
            };

            lblSubtitle = new Label
            {
                Text = "University of Engineering and Technology, Lahore",
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.LightCyan,
                AutoSize = false,
                Width = 460,
                Height = 25,
                Location = new Point(10, 75),
                TextAlign = ContentAlignment.MiddleCenter
            };

            pnlHeader.Controls.AddRange(new Control[] { lblTitle, lblSubtitle });

            // Form Panel
            pnlForm = new Panel
            {
                Location = new Point(60, 140),
                Size = new Size(360, 300)
            };

            lblUsername = new Label { Text = "Username:", Location = new Point(0, 10), AutoSize = true, Font = new Font("Segoe UI", 10) };
            txtUsername = new TextBox { Location = new Point(0, 32), Width = 360, Height = 30, Font = new Font("Segoe UI", 10) };

            lblPassword = new Label { Text = "Password:", Location = new Point(0, 80), AutoSize = true, Font = new Font("Segoe UI", 10) };
            txtPassword = new TextBox { Location = new Point(0, 102), Width = 360, Height = 30, Font = new Font("Segoe UI", 10), PasswordChar = '*' };

            chkShowPassword = new CheckBox { Text = "Show Password", Location = new Point(0, 138), AutoSize = true };
            chkShowPassword.CheckedChanged += (s, e) => txtPassword.PasswordChar = chkShowPassword.Checked ? '\0' : '*';

            lblRole = new Label { Text = "Login As:", Location = new Point(0, 170), AutoSize = true, Font = new Font("Segoe UI", 10) };
            cmbRole = new ComboBox
            {
                Location = new Point(0, 192),
                Width = 360,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10)
            };
            cmbRole.Items.AddRange(new string[] { "Admin", "Teacher", "Student", "Parent" });
            cmbRole.SelectedIndex = 0;

            btnLogin = new Button
            {
                Text = "LOGIN",
                Location = new Point(0, 240),
                Width = 170,
                Height = 40,
                BackColor = Color.FromArgb(0, 102, 204),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat
            };
            btnLogin.Click += BtnLogin_Click;

            btnExit = new Button
            {
                Text = "EXIT",
                Location = new Point(190, 240),
                Width = 170,
                Height = 40,
                BackColor = Color.FromArgb(204, 0, 0),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat
            };
            btnExit.Click += (s, e) => Application.Exit();

            pnlForm.Controls.AddRange(new Control[] {
                lblUsername, txtUsername, lblPassword, txtPassword,
                chkShowPassword, lblRole, cmbRole, btnLogin, btnExit
            });

            this.Controls.AddRange(new Control[] { pnlHeader, pnlForm });

            // Accept enter key
            this.AcceptButton = btnLogin;
        }

        private void BtnLogin_Click(object? sender, EventArgs e)
        {
            try
            {
                string username = txtUsername.Text.Trim();
                string password = txtPassword.Text;

                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Please enter username and password.", "Login Failed",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string hashedPassword = HashPassword(password);
                string query = @"SELECT UserID, Username, Role FROM Users 
                                 WHERE Username = @user AND PasswordHash = @pass AND IsActive = 1";
                var dt = DatabaseHelper.ExecuteDataTable(query, new Dictionary<string, object>
                {
                    {"@user", username}, {"@pass", hashedPassword}
                });

                if (dt.Rows.Count > 0)
                {
                    var row = dt.Rows[0];
                    UserSession.UserID = Convert.ToInt32(row["UserID"]);
                    UserSession.Username = row["Username"].ToString()!;
                    UserSession.Role = row["Role"].ToString()!;
                    UserSession.IsLoggedIn = true;

                    // Update last login
                    DatabaseHelper.ExecuteNonQuery(
                        "UPDATE Users SET LastLogin = NOW() WHERE UserID = @id",
                        new Dictionary<string, object> { { "@id", UserSession.UserID } });

                    Logger.LogInfo($"User {username} logged in successfully.", "Auth");

                    var dashboard = new DashboardForm();
                    dashboard.Show();
                    this.Hide();
                }
                else
                {
                    Logger.LogWarning($"Failed login attempt for user: {username}", "Auth");
                    MessageBox.Show("Invalid username or password.", "Login Failed",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPassword.Clear();
                    txtPassword.Focus();
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Login error", "Auth", ex);
                MessageBox.Show($"Login error: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string HashPassword(string password)
        {
            using var sha = SHA256.Create();
            var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
            return Convert.ToHexString(bytes).ToLower();
        }
    }
}
