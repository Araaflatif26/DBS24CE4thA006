using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Reports;
using SchoolManagementSystem.Utilities;

namespace SchoolManagementSystem.Forms
{
    public class ReportForm : Form
    {
        private readonly string _defaultReport;
        private ListBox lstReports;
        private Panel pnlParams;
        private Button btnGenerate;
        private Label lblTitle, lblStatus;

        // Parameter controls
        private ComboBox cmbClass, cmbSubject, cmbStudent, cmbMonth;
        private DateTimePicker dtpFrom, dtpTo, dtpDate;
        private NumericUpDown nudYear;
        private TextBox txtAcYear;

        public ReportForm(string defaultReport = "Student")
        {
            _defaultReport = defaultReport;
            InitializeComponent();
            LoadDropdowns();
        }

        private void InitializeComponent()
        {
            this.Text = "Reports";
            this.Size = new Size(900, 620);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            var menu = new MenuStrip();
            var fm = new ToolStripMenuItem("File");
            fm.DropDownItems.Add("Close", null, (s, e) => this.Close());
            menu.Items.Add(fm); this.Controls.Add(menu);

            // Left: report list
            var pnlL = new Panel { Location = new Point(0, 28), Size = new Size(250, 570), BackColor = Color.FromArgb(0, 102, 204) };
            var lblList = new Label { Text = "Available Reports", Font = new Font("Segoe UI", 11, FontStyle.Bold), ForeColor = Color.White, Location = new Point(10, 10), AutoSize = true };

            lstReports = new ListBox
            {
                Location = new Point(5, 38),
                Size = new Size(240, 520),
                BackColor = Color.FromArgb(0, 80, 160),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10),
                BorderStyle = BorderStyle.None,
                SelectionMode = SelectionMode.One
            };

            string[] reports = {
                "1. Student List",
                "2. Attendance Report",
                "3. Exam Results",
                "4. Student Report Card",
                "5. Fee Collection",
                "6. Teacher List",
                "7. Class-wise Students",
                "8. Fee Defaulters",
                "9. Subject Results",
                "10. Daily Attendance",
                "11. Class Timetable"
            };
            lstReports.Items.AddRange(reports);
            lstReports.SelectedIndexChanged += LstReports_SelectedIndexChanged;

            pnlL.Controls.AddRange(new Control[] { lblList, lstReports });

            // Right: params + generate
            var pnlR = new Panel { Location = new Point(260, 28), Size = new Size(625, 570) };

            lblTitle = new Label { Text = "Select a report from the list", Font = new Font("Segoe UI", 13, FontStyle.Bold), Location = new Point(10, 10), AutoSize = true, ForeColor = Color.FromArgb(0, 102, 204) };

            pnlParams = new Panel { Location = new Point(10, 50), Size = new Size(600, 420), BackColor = Color.FromArgb(248, 249, 250), BorderStyle = BorderStyle.FixedSingle };

            btnGenerate = new Button
            {
                Text = "📄 Generate PDF Report",
                Location = new Point(10, 490),
                Width = 220,
                Height = 44,
                BackColor = Color.FromArgb(0, 153, 76),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat
            };
            btnGenerate.Click += BtnGenerate_Click;

            lblStatus = new Label { Text = "", Location = new Point(240, 500), AutoSize = true, ForeColor = Color.DarkBlue, Font = new Font("Segoe UI", 9) };

            pnlR.Controls.AddRange(new Control[] { lblTitle, pnlParams, btnGenerate, lblStatus });
            this.Controls.AddRange(new Control[] { menu, pnlL, pnlR });

            // Pre-select
            lstReports.SelectedIndex = 0;
        }

        private void LoadDropdowns()
        {
            try
            {
                var classes = DatabaseHelper.ExecuteDataTable("SELECT ClassID, ClassName FROM Classes WHERE IsActive=1");
                cmbClass = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, DataSource = classes, DisplayMember = "ClassName", ValueMember = "ClassID" };

                var subjects = DatabaseHelper.ExecuteDataTable("SELECT SubjectID, SubjectName FROM Subjects WHERE IsActive=1");
                cmbSubject = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, DataSource = subjects, DisplayMember = "SubjectName", ValueMember = "SubjectID" };

                var students = DatabaseHelper.ExecuteDataTable("SELECT StudentID, CONCAT(FirstName,' ',LastName) AS Name FROM Students WHERE IsActive=1 ORDER BY FirstName");
                cmbStudent = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, DataSource = students, DisplayMember = "Name", ValueMember = "StudentID" };

                cmbMonth = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
                cmbMonth.Items.AddRange(new string[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" });
                cmbMonth.SelectedIndex = DateTime.Now.Month - 1;

                nudYear = new NumericUpDown { Minimum = 2020, Maximum = 2030, Value = DateTime.Now.Year };
                dtpFrom = new DateTimePicker { Format = DateTimePickerFormat.Short, Value = DateTime.Today.AddMonths(-1) };
                dtpTo = new DateTimePicker { Format = DateTimePickerFormat.Short, Value = DateTime.Today };
                dtpDate = new DateTimePicker { Format = DateTimePickerFormat.Short, Value = DateTime.Today };
                txtAcYear = new TextBox { Text = "2024-25" };
            }
            catch (Exception ex) { Logger.LogError("ReportForm LoadDropdowns failed", "ReportForm", ex); }
        }

        private void LstReports_SelectedIndexChanged(object? sender, EventArgs e)
        {
            pnlParams.Controls.Clear();
            int idx = lstReports.SelectedIndex;

            lblTitle.Text = lstReports.SelectedItem?.ToString() ?? "";
            int y = 15;

            void AddParam(string label, Control ctrl)
            {
                pnlParams.Controls.Add(new Label { Text = label, Location = new Point(15, y), AutoSize = true, Font = new Font("Segoe UI", 10) });
                ctrl.Location = new Point(15, y + 22); ctrl.Width = 300; pnlParams.Controls.Add(ctrl);
                y += 65;
            }

            switch (idx)
            {
                case 0: // Student List
                    pnlParams.Controls.Add(new Label { Text = "Optional: Filter by Class (leave blank for all)", Location = new Point(15, 15), AutoSize = true });
                    var cmbClassClone = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Location = new Point(15, 40), Width = 300 };
                    try {
                        var dt = DatabaseHelper.ExecuteDataTable("SELECT ClassID, ClassName FROM Classes WHERE IsActive=1");
                        cmbClassClone.Items.Add(new { ClassID = 0, ClassName = "-- All Classes --" });
                        foreach (System.Data.DataRow r in dt.Rows) cmbClassClone.Items.Add(new { ClassID = Convert.ToInt32(r["ClassID"]), ClassName = r["ClassName"].ToString() });
                    } catch { }
                    cmbClassClone.DisplayMember = "ClassName"; cmbClassClone.ValueMember = "ClassID"; cmbClassClone.SelectedIndex = 0;
                    cmbClassClone.Name = "cmbClassFilter";
                    pnlParams.Controls.Add(cmbClassClone);
                    break;
                case 1: // Attendance
                    AddParam("Class:", cmbClass); AddParam("Subject:", cmbSubject);
                    AddParam("From Date:", dtpFrom); AddParam("To Date:", dtpTo);
                    break;
                case 2: // Exam Results
                    var cmbExam = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
                    try { var dt = DatabaseHelper.ExecuteDataTable("SELECT ExamID, ExamName FROM Exams WHERE IsActive=1"); cmbExam.DataSource = dt; cmbExam.DisplayMember = "ExamName"; cmbExam.ValueMember = "ExamID"; } catch { }
                    cmbExam.Name = "cmbExam";
                    AddParam("Select Exam:", cmbExam);
                    break;
                case 3: // Report Card
                    AddParam("Student:", cmbStudent); AddParam("Academic Year:", txtAcYear);
                    break;
                case 4: // Fee Collection
                    AddParam("Month:", cmbMonth); AddParam("Year:", nudYear);
                    break;
                case 5: // Teacher List - no params
                    pnlParams.Controls.Add(new Label { Text = "Click Generate to create Teacher List report.", Location = new Point(15, 15), AutoSize = true });
                    break;
                case 6: // Class-wise - no params
                    pnlParams.Controls.Add(new Label { Text = "Click Generate to create Class-wise report.", Location = new Point(15, 15), AutoSize = true });
                    break;
                case 7: // Fee Defaulters
                    AddParam("Academic Year:", txtAcYear);
                    break;
                case 8: // Subject Results
                    AddParam("Class:", cmbClass); AddParam("Academic Year:", txtAcYear);
                    break;
                case 9: // Daily Attendance
                    AddParam("Date:", dtpDate);
                    break;
                case 10: // Timetable
                    AddParam("Class:", cmbClass);
                    break;
            }
        }

        private void BtnGenerate_Click(object? sender, EventArgs e)
        {
            lblStatus.Text = "Generating...";
            Application.DoEvents();
            try
            {
                string path = lstReports.SelectedIndex switch
                {
                    0 => PdfReportGenerator.GenerateStudentListReport(null),
                    1 => PdfReportGenerator.GenerateAttendanceReport(
                            cmbClass.SelectedValue != null ? (int)cmbClass.SelectedValue : 0,
                            cmbSubject.SelectedValue != null ? (int)cmbSubject.SelectedValue : 0,
                            dtpFrom.Value, dtpTo.Value),
                    2 => PdfReportGenerator.GenerateExamResultsReport(
                            GetComboValue("cmbExam")),
                    3 => PdfReportGenerator.GenerateReportCard(
                            cmbStudent.SelectedValue != null ? (int)cmbStudent.SelectedValue : 0,
                            txtAcYear.Text.Trim()),
                    4 => PdfReportGenerator.GenerateFeeCollectionReport(
                            cmbMonth.SelectedItem?.ToString() ?? "January", (int)nudYear.Value),
                    5 => PdfReportGenerator.GenerateTeacherListReport(),
                    6 => PdfReportGenerator.GenerateClassWiseStudentReport(),
                    7 => PdfReportGenerator.GenerateFeeDefaultersReport(txtAcYear.Text.Trim()),
                    8 => PdfReportGenerator.GenerateSubjectResultsSummary(
                            cmbClass.SelectedValue != null ? (int)cmbClass.SelectedValue : 0,
                            txtAcYear.Text.Trim()),
                    9 => PdfReportGenerator.GenerateDailyAttendanceSummary(dtpDate.Value),
                    10 => PdfReportGenerator.GenerateTimetableReport(
                            cmbClass.SelectedValue != null ? (int)cmbClass.SelectedValue : 0),
                    _ => throw new Exception("Select a report first.")
                };

                lblStatus.Text = "✅ Report saved!";
                if (MessageBox.Show($"Report generated!\n\nPath: {path}\n\nOpen report now?", "Success",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(path) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                lblStatus.Text = "❌ Error generating report";
                Logger.LogError("BtnGenerate_Click ReportForm failed", "ReportForm", ex);
                MessageBox.Show($"Error: {ex.Message}", "Report Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int GetComboValue(string name)
        {
            var ctrl = pnlParams.Controls[name] as ComboBox;
            return ctrl?.SelectedValue != null ? Convert.ToInt32(ctrl.SelectedValue) : 0;
        }
    }
}
