using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Utilities;

namespace SchoolManagementSystem.Forms
{
    public class AttendanceForm : Form
    {
        private ComboBox cmbClass, cmbSubject;
        private DateTimePicker dtpDate;
        private DataGridView dgvAttendance;
        private Button btnLoadStudents, btnSaveAttendance, btnViewReport;
        private Label lblClass, lblSubject, lblDate, lblTitle;
        private Panel pnlTop;

        public AttendanceForm()
        {
            InitializeComponent();
            LoadDropdowns();
        }

        private void InitializeComponent()
        {
            this.Text = "Attendance Management";
            this.Size = new Size(900, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            var menu = new MenuStrip();
            var fileMenu = new ToolStripMenuItem("File");
            fileMenu.DropDownItems.Add("View Attendance Report", null, (s, e) => ViewReport());
            fileMenu.DropDownItems.Add("Close", null, (s, e) => this.Close());
            menu.Items.Add(fileMenu);
            this.Controls.Add(menu);

            lblTitle = new Label { Text = "Mark Attendance", Font = new Font("Segoe UI", 14, FontStyle.Bold), Location = new Point(20, 40), AutoSize = true, ForeColor = Color.FromArgb(0, 102, 204) };

            pnlTop = new Panel { Location = new Point(10, 70), Size = new Size(860, 70), BackColor = Color.FromArgb(235, 245, 255) };

            lblClass = new Label { Text = "Class:", Location = new Point(10, 22), AutoSize = true };
            cmbClass = new ComboBox { Location = new Point(60, 18), Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };

            lblSubject = new Label { Text = "Subject:", Location = new Point(260, 22), AutoSize = true };
            cmbSubject = new ComboBox { Location = new Point(320, 18), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };

            lblDate = new Label { Text = "Date:", Location = new Point(540, 22), AutoSize = true };
            dtpDate = new DateTimePicker { Location = new Point(580, 18), Width = 150, Format = DateTimePickerFormat.Short };

            btnLoadStudents = new Button
            {
                Text = "Load Students",
                Location = new Point(740, 15),
                Width = 110,
                BackColor = Color.FromArgb(0, 102, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnLoadStudents.Click += BtnLoadStudents_Click;

            pnlTop.Controls.AddRange(new Control[] { lblClass, cmbClass, lblSubject, cmbSubject, lblDate, dtpDate, btnLoadStudents });

            // Grid
            dgvAttendance = new DataGridView
            {
                Location = new Point(10, 155),
                Size = new Size(860, 400),
                BackgroundColor = Color.White,
                AllowUserToAddRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            // Add Status dropdown column
            var statusCol = new DataGridViewComboBoxColumn
            {
                Name = "Status",
                HeaderText = "Status",
                DataSource = new string[] { "Present", "Absent", "Late", "Excused" }
            };
            dgvAttendance.Columns.Add("StudentID", "Student ID");
            dgvAttendance.Columns.Add("StudentName", "Student Name");
            dgvAttendance.Columns.Add(statusCol);
            dgvAttendance.Columns.Add("Remarks", "Remarks");
            dgvAttendance.Columns["StudentID"].Visible = false;

            btnSaveAttendance = new Button
            {
                Text = "💾 Save Attendance",
                Location = new Point(10, 570),
                Width = 180,
                Height = 38,
                BackColor = Color.FromArgb(0, 153, 76),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat
            };
            btnSaveAttendance.Click += BtnSaveAttendance_Click;

            btnViewReport = new Button
            {
                Text = "📊 View Report",
                Location = new Point(200, 570),
                Width = 150,
                Height = 38,
                BackColor = Color.FromArgb(153, 51, 255),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat
            };
            btnViewReport.Click += (s, e) => ViewReport();

            // Mark All buttons
            var btnMarkAllPresent = new Button { Text = "✓ All Present", Location = new Point(360, 570), Width = 130, Height = 38, BackColor = Color.Green, ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            btnMarkAllPresent.Click += (s, e) => MarkAll("Present");

            var btnMarkAllAbsent = new Button { Text = "✗ All Absent", Location = new Point(500, 570), Width = 130, Height = 38, BackColor = Color.Red, ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            btnMarkAllAbsent.Click += (s, e) => MarkAll("Absent");

            this.Controls.AddRange(new Control[] { menu, lblTitle, pnlTop, dgvAttendance, btnSaveAttendance, btnViewReport, btnMarkAllPresent, btnMarkAllAbsent });
        }

        private void LoadDropdowns()
        {
            try
            {
                var classes = DatabaseHelper.ExecuteDataTable("SELECT ClassID, ClassName FROM Classes WHERE IsActive=1");
                cmbClass.DataSource = classes;
                cmbClass.DisplayMember = "ClassName";
                cmbClass.ValueMember = "ClassID";
                cmbClass.SelectedIndexChanged += (s, e) => LoadSubjectsForClass();

                LoadSubjectsForClass();
            }
            catch (Exception ex) { Logger.LogError("LoadDropdowns Attendance", "AttendanceForm", ex); }
        }

        private void LoadSubjectsForClass()
        {
            if (cmbClass.SelectedValue == null) return;
            try
            {
                var subs = DatabaseHelper.ExecuteDataTable(@"
                    SELECT DISTINCT s.SubjectID, s.SubjectName FROM TeacherSubjects ts
                    JOIN Subjects s ON ts.SubjectID = s.SubjectID
                    WHERE ts.ClassID = @cid",
                    new Dictionary<string, object> { { "@cid", cmbClass.SelectedValue } });
                cmbSubject.DataSource = subs;
                cmbSubject.DisplayMember = "SubjectName";
                cmbSubject.ValueMember = "SubjectID";
            }
            catch (Exception ex) { Logger.LogError("LoadSubjectsForClass failed", "AttendanceForm", ex); }
        }

        private void BtnLoadStudents_Click(object? sender, EventArgs e)
        {
            if (cmbClass.SelectedValue == null || cmbSubject.SelectedValue == null) return;
            try
            {
                int classID = (int)cmbClass.SelectedValue;
                int subjectID = (int)cmbSubject.SelectedValue;
                DateTime date = dtpDate.Value.Date;

                var students = DatabaseHelper.ExecuteDataTable(@"
                    SELECT s.StudentID, CONCAT(s.FirstName,' ',s.LastName) AS StudentName,
                    COALESCE(a.Status,'Present') AS Status, COALESCE(a.Remarks,'') AS Remarks
                    FROM Students s
                    LEFT JOIN Attendance a ON s.StudentID=a.StudentID AND a.SubjectID=@sid AND a.AttendanceDate=@date
                    WHERE s.ClassID=@cid AND s.IsActive=1",
                    new Dictionary<string, object> { { "@cid", classID }, { "@sid", subjectID }, { "@date", date } });

                dgvAttendance.Rows.Clear();
                foreach (System.Data.DataRow row in students.Rows)
                {
                    int idx = dgvAttendance.Rows.Add(row["StudentID"], row["StudentName"], row["Status"], row["Remarks"]);
                }

                Logger.LogInfo($"Loaded {dgvAttendance.Rows.Count} students for attendance.", "AttendanceForm");
            }
            catch (Exception ex)
            {
                Logger.LogError("BtnLoadStudents_Click failed", "AttendanceForm", ex);
                MessageBox.Show($"Error loading students: {ex.Message}");
            }
        }

        private void BtnSaveAttendance_Click(object? sender, EventArgs e)
        {
            if (dgvAttendance.Rows.Count == 0) { MessageBox.Show("Load students first."); return; }
            if (cmbSubject.SelectedValue == null) return;

            try
            {
                int subjectID = (int)cmbSubject.SelectedValue;
                DateTime date = dtpDate.Value.Date;
                int saved = 0;

                foreach (DataGridViewRow row in dgvAttendance.Rows)
                {
                    int studentID = Convert.ToInt32(row.Cells["StudentID"].Value);
                    string status = row.Cells["Status"].Value?.ToString() ?? "Present";
                    string remarks = row.Cells["Remarks"].Value?.ToString() ?? "";

                    string query = @"INSERT INTO Attendance (StudentID, SubjectID, AttendanceDate, Status, Remarks, MarkedByTeacherID)
                        VALUES (@sid, @subid, @date, @status, @remarks, @tid)
                        ON DUPLICATE KEY UPDATE Status=@status, Remarks=@remarks";
                    DatabaseHelper.ExecuteNonQuery(query, new Dictionary<string, object>
                    {
                        {"@sid", studentID}, {"@subid", subjectID}, {"@date", date},
                        {"@status", status}, {"@remarks", remarks}, {"@tid", DBNull.Value}
                    });
                    saved++;
                }

                Logger.LogInfo($"Attendance saved for {saved} students.", "AttendanceForm");
                MessageBox.Show($"Attendance saved for {saved} students!", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Logger.LogError("BtnSaveAttendance_Click failed", "AttendanceForm", ex);
                MessageBox.Show($"Error saving attendance: {ex.Message}");
            }
        }

        private void MarkAll(string status)
        {
            foreach (DataGridViewRow row in dgvAttendance.Rows)
                row.Cells["Status"].Value = status;
        }

        private void ViewReport()
        {
            if (cmbClass.SelectedValue == null || cmbSubject.SelectedValue == null) return;
            try
            {
                var dt = DatabaseHelper.ExecuteStoredProcedure("sp_GetClassAttendanceReport",
                    new Dictionary<string, object>
                    {
                        {"@p_ClassID", cmbClass.SelectedValue},
                        {"@p_SubjectID", cmbSubject.SelectedValue},
                        {"@p_StartDate", DateTime.Today.AddMonths(-1)},
                        {"@p_EndDate", DateTime.Today}
                    });

                var reportForm = new Form { Text = "Attendance Report", Size = new Size(700, 500) };
                var dgv = new DataGridView { Dock = DockStyle.Fill, DataSource = dt, ReadOnly = true, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
                reportForm.Controls.Add(dgv);
                reportForm.ShowDialog();
            }
            catch (Exception ex) { Logger.LogError("ViewReport failed", "AttendanceForm", ex); }
        }
    }
}
