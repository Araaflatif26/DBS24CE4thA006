using SchoolManagementSystem.DAL;
using SchoolManagementSystem.Utilities;

namespace SchoolManagementSystem.Forms
{
    public class ClassForm : Form
    {
        private DataGridView dgvClasses;
        private TextBox txtClassName, txtClassCode, txtSection, txtRoom;
        private NumericUpDown nudCapacity;
        private ComboBox cmbDepartment, cmbClassTeacher, cmbAcademicYear;
        private Button btnSave, btnUpdate, btnDelete, btnClear;
        private int _editID = -1;

        public ClassForm()
        {
            InitializeComponent();
            LoadClasses();
            LoadDropdowns();
        }

        private void InitializeComponent()
        {
            this.Text = "Class Management";
            this.Size = new Size(1000, 620);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            var menu = new MenuStrip();
            var fileMenu = new ToolStripMenuItem("File");
            fileMenu.DropDownItems.Add("Close", null, (s, e) => this.Close());
            menu.Items.Add(fileMenu);
            this.Controls.Add(menu);

            // List Panel
            var pnlList = new Panel { Location = new Point(0, 28), Size = new Size(450, 570), BorderStyle = BorderStyle.FixedSingle };
            var lblList = new Label { Text = "Classes", Font = new Font("Segoe UI", 12, FontStyle.Bold), Location = new Point(10, 8), AutoSize = true, ForeColor = Color.FromArgb(0, 102, 204) };
            dgvClasses = new DataGridView
            {
                Location = new Point(10, 38),
                Size = new Size(428, 520),
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AllowUserToAddRows = false,
                BackgroundColor = Color.White,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            dgvClasses.SelectionChanged += Dgv_SelectionChanged;
            pnlList.Controls.AddRange(new Control[] { lblList, dgvClasses });

            // Form Panel
            var pnlForm = new Panel { Location = new Point(460, 28), Size = new Size(530, 570), BorderStyle = BorderStyle.FixedSingle };
            var lblTitle = new Label { Text = "Class Details", Font = new Font("Segoe UI", 12, FontStyle.Bold), Location = new Point(10, 8), AutoSize = true, ForeColor = Color.FromArgb(0, 102, 204) };
            pnlForm.Controls.Add(lblTitle);

            // Row 1
            int y = 45;
            pnlForm.Controls.Add(new Label { Text = "Class Name: *", Location = new Point(10, y), AutoSize = true });
            txtClassName = new TextBox { Location = new Point(10, y + 20), Width = 230 };
            pnlForm.Controls.Add(txtClassName);

            pnlForm.Controls.Add(new Label { Text = "Class Code: *", Location = new Point(270, y), AutoSize = true });
            txtClassCode = new TextBox { Location = new Point(270, y + 20), Width = 230 };
            pnlForm.Controls.Add(txtClassCode);
            y += 62;

            // Row 2
            pnlForm.Controls.Add(new Label { Text = "Section:", Location = new Point(10, y), AutoSize = true });
            txtSection = new TextBox { Location = new Point(10, y + 20), Width = 230 };
            pnlForm.Controls.Add(txtSection);

            pnlForm.Controls.Add(new Label { Text = "Room Number:", Location = new Point(270, y), AutoSize = true });
            txtRoom = new TextBox { Location = new Point(270, y + 20), Width = 230 };
            pnlForm.Controls.Add(txtRoom);
            y += 62;

            // Row 3
            pnlForm.Controls.Add(new Label { Text = "Department:", Location = new Point(10, y), AutoSize = true });
            cmbDepartment = new ComboBox { Location = new Point(10, y + 20), Width = 230, DropDownStyle = ComboBoxStyle.DropDownList };
            pnlForm.Controls.Add(cmbDepartment);

            pnlForm.Controls.Add(new Label { Text = "Class Teacher:", Location = new Point(270, y), AutoSize = true });
            cmbClassTeacher = new ComboBox { Location = new Point(270, y + 20), Width = 230, DropDownStyle = ComboBoxStyle.DropDownList };
            pnlForm.Controls.Add(cmbClassTeacher);
            y += 62;

            // Row 4
            pnlForm.Controls.Add(new Label { Text = "Capacity:", Location = new Point(10, y), AutoSize = true });
            nudCapacity = new NumericUpDown { Location = new Point(10, y + 20), Width = 230, Minimum = 10, Maximum = 100, Value = 40 };
            pnlForm.Controls.Add(nudCapacity);

            pnlForm.Controls.Add(new Label { Text = "Academic Year:", Location = new Point(270, y), AutoSize = true });
            cmbAcademicYear = new ComboBox { Location = new Point(270, y + 20), Width = 230, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbAcademicYear.Items.AddRange(new string[] { "2023-24", "2024-25", "2025-26" });
            cmbAcademicYear.SelectedIndex = 1;
            pnlForm.Controls.Add(cmbAcademicYear);
            y += 62;

            // Buttons
            btnSave = Btn("Save", Color.FromArgb(0, 153, 76), new Point(10, y + 10));
            btnSave.Click += BtnSave_Click;
            btnUpdate = Btn("Update", Color.FromArgb(0, 102, 204), new Point(130, y + 10));
            btnUpdate.Click += BtnUpdate_Click;
            btnUpdate.Enabled = false;
            btnDelete = Btn("Delete", Color.Red, new Point(250, y + 10));
            btnDelete.Click += BtnDelete_Click;
            btnDelete.Enabled = false;
            btnClear = Btn("Clear", Color.Gray, new Point(370, y + 10));
            btnClear.Click += (s, e) => ClearForm();

            pnlForm.Controls.AddRange(new Control[] { btnSave, btnUpdate, btnDelete, btnClear });
            this.Controls.AddRange(new Control[] { menu, pnlList, pnlForm });
        }

        private Button Btn(string t, Color c, Point loc) => new Button
        {
            Text = t, Location = loc, Width = 110, Height = 34,
            BackColor = c, ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        };

        private void LoadClasses()
        {
            try
            {
                var dt = DatabaseHelper.ExecuteDataTable("SELECT ClassID, ClassName, ClassCode, Section, AcademicYear FROM Classes WHERE IsActive=1 ORDER BY ClassName");
                dgvClasses.DataSource = dt;
            }
            catch (Exception ex) { Logger.LogError("LoadClasses failed", "ClassForm", ex); }
        }

        private void LoadDropdowns()
        {
            try
            {
                var depts = DatabaseHelper.ExecuteDataTable("SELECT DepartmentID, DepartmentName FROM Departments WHERE IsActive=1");
                cmbDepartment.DataSource = depts;
                cmbDepartment.DisplayMember = "DepartmentName";
                cmbDepartment.ValueMember = "DepartmentID";

                var teachers = DatabaseHelper.ExecuteDataTable("SELECT TeacherID, CONCAT(FirstName,' ',LastName) AS Name FROM Teachers WHERE IsActive=1");
                cmbClassTeacher.DataSource = teachers;
                cmbClassTeacher.DisplayMember = "Name";
                cmbClassTeacher.ValueMember = "TeacherID";
            }
            catch (Exception ex) { Logger.LogError("LoadDropdowns ClassForm failed", "ClassForm", ex); }
        }

        private void Dgv_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgvClasses.SelectedRows.Count == 0) return;
            _editID = Convert.ToInt32(dgvClasses.SelectedRows[0].Cells["ClassID"].Value);
            try
            {
                var dt = DatabaseHelper.ExecuteDataTable("SELECT * FROM Classes WHERE ClassID=@id", new Dictionary<string, object> { { "@id", _editID } });
                if (dt.Rows.Count == 0) return;
                var r = dt.Rows[0];
                txtClassName.Text = r["ClassName"].ToString();
                txtClassCode.Text = r["ClassCode"].ToString();
                txtSection.Text = r["Section"]?.ToString() ?? "";
                txtRoom.Text = r["RoomNumber"]?.ToString() ?? "";
                nudCapacity.Value = r["Capacity"] == DBNull.Value ? 40 : Convert.ToDecimal(r["Capacity"]);
                cmbAcademicYear.SelectedItem = r["AcademicYear"].ToString();
                try { cmbDepartment.SelectedValue = Convert.ToInt32(r["DepartmentID"]); } catch { }
                try { cmbClassTeacher.SelectedValue = Convert.ToInt32(r["ClassTeacherID"]); } catch { }
                btnSave.Enabled = false; btnUpdate.Enabled = true; btnDelete.Enabled = true;
            }
            catch (Exception ex) { Logger.LogError("Dgv_SelectionChanged ClassForm failed", "ClassForm", ex); }
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtClassName.Text)) { MessageBox.Show("Class name required."); return; }
            try
            {
                DatabaseHelper.ExecuteNonQuery(
                    @"INSERT INTO Classes (ClassName,ClassCode,Section,DepartmentID,ClassTeacherID,RoomNumber,Capacity,AcademicYear)
                      VALUES (@cn,@cc,@sec,@dept,@ct,@room,@cap,@yr)",
                    new Dictionary<string, object>
                    {
                        {"@cn", txtClassName.Text.Trim()}, {"@cc", txtClassCode.Text.Trim()},
                        {"@sec", txtSection.Text.Trim()}, {"@dept", cmbDepartment.SelectedValue!},
                        {"@ct", cmbClassTeacher.SelectedValue!}, {"@room", txtRoom.Text.Trim()},
                        {"@cap", (int)nudCapacity.Value}, {"@yr", cmbAcademicYear.SelectedItem!}
                    });
                MessageBox.Show("Class saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadClasses(); ClearForm();
            }
            catch (Exception ex) { MessageBox.Show($"Error: {ex.Message}"); }
        }

        private void BtnUpdate_Click(object? sender, EventArgs e)
        {
            if (_editID < 0) return;
            try
            {
                DatabaseHelper.ExecuteNonQuery(
                    @"UPDATE Classes SET ClassName=@cn,ClassCode=@cc,Section=@sec,DepartmentID=@dept,
                      ClassTeacherID=@ct,RoomNumber=@room,Capacity=@cap,AcademicYear=@yr WHERE ClassID=@id",
                    new Dictionary<string, object>
                    {
                        {"@cn", txtClassName.Text.Trim()}, {"@cc", txtClassCode.Text.Trim()},
                        {"@sec", txtSection.Text.Trim()}, {"@dept", cmbDepartment.SelectedValue!},
                        {"@ct", cmbClassTeacher.SelectedValue!}, {"@room", txtRoom.Text.Trim()},
                        {"@cap", (int)nudCapacity.Value}, {"@yr", cmbAcademicYear.SelectedItem!},
                        {"@id", _editID}
                    });
                MessageBox.Show("Updated!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadClasses(); ClearForm();
            }
            catch (Exception ex) { MessageBox.Show($"Error: {ex.Message}"); }
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (_editID < 0) return;
            if (MessageBox.Show("Delete this class?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DatabaseHelper.ExecuteNonQuery("UPDATE Classes SET IsActive=0 WHERE ClassID=@id",
                    new Dictionary<string, object> { { "@id", _editID } });
                LoadClasses(); ClearForm();
            }
        }

        private void ClearForm()
        {
            _editID = -1;
            txtClassName.Clear(); txtClassCode.Clear(); txtSection.Clear(); txtRoom.Clear();
            nudCapacity.Value = 40; cmbAcademicYear.SelectedIndex = 1;
            if (cmbDepartment.Items.Count > 0) cmbDepartment.SelectedIndex = 0;
            if (cmbClassTeacher.Items.Count > 0) cmbClassTeacher.SelectedIndex = 0;
            btnSave.Enabled = true; btnUpdate.Enabled = false; btnDelete.Enabled = false;
        }
    }
}
