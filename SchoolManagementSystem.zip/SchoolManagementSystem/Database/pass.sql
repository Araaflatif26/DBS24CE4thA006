USE SchoolManagementDB;

INSERT IGNORE INTO Users (Username, PasswordHash, Role) VALUES
('admin', SHA2('admin123', 256), 'Admin'),
('teacher1', SHA2('teacher123', 256), 'Teacher'),
('student1', SHA2('student123', 256), 'Student');