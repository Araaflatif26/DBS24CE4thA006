-- ============================================================
-- School Management System - Database Schema
-- University of Engineering and Technology, Lahore
-- CMPE-232 Term Project
-- ============================================================

CREATE DATABASE IF NOT EXISTS SchoolManagementDB;
USE SchoolManagementDB;

-- ============================================================
-- TABLE 1: Departments
-- ============================================================
CREATE TABLE Departments (
    DepartmentID INT AUTO_INCREMENT PRIMARY KEY,
    DepartmentName VARCHAR(100) NOT NULL UNIQUE,
    DepartmentCode VARCHAR(10) NOT NULL UNIQUE,
    HeadOfDepartment VARCHAR(100),
    EstablishedYear INT,
    IsActive TINYINT(1) DEFAULT 1,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE 2: Users (for login)
-- ============================================================
CREATE TABLE Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(50) NOT NULL UNIQUE,
    PasswordHash VARCHAR(256) NOT NULL,
    Role ENUM('Admin','Teacher','Student','Parent') NOT NULL,
    IsActive TINYINT(1) DEFAULT 1,
    LastLogin DATETIME,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE 3: Students
-- ============================================================
CREATE TABLE Students (
    StudentID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    DateOfBirth DATE NOT NULL,
    Gender ENUM('Male','Female','Other') NOT NULL,
    Email VARCHAR(100) UNIQUE,
    Phone VARCHAR(20),
    Address TEXT,
    EnrollmentDate DATE NOT NULL,
    ClassID INT,
    DepartmentID INT,
    GuardianName VARCHAR(100),
    GuardianPhone VARCHAR(20),
    IsActive TINYINT(1) DEFAULT 1,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID)
);

-- ============================================================
-- TABLE 4: Teachers
-- ============================================================
CREATE TABLE Teachers (
    TeacherID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    DateOfBirth DATE,
    Gender ENUM('Male','Female','Other'),
    Email VARCHAR(100) UNIQUE NOT NULL,
    Phone VARCHAR(20),
    Address TEXT,
    Qualification VARCHAR(100),
    JoiningDate DATE NOT NULL,
    DepartmentID INT,
    Salary DECIMAL(10,2),
    IsActive TINYINT(1) DEFAULT 1,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID)
);

-- ============================================================
-- TABLE 5: Classes
-- ============================================================
CREATE TABLE Classes (
    ClassID INT AUTO_INCREMENT PRIMARY KEY,
    ClassName VARCHAR(50) NOT NULL,
    ClassCode VARCHAR(20) NOT NULL UNIQUE,
    Section VARCHAR(5),
    DepartmentID INT,
    ClassTeacherID INT,
    RoomNumber VARCHAR(20),
    Capacity INT DEFAULT 40,
    AcademicYear VARCHAR(10) NOT NULL,
    IsActive TINYINT(1) DEFAULT 1,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID),
    FOREIGN KEY (ClassTeacherID) REFERENCES Teachers(TeacherID)
);

ALTER TABLE Students ADD FOREIGN KEY (ClassID) REFERENCES Classes(ClassID);

-- ============================================================
-- TABLE 6: Subjects
-- ============================================================
CREATE TABLE Subjects (
    SubjectID INT AUTO_INCREMENT PRIMARY KEY,
    SubjectName VARCHAR(100) NOT NULL,
    SubjectCode VARCHAR(20) NOT NULL UNIQUE,
    CreditHours INT DEFAULT 3,
    DepartmentID INT,
    IsElective TINYINT(1) DEFAULT 0,
    IsActive TINYINT(1) DEFAULT 1,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID)
);

-- ============================================================
-- TABLE 7: TeacherSubjects (Many-to-Many)
-- ============================================================
CREATE TABLE TeacherSubjects (
    TeacherSubjectID INT AUTO_INCREMENT PRIMARY KEY,
    TeacherID INT NOT NULL,
    SubjectID INT NOT NULL,
    ClassID INT NOT NULL,
    AcademicYear VARCHAR(10) NOT NULL,
    UNIQUE KEY unique_assignment (TeacherID, SubjectID, ClassID, AcademicYear),
    FOREIGN KEY (TeacherID) REFERENCES Teachers(TeacherID),
    FOREIGN KEY (SubjectID) REFERENCES Subjects(SubjectID),
    FOREIGN KEY (ClassID) REFERENCES Classes(ClassID)
);

-- ============================================================
-- TABLE 8: Attendance
-- ============================================================
CREATE TABLE Attendance (
    AttendanceID INT AUTO_INCREMENT PRIMARY KEY,
    StudentID INT NOT NULL,
    SubjectID INT NOT NULL,
    AttendanceDate DATE NOT NULL,
    Status ENUM('Present','Absent','Late','Excused') NOT NULL DEFAULT 'Present',
    Remarks VARCHAR(200),
    MarkedByTeacherID INT,
    MarkedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_attendance (StudentID, SubjectID, AttendanceDate),
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    FOREIGN KEY (SubjectID) REFERENCES Subjects(SubjectID),
    FOREIGN KEY (MarkedByTeacherID) REFERENCES Teachers(TeacherID)
);

-- ============================================================
-- TABLE 9: Exams
-- ============================================================
CREATE TABLE Exams (
    ExamID INT AUTO_INCREMENT PRIMARY KEY,
    ExamName VARCHAR(100) NOT NULL,
    ExamType ENUM('Midterm','Final','Quiz','Assignment','Practical') NOT NULL,
    SubjectID INT NOT NULL,
    ClassID INT NOT NULL,
    ExamDate DATE NOT NULL,
    TotalMarks INT NOT NULL,
    PassingMarks INT NOT NULL,
    Duration INT COMMENT 'Duration in minutes',
    IsActive TINYINT(1) DEFAULT 1,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (SubjectID) REFERENCES Subjects(SubjectID),
    FOREIGN KEY (ClassID) REFERENCES Classes(ClassID)
);

-- ============================================================
-- TABLE 10: ExamResults
-- ============================================================
CREATE TABLE ExamResults (
    ResultID INT AUTO_INCREMENT PRIMARY KEY,
    ExamID INT NOT NULL,
    StudentID INT NOT NULL,
    ObtainedMarks DECIMAL(5,2) NOT NULL,
    Grade VARCHAR(5),
    Remarks VARCHAR(200),
    EnteredByTeacherID INT,
    EnteredAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_result (ExamID, StudentID),
    FOREIGN KEY (ExamID) REFERENCES Exams(ExamID),
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    FOREIGN KEY (EnteredByTeacherID) REFERENCES Teachers(TeacherID)
);

-- ============================================================
-- TABLE 11: FeeStructure
-- ============================================================
CREATE TABLE FeeStructure (
    FeeStructureID INT AUTO_INCREMENT PRIMARY KEY,
    ClassName VARCHAR(50) NOT NULL,
    FeeType ENUM('Tuition','Transport','Library','Lab','Exam','Hostel') NOT NULL,
    Amount DECIMAL(10,2) NOT NULL,
    AcademicYear VARCHAR(10) NOT NULL,
    DueDate INT COMMENT 'Day of month fee is due',
    IsActive TINYINT(1) DEFAULT 1,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE 12: FeePayments
-- ============================================================
CREATE TABLE FeePayments (
    PaymentID INT AUTO_INCREMENT PRIMARY KEY,
    StudentID INT NOT NULL,
    FeeStructureID INT NOT NULL,
    AmountPaid DECIMAL(10,2) NOT NULL,
    PaymentDate DATE NOT NULL,
    PaymentMethod ENUM('Cash','Bank','Online','Cheque') NOT NULL,
    ReceiptNumber VARCHAR(50) UNIQUE,
    Month VARCHAR(20),
    Year INT,
    Status ENUM('Paid','Partial','Pending','Overdue') NOT NULL DEFAULT 'Pending',
    Remarks VARCHAR(200),
    ReceivedByUserID INT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    FOREIGN KEY (FeeStructureID) REFERENCES FeeStructure(FeeStructureID)
);

-- ============================================================
-- TABLE 13: Timetable
-- ============================================================
CREATE TABLE Timetable (
    TimetableID INT AUTO_INCREMENT PRIMARY KEY,
    ClassID INT NOT NULL,
    SubjectID INT NOT NULL,
    TeacherID INT NOT NULL,
    DayOfWeek ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') NOT NULL,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    RoomNumber VARCHAR(20),
    AcademicYear VARCHAR(10) NOT NULL,
    IsActive TINYINT(1) DEFAULT 1,
    FOREIGN KEY (ClassID) REFERENCES Classes(ClassID),
    FOREIGN KEY (SubjectID) REFERENCES Subjects(SubjectID),
    FOREIGN KEY (TeacherID) REFERENCES Teachers(TeacherID)
);

-- ============================================================
-- TABLE 14: ErrorLogs
-- ============================================================
CREATE TABLE ErrorLogs (
    LogID INT AUTO_INCREMENT PRIMARY KEY,
    LogLevel ENUM('Info','Warning','Error','Critical') NOT NULL,
    Message TEXT NOT NULL,
    StackTrace TEXT,
    UserID INT,
    Module VARCHAR(100),
    LoggedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE 15: Announcements
-- ============================================================
CREATE TABLE Announcements (
    AnnouncementID INT AUTO_INCREMENT PRIMARY KEY,
    Title VARCHAR(200) NOT NULL,
    Content TEXT NOT NULL,
    TargetAudience ENUM('All','Students','Teachers','Parents') NOT NULL DEFAULT 'All',
    PublishedByUserID INT,
    PublishDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    ExpiryDate DATE,
    IsActive TINYINT(1) DEFAULT 1
);

-- ============================================================
-- TABLE 16: LeaveRequests
-- ============================================================
CREATE TABLE LeaveRequests (
    LeaveID INT AUTO_INCREMENT PRIMARY KEY,
    ApplicantType ENUM('Student','Teacher') NOT NULL,
    ApplicantID INT NOT NULL,
    LeaveType ENUM('Sick','Emergency','Casual','Annual') NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    Reason TEXT NOT NULL,
    Status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    ApprovedByUserID INT,
    ApprovedAt DATETIME,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);
