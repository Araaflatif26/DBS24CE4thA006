-- ============================================================
-- Views, Stored Procedures, Triggers, Constraints
-- ============================================================
USE SchoolManagementDB;

-- ============================================================
-- VIEWS (Minimum 5)
-- ============================================================

-- View 1: Student Full Details
CREATE OR REPLACE VIEW vw_StudentDetails AS
SELECT 
    s.StudentID, s.FirstName, s.LastName,
    CONCAT(s.FirstName, ' ', s.LastName) AS FullName,
    s.DateOfBirth, s.Gender, s.Email, s.Phone,
    s.EnrollmentDate, s.GuardianName, s.GuardianPhone,
    c.ClassName, c.Section, c.AcademicYear,
    d.DepartmentName, s.IsActive
FROM Students s
LEFT JOIN Classes c ON s.ClassID = c.ClassID
LEFT JOIN Departments d ON s.DepartmentID = d.DepartmentID;

-- View 2: Teacher Full Details
CREATE OR REPLACE VIEW vw_TeacherDetails AS
SELECT 
    t.TeacherID, t.FirstName, t.LastName,
    CONCAT(t.FirstName, ' ', t.LastName) AS FullName,
    t.Email, t.Phone, t.Qualification,
    t.JoiningDate, t.Salary,
    d.DepartmentName, t.IsActive
FROM Teachers t
LEFT JOIN Departments d ON t.DepartmentID = d.DepartmentID;

-- View 3: Attendance Summary per Student
CREATE OR REPLACE VIEW vw_AttendanceSummary AS
SELECT 
    s.StudentID,
    CONCAT(s.FirstName, ' ', s.LastName) AS StudentName,
    sub.SubjectName,
    COUNT(a.AttendanceID) AS TotalClasses,
    SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) AS PresentCount,
    SUM(CASE WHEN a.Status = 'Absent' THEN 1 ELSE 0 END) AS AbsentCount,
    ROUND(SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) * 100.0 / COUNT(a.AttendanceID), 2) AS AttendancePercentage
FROM Students s
JOIN Attendance a ON s.StudentID = a.StudentID
JOIN Subjects sub ON a.SubjectID = sub.SubjectID
GROUP BY s.StudentID, sub.SubjectID;

-- View 4: Exam Results with Grade
CREATE OR REPLACE VIEW vw_ExamResultsSummary AS
SELECT 
    er.ResultID,
    CONCAT(s.FirstName, ' ', s.LastName) AS StudentName,
    e.ExamName, e.ExamType, e.ExamDate,
    sub.SubjectName,
    c.ClassName, c.Section,
    e.TotalMarks, er.ObtainedMarks,
    ROUND(er.ObtainedMarks * 100.0 / e.TotalMarks, 2) AS Percentage,
    er.Grade,
    CASE WHEN er.ObtainedMarks >= e.PassingMarks THEN 'Pass' ELSE 'Fail' END AS PassFail
FROM ExamResults er
JOIN Students s ON er.StudentID = s.StudentID
JOIN Exams e ON er.ExamID = e.ExamID
JOIN Subjects sub ON e.SubjectID = sub.SubjectID
JOIN Classes c ON e.ClassID = c.ClassID;

-- View 5: Fee Status Summary
CREATE OR REPLACE VIEW vw_FeeStatus AS
SELECT 
    s.StudentID,
    CONCAT(s.FirstName, ' ', s.LastName) AS StudentName,
    c.ClassName,
    fs.FeeType,
    fs.Amount AS TotalFee,
    COALESCE(SUM(fp.AmountPaid), 0) AS PaidAmount,
    fs.Amount - COALESCE(SUM(fp.AmountPaid), 0) AS BalanceAmount,
    fp.Status
FROM Students s
JOIN Classes c ON s.ClassID = c.ClassID
JOIN FeeStructure fs ON c.ClassName = fs.ClassName
LEFT JOIN FeePayments fp ON s.StudentID = fp.StudentID AND fs.FeeStructureID = fp.FeeStructureID
GROUP BY s.StudentID, fs.FeeStructureID;

-- View 6: Timetable View
CREATE OR REPLACE VIEW vw_ClassTimetable AS
SELECT 
    t.TimetableID,
    c.ClassName, c.Section,
    sub.SubjectName,
    CONCAT(tea.FirstName, ' ', tea.LastName) AS TeacherName,
    t.DayOfWeek,
    TIME_FORMAT(t.StartTime, '%h:%i %p') AS StartTime,
    TIME_FORMAT(t.EndTime, '%h:%i %p') AS EndTime,
    t.RoomNumber
FROM Timetable t
JOIN Classes c ON t.ClassID = c.ClassID
JOIN Subjects sub ON t.SubjectID = sub.SubjectID
JOIN Teachers tea ON t.TeacherID = tea.TeacherID
WHERE t.IsActive = 1
ORDER BY t.DayOfWeek, t.StartTime;

-- View 7: Student Report Card
CREATE OR REPLACE VIEW vw_ReportCard AS
SELECT 
    s.StudentID,
    CONCAT(s.FirstName, ' ', s.LastName) AS StudentName,
    c.ClassName,
    sub.SubjectName,
    AVG(er.ObtainedMarks) AS AverageMarks,
    MAX(e.TotalMarks) AS TotalMarks,
    ROUND(AVG(er.ObtainedMarks) * 100.0 / MAX(e.TotalMarks), 2) AS AveragePercentage
FROM Students s
JOIN ExamResults er ON s.StudentID = er.StudentID
JOIN Exams e ON er.ExamID = e.ExamID
JOIN Subjects sub ON e.SubjectID = sub.SubjectID
JOIN Classes c ON s.ClassID = c.ClassID
GROUP BY s.StudentID, sub.SubjectID;


-- ============================================================
-- STORED PROCEDURES (Minimum 3)
-- ============================================================

DELIMITER $$

-- SP 1: Add Student
CREATE PROCEDURE sp_AddStudent(
    IN p_FirstName VARCHAR(50),
    IN p_LastName VARCHAR(50),
    IN p_DOB DATE,
    IN p_Gender ENUM('Male','Female','Other'),
    IN p_Email VARCHAR(100),
    IN p_Phone VARCHAR(20),
    IN p_Address TEXT,
    IN p_EnrollmentDate DATE,
    IN p_ClassID INT,
    IN p_DepartmentID INT,
    IN p_GuardianName VARCHAR(100),
    IN p_GuardianPhone VARCHAR(20),
    OUT p_NewStudentID INT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        INSERT INTO ErrorLogs(LogLevel, Message, Module)
        VALUES('Error', 'Error in sp_AddStudent', 'StudentManagement');
        RESIGNAL;
    END;

    START TRANSACTION;
        INSERT INTO Students(FirstName, LastName, DateOfBirth, Gender, Email, Phone,
            Address, EnrollmentDate, ClassID, DepartmentID, GuardianName, GuardianPhone)
        VALUES(p_FirstName, p_LastName, p_DOB, p_Gender, p_Email, p_Phone,
            p_Address, p_EnrollmentDate, p_ClassID, p_DepartmentID, p_GuardianName, p_GuardianPhone);
        SET p_NewStudentID = LAST_INSERT_ID();
    COMMIT;
END$$

-- SP 2: Record Fee Payment
CREATE PROCEDURE sp_RecordFeePayment(
    IN p_StudentID INT,
    IN p_FeeStructureID INT,
    IN p_AmountPaid DECIMAL(10,2),
    IN p_PaymentDate DATE,
    IN p_PaymentMethod ENUM('Cash','Bank','Online','Cheque'),
    IN p_Month VARCHAR(20),
    IN p_Year INT,
    IN p_ReceivedByUserID INT,
    OUT p_ReceiptNumber VARCHAR(50)
)
BEGIN
    DECLARE v_TotalFee DECIMAL(10,2);
    DECLARE v_AlreadyPaid DECIMAL(10,2);
    DECLARE v_Status ENUM('Paid','Partial','Pending','Overdue');

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        INSERT INTO ErrorLogs(LogLevel, Message, Module)
        VALUES('Error', CONCAT('Error in sp_RecordFeePayment for Student ', p_StudentID), 'FeeManagement');
        RESIGNAL;
    END;

    SELECT Amount INTO v_TotalFee FROM FeeStructure WHERE FeeStructureID = p_FeeStructureID;
    SELECT COALESCE(SUM(AmountPaid),0) INTO v_AlreadyPaid
    FROM FeePayments
    WHERE StudentID = p_StudentID AND FeeStructureID = p_FeeStructureID AND Month = p_Month AND Year = p_Year;

    IF (v_AlreadyPaid + p_AmountPaid) >= v_TotalFee THEN
        SET v_Status = 'Paid';
    ELSE
        SET v_Status = 'Partial';
    END IF;

    SET p_ReceiptNumber = CONCAT('RCP', YEAR(NOW()), LPAD(p_StudentID, 5, '0'), UNIX_TIMESTAMP());

    START TRANSACTION;
        INSERT INTO FeePayments(StudentID, FeeStructureID, AmountPaid, PaymentDate, PaymentMethod,
            ReceiptNumber, Month, Year, Status, ReceivedByUserID)
        VALUES(p_StudentID, p_FeeStructureID, p_AmountPaid, p_PaymentDate, p_PaymentMethod,
            p_ReceiptNumber, p_Month, p_Year, v_Status, p_ReceivedByUserID);
    COMMIT;
END$$

-- SP 3: Get Class Attendance Report
CREATE PROCEDURE sp_GetClassAttendanceReport(
    IN p_ClassID INT,
    IN p_SubjectID INT,
    IN p_StartDate DATE,
    IN p_EndDate DATE
)
BEGIN
    SELECT 
        s.StudentID,
        CONCAT(s.FirstName, ' ', s.LastName) AS StudentName,
        COUNT(a.AttendanceID) AS TotalClasses,
        SUM(CASE WHEN a.Status='Present' THEN 1 ELSE 0 END) AS Present,
        SUM(CASE WHEN a.Status='Absent' THEN 1 ELSE 0 END) AS Absent,
        SUM(CASE WHEN a.Status='Late' THEN 1 ELSE 0 END) AS Late,
        ROUND(SUM(CASE WHEN a.Status='Present' THEN 1 ELSE 0 END)*100.0/COUNT(a.AttendanceID),2) AS Percentage
    FROM Students s
    LEFT JOIN Attendance a ON s.StudentID = a.StudentID 
        AND a.SubjectID = p_SubjectID
        AND a.AttendanceDate BETWEEN p_StartDate AND p_EndDate
    WHERE s.ClassID = p_ClassID AND s.IsActive = 1
    GROUP BY s.StudentID;
END$$

-- SP 4: Generate Student Report Card
CREATE PROCEDURE sp_GetStudentReportCard(
    IN p_StudentID INT,
    IN p_AcademicYear VARCHAR(10)
)
BEGIN
    SELECT 
        sub.SubjectName,
        e.ExamType,
        e.TotalMarks,
        er.ObtainedMarks,
        ROUND(er.ObtainedMarks*100/e.TotalMarks, 2) AS Percentage,
        er.Grade,
        CASE WHEN er.ObtainedMarks >= e.PassingMarks THEN 'Pass' ELSE 'Fail' END AS Status
    FROM ExamResults er
    JOIN Exams e ON er.ExamID = e.ExamID
    JOIN Subjects sub ON e.SubjectID = sub.SubjectID
    JOIN Classes c ON e.ClassID = c.ClassID
    WHERE er.StudentID = p_StudentID AND c.AcademicYear = p_AcademicYear
    ORDER BY sub.SubjectName, e.ExamType;
END$$

-- SP 5: Bulk Mark Attendance
CREATE PROCEDURE sp_BulkMarkAttendance(
    IN p_SubjectID INT,
    IN p_AttendanceDate DATE,
    IN p_TeacherID INT,
    IN p_AttendanceData JSON
)
BEGIN
    DECLARE i INT DEFAULT 0;
    DECLARE v_Count INT;
    DECLARE v_StudentID INT;
    DECLARE v_Status VARCHAR(20);

    SET v_Count = JSON_LENGTH(p_AttendanceData);

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        INSERT INTO ErrorLogs(LogLevel, Message, Module)
        VALUES('Error', 'Error in sp_BulkMarkAttendance', 'Attendance');
        RESIGNAL;
    END;

    START TRANSACTION;
    WHILE i < v_Count DO
        SET v_StudentID = JSON_EXTRACT(p_AttendanceData, CONCAT('$[', i, '].studentID'));
        SET v_Status = JSON_UNQUOTE(JSON_EXTRACT(p_AttendanceData, CONCAT('$[', i, '].status')));
        
        INSERT INTO Attendance(StudentID, SubjectID, AttendanceDate, Status, MarkedByTeacherID)
        VALUES(v_StudentID, p_SubjectID, p_AttendanceDate, v_Status, p_TeacherID)
        ON DUPLICATE KEY UPDATE Status = v_Status;
        
        SET i = i + 1;
    END WHILE;
    COMMIT;
END$$

DELIMITER ;


-- ============================================================
-- TRIGGERS (Minimum 2)
-- ============================================================

DELIMITER $$

-- Trigger 1: Auto-assign Grade after Exam Result Insert
CREATE TRIGGER trg_AssignGrade
BEFORE INSERT ON ExamResults
FOR EACH ROW
BEGIN
    DECLARE v_Percentage DECIMAL(5,2);
    DECLARE v_TotalMarks INT;
    
    SELECT TotalMarks INTO v_TotalMarks FROM Exams WHERE ExamID = NEW.ExamID;
    SET v_Percentage = (NEW.ObtainedMarks / v_TotalMarks) * 100;
    
    IF v_Percentage >= 90 THEN SET NEW.Grade = 'A+';
    ELSEIF v_Percentage >= 80 THEN SET NEW.Grade = 'A';
    ELSEIF v_Percentage >= 70 THEN SET NEW.Grade = 'B';
    ELSEIF v_Percentage >= 60 THEN SET NEW.Grade = 'C';
    ELSEIF v_Percentage >= 50 THEN SET NEW.Grade = 'D';
    ELSE SET NEW.Grade = 'F';
    END IF;
END$$

-- Trigger 2: Log fee payment after insert
CREATE TRIGGER trg_LogFeePayment
AFTER INSERT ON FeePayments
FOR EACH ROW
BEGIN
    INSERT INTO ErrorLogs(LogLevel, Message, Module)
    VALUES('Info', CONCAT('Fee payment recorded. ReceiptNo: ', NEW.ReceiptNumber, 
           ', StudentID: ', NEW.StudentID, ', Amount: ', NEW.AmountPaid), 'FeeManagement');
END$$

-- Trigger 3: Prevent deleting active students
CREATE TRIGGER trg_PreventStudentDelete
BEFORE DELETE ON Students
FOR EACH ROW
BEGIN
    IF OLD.IsActive = 1 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot delete an active student. Please deactivate first.';
    END IF;
END$$

-- Trigger 4: Auto-log exam result update
CREATE TRIGGER trg_LogResultUpdate
AFTER UPDATE ON ExamResults
FOR EACH ROW
BEGIN
    INSERT INTO ErrorLogs(LogLevel, Message, Module)
    VALUES('Info', CONCAT('ExamResult updated. ResultID: ', NEW.ResultID,
           ', OldMarks: ', OLD.ObtainedMarks, ', NewMarks: ', NEW.ObtainedMarks), 'ExamManagement');
END$$

DELIMITER ;


-- ============================================================
-- CONSTRAINTS (Minimum 10)
-- ============================================================

-- Additional constraints using ALTER TABLE
ALTER TABLE Students
    ADD CONSTRAINT chk_StudentDOB CHECK (DateOfBirth < CURDATE()),
    ADD CONSTRAINT chk_StudentEmail CHECK (Email LIKE '%@%.%');

ALTER TABLE Teachers
    ADD CONSTRAINT chk_TeacherSalary CHECK (Salary > 0),
    ADD CONSTRAINT chk_TeacherEmail CHECK (Email LIKE '%@%.%');

ALTER TABLE Classes
    ADD CONSTRAINT chk_Capacity CHECK (Capacity > 0 AND Capacity <= 100);

ALTER TABLE Exams
    ADD CONSTRAINT chk_PassingMarks CHECK (PassingMarks <= TotalMarks),
    ADD CONSTRAINT chk_TotalMarks CHECK (TotalMarks > 0);

ALTER TABLE ExamResults
    ADD CONSTRAINT chk_ObtainedMarks CHECK (ObtainedMarks >= 0);

ALTER TABLE FeePayments
    ADD CONSTRAINT chk_AmountPaid CHECK (AmountPaid > 0);

ALTER TABLE FeeStructure
    ADD CONSTRAINT chk_FeeAmount CHECK (Amount > 0);

ALTER TABLE Attendance
    ADD CONSTRAINT chk_AttendanceDate CHECK (AttendanceDate <= CURDATE());

ALTER TABLE Timetable
    ADD CONSTRAINT chk_TimeSlot CHECK (EndTime > StartTime);


-- ============================================================
-- TRANSACTIONS (Minimum 3 examples used in Stored Procedures above)
-- Additional standalone transaction example
-- ============================================================

-- Transaction for enrolling a student (used programmatically in C#)
-- See sp_AddStudent for Transaction 1
-- See sp_RecordFeePayment for Transaction 2
-- See sp_BulkMarkAttendance for Transaction 3


-- ============================================================
-- SAMPLE DATA
-- ============================================================

INSERT INTO Departments (DepartmentName, DepartmentCode, HeadOfDepartment, EstablishedYear) VALUES
('Computer Science', 'CS', 'Dr. Ali Hassan', 2005),
('Mathematics', 'MATH', 'Prof. Sarah Khan', 2000),
('Physics', 'PHY', 'Dr. Usman Malik', 2000),
('English', 'ENG', 'Prof. Ayesha Iqbal', 1998),
('Biology', 'BIO', 'Dr. Fatima Shah', 2003);

INSERT INTO Users (Username, PasswordHash, Role) VALUES
('admin', SHA2('admin123', 256), 'Admin'),
('teacher1', SHA2('teacher123', 256), 'Teacher'),
('student1', SHA2('student123', 256), 'Student');

INSERT INTO Teachers (UserID, FirstName, LastName, Email, Phone, Qualification, JoiningDate, DepartmentID, Salary) VALUES
(2, 'Ahmed', 'Raza', 'ahmed.raza@school.edu', '0300-1234567', 'MS Computer Science', '2015-08-01', 1, 85000),
(NULL, 'Sana', 'Butt', 'sana.butt@school.edu', '0301-9876543', 'MS Mathematics', '2016-01-15', 2, 75000),
(NULL, 'Kamran', 'Ali', 'kamran.ali@school.edu', '0302-1112233', 'MS Physics', '2014-03-20', 3, 80000);

INSERT INTO Classes (ClassName, ClassCode, Section, DepartmentID, ClassTeacherID, RoomNumber, AcademicYear) VALUES
('Class 9', '9A', 'A', 1, 1, 'Room-101', '2024-25'),
('Class 10', '10A', 'A', 1, 2, 'Room-102', '2024-25'),
('Class 11', '11A', 'A', 2, 3, 'Room-103', '2024-25');

INSERT INTO Subjects (SubjectName, SubjectCode, CreditHours, DepartmentID) VALUES
('Computer Science', 'CS101', 3, 1),
('Mathematics', 'MATH101', 4, 2),
('Physics', 'PHY101', 4, 3),
('English', 'ENG101', 3, 4),
('Biology', 'BIO101', 4, 5);

INSERT INTO Students (FirstName, LastName, DateOfBirth, Gender, Email, Phone, Address, EnrollmentDate, ClassID, DepartmentID, GuardianName, GuardianPhone) VALUES
('Zain', 'Ahmed', '2008-05-15', 'Male', 'zain@email.com', '0300-1111111', 'Lahore', '2024-01-10', 1, 1, 'Mr. Ahmed', '0300-2222222'),
('Sara', 'Khan', '2007-09-20', 'Female', 'sara@email.com', '0301-3333333', 'Lahore', '2024-01-10', 2, 1, 'Mr. Khan', '0301-4444444'),
('Ali', 'Hassan', '2006-12-01', 'Male', 'ali@email.com', '0302-5555555', 'Lahore', '2024-01-10', 3, 2, 'Mr. Hassan', '0302-6666666');

INSERT INTO FeeStructure (ClassName, FeeType, Amount, AcademicYear, DueDate) VALUES
('Class 9', 'Tuition', 5000.00, '2024-25', 10),
('Class 9', 'Library', 500.00, '2024-25', 10),
('Class 10', 'Tuition', 6000.00, '2024-25', 10),
('Class 10', 'Lab', 1000.00, '2024-25', 10),
('Class 11', 'Tuition', 7000.00, '2024-25', 10);
