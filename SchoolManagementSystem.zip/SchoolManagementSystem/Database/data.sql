USE SchoolManagementDB;

-- Departments
INSERT IGNORE INTO Departments (DepartmentName, DepartmentCode, HeadOfDepartment, EstablishedYear) VALUES
('Computer Science', 'CS', 'Dr. Ali Hassan', 2005),
('Mathematics', 'MATH', 'Prof. Sarah Khan', 2000),
('Physics', 'PHY', 'Dr. Usman Malik', 2000),
('English', 'ENG', 'Prof. Ayesha Iqbal', 1998),
('Biology', 'BIO', 'Dr. Fatima Shah', 2003);

-- Teachers
INSERT IGNORE INTO Teachers (FirstName, LastName, Email, Phone, Qualification, JoiningDate, DepartmentID, Salary) VALUES
('Ahmed', 'Raza', 'ahmed.raza@school.edu', '0300-1234567', 'MS Computer Science', '2015-08-01', 1, 85000),
('Sana', 'Butt', 'sana.butt@school.edu', '0301-9876543', 'MS Mathematics', '2016-01-15', 2, 75000),
('Kamran', 'Ali', 'kamran.ali@school.edu', '0302-1112233', 'MS Physics', '2014-03-20', 3, 80000),
('Nadia', 'Hussain', 'nadia.hussain@school.edu', '0303-4455667', 'MA English', '2017-07-10', 4, 70000),
('Tariq', 'Mehmood', 'tariq.mehmood@school.edu', '0304-7788990', 'MS Biology', '2013-05-15', 5, 78000),
('Ayesha', 'Siddiqui', 'ayesha.siddiqui@school.edu', '0305-1122334', 'MS Computer Science', '2018-09-01', 1, 82000),
('Bilal', 'Khan', 'bilal.khan@school.edu', '0306-5566778', 'MS Mathematics', '2019-01-20', 2, 72000),
('Hira', 'Baig', 'hira.baig@school.edu', '0307-9900112', 'MS Physics', '2016-06-10', 3, 76000),
('Omar', 'Farooq', 'omar.farooq@school.edu', '0308-3344556', 'MA English', '2015-11-05', 4, 68000),
('Zara', 'Malik', 'zara.malik@school.edu', '0309-7788001', 'MS Biology', '2020-02-15', 5, 74000);

-- Classes
INSERT IGNORE INTO Classes (ClassName, ClassCode, Section, DepartmentID, ClassTeacherID, RoomNumber, AcademicYear) VALUES
('Class 6', '6A', 'A', 1, 1, 'Room-101', '2024-25'),
('Class 7', '7A', 'A', 2, 2, 'Room-102', '2024-25'),
('Class 8', '8A', 'A', 3, 3, 'Room-103', '2024-25'),
('Class 9', '9A', 'A', 1, 4, 'Room-104', '2024-25'),
('Class 10', '10A', 'A', 2, 5, 'Room-105', '2024-25');

-- Subjects
INSERT IGNORE INTO Subjects (SubjectName, SubjectCode, CreditHours, DepartmentID) VALUES
('Computer Science', 'CS101', 3, 1),
('Mathematics', 'MATH101', 4, 2),
('Physics', 'PHY101', 4, 3),
('English', 'ENG101', 3, 4),
('Biology', 'BIO101', 4, 5),
('Urdu', 'URD101', 3, 4),
('Chemistry', 'CHEM101', 4, 3),
('Islamiat', 'ISL101', 2, 4),
('Pakistan Studies', 'PAK101', 2, 4),
('General Science', 'SCI101', 3, 3);

-- Students
INSERT IGNORE INTO Students (FirstName, LastName, DateOfBirth, Gender, Email, Phone, Address, EnrollmentDate, ClassID, DepartmentID, GuardianName, GuardianPhone) VALUES
('Zain', 'Ahmed', '2010-05-15', 'Male', 'zain.ahmed@email.com', '0300-1111111', 'House 12, Gulberg, Lahore', '2024-01-10', 1, 1, 'Mr. Asif Ahmed', '0300-2222222'),
('Sara', 'Khan', '2009-09-20', 'Female', 'sara.khan@email.com', '0301-3333333', 'House 45, DHA, Lahore', '2024-01-10', 2, 2, 'Mr. Imran Khan', '0301-4444444'),
('Ali', 'Hassan', '2008-12-01', 'Male', 'ali.hassan@email.com', '0302-5555555', 'House 7, Model Town, Lahore', '2024-01-10', 3, 3, 'Mr. Tariq Hassan', '0302-6666666'),
('Fatima', 'Malik', '2010-03-22', 'Female', 'fatima.malik@email.com', '0303-7777777', 'House 33, Johar Town, Lahore', '2024-01-10', 1, 1, 'Mr. Saleem Malik', '0303-8888888'),
('Usman', 'Butt', '2009-07-14', 'Male', 'usman.butt@email.com', '0304-9999999', 'House 21, Bahria Town, Lahore', '2024-01-10', 2, 2, 'Mr. Naeem Butt', '0304-1010101'),
('Ayesha', 'Iqbal', '2008-11-30', 'Female', 'ayesha.iqbal@email.com', '0305-2020202', 'House 55, Wapda Town, Lahore', '2024-01-10', 4, 1, 'Mr. Javed Iqbal', '0305-3030303'),
('Hassan', 'Raza', '2010-01-08', 'Male', 'hassan.raza@email.com', '0306-4040404', 'House 9, Garden Town, Lahore', '2024-01-10', 3, 3, 'Mr. Waseem Raza', '0306-5050505'),
('Amna', 'Sheikh', '2009-06-25', 'Female', 'amna.sheikh@email.com', '0307-6060606', 'House 17, Iqbal Town, Lahore', '2024-01-10', 5, 2, 'Mr. Arif Sheikh', '0307-7070707'),
('Bilal', 'Chaudhry', '2008-04-17', 'Male', 'bilal.chaudhry@email.com', '0308-8080808', 'House 28, Samanabad, Lahore', '2024-01-10', 4, 1, 'Mr. Khalid Chaudhry', '0308-9090909'),
('Hira', 'Nawaz', '2010-08-09', 'Female', 'hira.nawaz@email.com', '0309-1212121', 'House 63, Township, Lahore', '2024-01-10', 5, 2, 'Mr. Pervez Nawaz', '0309-2323232'),
('Hamza', 'Siddiqui', '2009-02-14', 'Male', 'hamza.siddiqui@email.com', '0310-3434343', 'House 41, Gulshan Ravi, Lahore', '2024-01-10', 1, 1, 'Mr. Faisal Siddiqui', '0310-4545454'),
('Mahnoor', 'Ali', '2008-10-03', 'Female', 'mahnoor.ali@email.com', '0311-5656565', 'House 5, Shadman, Lahore', '2024-01-10', 2, 2, 'Mr. Liaqat Ali', '0311-6767676'),
('Saad', 'Farooq', '2010-12-20', 'Male', 'saad.farooq@email.com', '0312-7878787', 'House 19, Faisal Town, Lahore', '2024-01-10', 3, 3, 'Mr. Zahid Farooq', '0312-8989898'),
('Sobia', 'Baig', '2009-05-11', 'Female', 'sobia.baig@email.com', '0313-9090909', 'House 72, Cavalry Ground, Lahore', '2024-01-10', 4, 1, 'Mr. Riaz Baig', '0313-1010101'),
('Talha', 'Mehmood', '2008-07-28', 'Male', 'talha.mehmood@email.com', '0314-2121212', 'House 36, Cantt, Lahore', '2024-01-10', 5, 2, 'Mr. Aamir Mehmood', '0314-3232323');

-- Fee Structure
INSERT IGNORE INTO FeeStructure (ClassName, FeeType, Amount, AcademicYear, DueDate) VALUES
('Class 6', 'Tuition', 4500.00, '2024-25', 10),
('Class 6', 'Library', 300.00, '2024-25', 10),
('Class 7', 'Tuition', 5000.00, '2024-25', 10),
('Class 7', 'Library', 300.00, '2024-25', 10),
('Class 8', 'Tuition', 5500.00, '2024-25', 10),
('Class 8', 'Lab', 500.00, '2024-25', 10),
('Class 9', 'Tuition', 6000.00, '2024-25', 10),
('Class 9', 'Lab', 800.00, '2024-25', 10),
('Class 10', 'Tuition', 7000.00, '2024-25', 10),
('Class 10', 'Lab', 1000.00, '2024-25', 10);

-- Teacher-Subject assignments
INSERT IGNORE INTO TeacherSubjects (TeacherID, SubjectID, ClassID, AcademicYear) VALUES
(1, 1, 1, '2024-25'), (1, 1, 4, '2024-25'),
(2, 2, 2, '2024-25'), (2, 2, 5, '2024-25'),
(3, 3, 3, '2024-25'), (3, 7, 3, '2024-25'),
(4, 4, 1, '2024-25'), (4, 6, 2, '2024-25'),
(5, 5, 4, '2024-25'), (5, 10, 5, '2024-25');

-- Timetable
INSERT IGNORE INTO Timetable (ClassID, SubjectID, TeacherID, DayOfWeek, StartTime, EndTime, RoomNumber, AcademicYear) VALUES
(1, 1, 1, 'Monday', '08:00:00', '09:00:00', 'Room-101', '2024-25'),
(1, 2, 2, 'Monday', '09:00:00', '10:00:00', 'Room-101', '2024-25'),
(1, 4, 4, 'Tuesday', '08:00:00', '09:00:00', 'Room-101', '2024-25'),
(2, 2, 2, 'Monday', '08:00:00', '09:00:00', 'Room-102', '2024-25'),
(2, 3, 3, 'Tuesday', '09:00:00', '10:00:00', 'Room-102', '2024-25'),
(3, 3, 3, 'Monday', '08:00:00', '09:00:00', 'Room-103', '2024-25'),
(3, 5, 5, 'Wednesday', '08:00:00', '09:00:00', 'Room-103', '2024-25');

-- Sample Exams
INSERT IGNORE INTO Exams (ExamName, ExamType, SubjectID, ClassID, ExamDate, TotalMarks, PassingMarks, Duration) VALUES
('Midterm CS Class 6', 'Midterm', 1, 1, '2024-03-15', 100, 40, 120),
('Midterm Math Class 7', 'Midterm', 2, 2, '2024-03-16', 100, 40, 120),
('Final CS Class 6', 'Final', 1, 1, '2024-06-10', 100, 40, 180),
('Final Math Class 7', 'Final', 2, 2, '2024-06-11', 100, 40, 180),
('Quiz Physics Class 8', 'Quiz', 3, 3, '2024-02-20', 25, 10, 30);

-- Sample Exam Results
INSERT IGNORE INTO ExamResults (ExamID, StudentID, ObtainedMarks, Remarks) VALUES
(1, 1, 85, 'Good performance'),
(1, 4, 72, 'Satisfactory'),
(1, 7, 91, 'Excellent'),
(1, 9, 65, 'Average'),
(1, 11, 78, 'Good'),
(2, 2, 88, 'Excellent'),
(2, 5, 55, 'Needs improvement'),
(2, 8, 92, 'Outstanding'),
(2, 10, 70, 'Good'),
(2, 12, 83, 'Very Good');

-- Sample Attendance
INSERT IGNORE INTO Attendance (StudentID, SubjectID, AttendanceDate, Status, MarkedByTeacherID) VALUES
(1, 1, '2024-03-01', 'Present', 1), (1, 1, '2024-03-02', 'Present', 1),
(1, 1, '2024-03-03', 'Absent', 1),  (1, 1, '2024-03-04', 'Present', 1),
(2, 2, '2024-03-01', 'Present', 2), (2, 2, '2024-03-02', 'Late', 2),
(2, 2, '2024-03-03', 'Present', 2), (2, 2, '2024-03-04', 'Present', 2),
(3, 3, '2024-03-01', 'Present', 3), (3, 3, '2024-03-02', 'Present', 3),
(4, 1, '2024-03-01', 'Absent', 1),  (4, 1, '2024-03-02', 'Present', 1),
(5, 2, '2024-03-01', 'Present', 2), (5, 2, '2024-03-02', 'Present', 2),
(6, 1, '2024-03-01', 'Present', 1), (6, 1, '2024-03-02', 'Late', 1),
(7, 3, '2024-03-01', 'Present', 3), (7, 3, '2024-03-02', 'Present', 3),
(8, 2, '2024-03-01', 'Absent', 2),  (8, 2, '2024-03-02', 'Present', 2);

-- Sample Fee Payments
INSERT IGNORE INTO FeePayments (StudentID, FeeStructureID, AmountPaid, PaymentDate, PaymentMethod, ReceiptNumber, Month, Year, Status, ReceivedByUserID) VALUES
(1, 1, 4500.00, '2024-03-05', 'Cash', 'RCP2024001', 'March', 2024, 'Paid', 1),
(2, 3, 5000.00, '2024-03-06', 'Bank', 'RCP2024002', 'March', 2024, 'Paid', 1),
(3, 5, 5500.00, '2024-03-07', 'Online', 'RCP2024003', 'March', 2024, 'Paid', 1),
(4, 1, 4500.00, '2024-03-08', 'Cash', 'RCP2024004', 'March', 2024, 'Paid', 1),
(5, 3, 2500.00, '2024-03-09', 'Cash', 'RCP2024005', 'March', 2024, 'Partial', 1),
(6, 7, 6000.00, '2024-03-10', 'Bank', 'RCP2024006', 'March', 2024, 'Paid', 1),
(7, 5, 5500.00, '2024-03-11', 'Online', 'RCP2024007', 'March', 2024, 'Paid', 1),
(8, 3, 5000.00, '2024-03-12', 'Cash', 'RCP2024008', 'March', 2024, 'Paid', 1),
(9, 7, 6000.00, '2024-03-13', 'Cheque', 'RCP2024009', 'March', 2024, 'Paid', 1),
(10, 9, 7000.00, '2024-03-14', 'Bank', 'RCP2024010', 'March', 2024, 'Paid', 1);